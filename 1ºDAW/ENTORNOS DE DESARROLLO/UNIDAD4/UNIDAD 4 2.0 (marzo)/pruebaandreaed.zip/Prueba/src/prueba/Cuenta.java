package prueba;

/**
 *
 * @author Tu mismo
 */
public class Cuenta {


    // Propiedades de la Clase Cuenta
  private String nombre;
    private String cuenta;
    private double saldo;
    private double tipoInterés;

    /** Constructor sin argumentos 
     */
    public Cuenta ()
    {
    }
    /** Constructor con parámetro para iniciar todas las propiedades de la clase
     * 
     * @param nom Nombre del cliente de la cuenta
     * @param cue Número de la cuenta del cliente
     * @param sal Saldo actual en la cuenta
     * @param tipo Tipo de interés a aplicar a la cuenta
     */
    public Cuenta (String nom, String cue, double sal, double tipo)
    {
        nombre =nom;
        cuenta=cue;
        saldo=sal;
        tipoInterés=tipo;
    }
   /** Método para asignar el nombre del titular de la cuenta
     * 
     * @param nom Nombre del titular
     */
    public void asignarNombre(String nom)
    {
        setNombre(nom);
    }
    /** Método que me devuelve el nombre del titular
     * 
     * @return <code>nombre</code> Nombre del titular
     */
    public String obtenerNombre()
    {
        return getNombre();
    }

    /** Método que me devuelve el saldo disponible en cada momento
     * 
     * @return <code>saldo</code> Saldo disponible en la cuenta
     */
     public double estado ()
    {
        return getSaldo();
    }

    /** Método para ingresar cantidades en la cuenta. Modifica el saldo.
      * 
      * @param cantidad Dinero a ingresar en cuenta
      * @throws Exception  Controlamos que no se introduzcan cantidades negativas
      */
    public void ingresar(double cantidad) throws Exception
    {
        if (cantidad<0){
            throw new Exception("No se puede ingresar una cantidad negativa");}
        setSaldo(getSaldo() + cantidad);
    }



    /** Método para retirar cantidades en la cuenta. Modifica el saldo.
     * 
     * @param cantidad Dinero a sacar de la cuenta
     * @throws Exception  Controlamos que no se retiren cantidades negativas ni superiores al saldo
     */
    public void retirar (double cantidad) throws Exception
    {
        if (cantidad < 0){
            throw new Exception ("No se puede retirar una cantidad negativa");}
        if (estado()< cantidad){
            throw new Exception ("No se hay suficiente saldo");}
        setSaldo(getSaldo() - cantidad);
    }
    /**
     * Devuelve el número de cuenta 
     * @return <code>cuenta</code> Cadena con el número de cuenta
     */
    public String obtenerCuenta ()
    {
        return getCuenta();
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the cuenta
     */
    public String getCuenta() {
        return cuenta;
    }

    /**
     * @param cuenta the cuenta to set
     */
    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    /**
     * @return the saldo
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    /**
     * @return the tipoInterés
     */
    public double getTipoInterés() {
        return tipoInterés;
    }

    /**
     * @param tipoInterés the tipoInterés to set
     */
    public void setTipoInterés(double tipoInterés) {
        this.tipoInterés = tipoInterés;
    }

  

}





