package prueba;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Yo Mismo
 */
public class Main {
    static BufferedReader dato = new BufferedReader(new InputStreamReader(System.in));

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cuenta cuenta1;
        double saldoActual;
        int opcion=0;
        cuenta1 = operativa_cuenta();
        saldoActual = cuenta1.estado();
        System.out.println("El saldo actual es"+ saldoActual );
    }

    public static Cuenta operativa_cuenta() throws NumberFormatException {
        Cuenta cuenta1;
        int opcion = 0;
        float cantidad = 2500;
        cuenta1 = new Cuenta("Juan López","1000-2365-85-123456789",cantidad,0);
        do{
            try {
                System.out.println("MENÚ DE OPERACIONES");
                System.out.println("-------------------");
                System.out.println("1 - Ingresar");
                System.out.println("2 - Retirar");
                System.out.println("3 - Finalizar");
                opcion=Integer.parseInt(dato.readLine());
                
                boolean cuentaModificada  = false;
                if(opcion==1){
                    System.out.println("¿Cuánto desea ingresar?: ");
                    cantidad =Integer.parseInt(dato.readLine());
                    cuentaModificada = true;
                }else if(opcion==2){
                    System.out.println("¿Cuátno desea retirar?: ");
                    cantidad=Integer.parseInt(dato.readLine());
                    cuentaModificada = true;
                }else if(opcion==3){
                    System.out.println("Finalizamos la ejecución");
                }else{
                    System.err.println("Opción errónea");
                }
                if (cuentaModificada){
                    try {
                        cuenta1.ingresar(cantidad);
                    } catch (Exception ex) {
                        System.err.println("Fallo al ingresar");
                    }
                    try {
                        cuenta1.retirar(cantidad);
                    } catch (Exception ex) {
                        System.err.println("Fallo al retirar");
                    }
                }
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }while (opcion!=3);
        return cuenta1;
    }
   
}
