package practica;

import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InterfazGrafica {

    private JFrame frame;
    private JTextField txtOperando1;
    private JTextField txtOperando2;
    private JButton btnCalcular;
    private JLabel lblResultado;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    InterfazGrafica window = new InterfazGrafica();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public InterfazGrafica() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        
        JLabel lblNewLabel = new JLabel("Operando 1:");
        frame.getContentPane().add(lblNewLabel);
        
        txtOperando1 = new JTextField();
        frame.getContentPane().add(txtOperando1);
        txtOperando1.setColumns(10);
        
        JLabel lblNewLabel_1 = new JLabel("Operando 2:");
        frame.getContentPane().add(lblNewLabel_1);
        
        txtOperando2 = new JTextField();
        frame.getContentPane().add(txtOperando2);
        txtOperando2.setColumns(10);
        
        btnCalcular = new JButton("Calcular suma");
        btnCalcular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
                try {
                    double op1 = Double.parseDouble(txtOperando1.getText());
                    double op2 = Double.parseDouble(txtOperando2.getText());
                    
                    double suma = op1 + op2;
                    
                    lblResultado.setText("Resultado: " + suma);
                    
                } catch (NumberFormatException ex) {
                    lblResultado.setText("Resultado: error en los datos");
                }
                
            }
        });
        frame.getContentPane().add(btnCalcular);
        
        lblResultado = new JLabel("Resultado:");
        frame.getContentPane().add(lblResultado);
    }

}
