/**
 * 
 */
/**
 * 
 */
module InterfazAndreaSolis {
	requires java.desktop;
}