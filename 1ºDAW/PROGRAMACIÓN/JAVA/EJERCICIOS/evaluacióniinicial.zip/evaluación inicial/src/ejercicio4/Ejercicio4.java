/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio4 {
     public static void main(String[]args){
    int a=10, b=3;
    System.out.println("Suma:" +(a+b));
    System.out.println("Resta:" +(a-b));
    System.out.println("Multiplicación:" +(a*b));
    System.out.println("División:" +(a+b));
    System.out.println("Módulo:" +(a%b));
}
}
