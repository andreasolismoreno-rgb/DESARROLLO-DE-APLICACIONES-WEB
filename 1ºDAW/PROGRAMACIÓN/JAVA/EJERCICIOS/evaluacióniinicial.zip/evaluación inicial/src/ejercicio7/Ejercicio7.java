/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio7;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio7 {
    public static void main(String[]args){
        int x = 10; // bloque externo
        {
        int y= 5; // bloque interno
        System.out.println(y); // válido
    }
      System.out.println(x); //válido
      //System.out.println(y); ERROR: y no exite fuera del bloque
    }
}
