/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio2 {
    public static void main(String[]args){
        int numero = 10;            // int
        double pi =3.14;            //double
        boolean activo = true;      //boolean
        if (numero >5) {            //if
            System.out.println ("Mayor que 5");
        } else {                      //else
            System.out.println("Menor o igual a 5");
        }
        for(int i=0; i<3; i++) {    // for
            System.out.println(i);
        }
        while (numero <0) {         //while
            numero--;
        }
        return;                     //return
    }
    //Palabras clave usadas: public, class, int, double, boolean, if, else, for, while, return.

}
