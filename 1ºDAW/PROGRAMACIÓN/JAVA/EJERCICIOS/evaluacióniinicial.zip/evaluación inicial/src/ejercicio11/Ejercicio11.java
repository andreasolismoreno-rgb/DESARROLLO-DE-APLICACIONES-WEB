/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio11;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio11 {
     public static void main(String[]args){
         int edad = 18;
         boolean mayorEdad = (edad>= 18);
         System.out.println(" ¿Mayor de edad? " + mayorEdad);
}
}
