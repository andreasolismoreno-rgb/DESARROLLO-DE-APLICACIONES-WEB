/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio10;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio10 {
     public static void main(String[]args){
         float t1 = 36.5f;
         double t2 = 37.8;
         double media = (t1+ t2) / 2;
         System.out.println ("Media: " + media);
}
}
