/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio9;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio9 {
     public static void main(String[]args){
         int decimal = 25;
         int octal = 031; // octal (3*8 + 1 = 25)
         int hex = 0x19;  // hexadecimal (1*16 + 9 = 25)
         System.out.println(decimal + "," + octal + "," + hex );
}
}