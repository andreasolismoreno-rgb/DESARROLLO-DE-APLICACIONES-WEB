/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio1 {
    //Escribe 5
   //identificadores válidos y 5 inválidos en Java, explicando por qué
   //los inválidos no lo son.
    
    
    //VÁLIDOS 
    //edad
    //nombreAlumno
    //_total
    //$valor
    //contador1
    
    
    //INVÁLIDOS 
    //1numero   // empieza con un número
    //nombre alumno  // contiene un espacio
    //int      // palabra reservada
    //precio€  // símbolo no permitido
    //#dato    // símbolo no permitido


    
}
