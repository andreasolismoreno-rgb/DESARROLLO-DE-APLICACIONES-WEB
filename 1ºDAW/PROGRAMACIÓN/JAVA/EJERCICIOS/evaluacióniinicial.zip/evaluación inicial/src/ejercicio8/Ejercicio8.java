/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio8;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio8 {
    public static void main(String[]args){
        byte b = 100;
        short s= 20000;
        int i= 100000;
        long l= 1000000000L;
        System.out.println(b + "," + s + "," + i +"," + l);
}
}