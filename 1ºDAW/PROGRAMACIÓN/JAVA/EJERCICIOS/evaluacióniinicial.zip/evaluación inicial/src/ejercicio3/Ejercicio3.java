/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio3;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio3 {
    public static void main(String[]args){
    final double PI=3.1416;
    double radio = 5;
    double area = PI + radio + radio;
    System.out.println("Area del círculo:"+area);
}
}
