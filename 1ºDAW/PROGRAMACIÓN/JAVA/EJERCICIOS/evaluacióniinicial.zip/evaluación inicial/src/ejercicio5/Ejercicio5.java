/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio5;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio5 {
     public static void main(String[]args){
         int contador = 5;
         System.out.println(++contador); //incrementa primero, luego muestra -> 6
         System.out.println(contador++);// muestra primero 6, luego incrementa -> 7
         System.out.println(contador);//-> 7
}
}