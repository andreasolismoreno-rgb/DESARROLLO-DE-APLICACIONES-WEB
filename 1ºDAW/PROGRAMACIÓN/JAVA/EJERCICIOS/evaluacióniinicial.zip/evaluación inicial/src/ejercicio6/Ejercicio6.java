/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio6;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio6 {
    public static void main(String[]args){
        int x= 15;
        boolean dentro = (x>= 10 && x <=20);
}
}