package ejerciciosud2;
    //Menú de operaciones matemáticas
    //Crea un menú con switch-case que permita:
    //1. Calcular el factorial de un número.
    //2. Calcular la potencia de un número (base y exponente).
    //3. Calcular la raíz cuadrada.
    //4. Salir.
    //Usa do-while para repetir hasta que el usuario elija salir.
import java.util.Scanner;
public class Ejercicio12 {
  
    public static void main (String [] args){
        Scanner sc = new Scanner (System.in);
        Integer opcion = null;
        
        do {            
            System.out.println("1.Calcular el factorial de un número.");
            System.out.println("2. Calcular la potencia de un número (base y exponente)");
            System.out.println("3. Calcular la raíz cuadrada.");
            System.out.println("4. Salir.");
            opcion = sc.nextInt ();
            
            switch (opcion) {
                case 1:
                    System.out.println ("Vamos a hacer el factorial");
                    Integer n = sc.nextInt();
                    Integer res = 1;
                    for (int i = 1; i <= n; i++){
                    res = res * i;
                }
                    System.out.println ("El factorial de "+n+" es " + res);
                    break;
                    
                case 2:
                    System.out.println ("Vamos a calcular la potencial");
                    System.out.println ("Deme la base");
                    Integer base = sc.nextInt ();
                    System.out.println ("Deme exponente");
                    Integer exponente = sc.nextInt();
                    System.out.println ( base + "^" + exponente + "= " + Math.pow( base, exponente));
                    break;
                    
                case 3:
                    System.out.println ("Vamos a calcular la raiz cuadrada");
                    System.out.println ("Deme un numero");
                    Integer a = sc.nextInt ();
                    System.out.println ( "La raiz cuadrada de " +a+ "es " + Math.sqrt(a));
                    break;
                    
                case 4:
                    System.out.println ("Vamos a salir");
                    break;
                default:
                    System.out.println ("Déjate de rollo y pon un número válido");
            }
        } while (opcion!=4);
    }
}
