package ejemplosclase;
//Haz un programa que determine si un número entero es capicúa (se lee igual de izquierda a
//derecha que de derecha a izquierda).
//Necesitas while, módulo (%) y if.
//Ejemplo: 12321 → capicúa.
public class Numerocapicua_ejercicio14 {
    
}
