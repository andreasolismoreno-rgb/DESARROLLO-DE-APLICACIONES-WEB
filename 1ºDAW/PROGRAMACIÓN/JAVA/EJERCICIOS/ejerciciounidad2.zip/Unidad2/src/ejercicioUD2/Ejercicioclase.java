/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioUD2;

import java.util.Scanner;

/**
 *
 * @author DAW1-M
 */
public class Ejercicioclase {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduce mes: ");
        int mes = sc.nextInt();
        
        System.out.print("Introduce año: ");
        int anyo = sc.nextInt();
        
        int numDias = 0;
        
        
        if (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) {
            numDias = 31;
        } else if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
            numDias = 30;
        } else if (mes == 2){
             if (anyo % 400 == 0 || (anyo % 4 == 0 && anyo % 100 != 0)) {
                numDias = 29;                
            } else {
                numDias = 28;
            }
        }

        System.out.println("el mes " + mes + " del año "+anyo+" tiene "+numDias+" dias");
    }
}

