package iteradores;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Iteradores {
    public static void main (String [] args){
        
    
        List<Integer> lista = Arrays.asList(4, 6, 8, 6, 10, 6);

        System.out.println("Ejercicio 41 Apariciones de 6: " + contarApariciones(lista, 6));
        System.out.println("Ejercicio 42 Mayor: " + mayor(lista));
        System.out.println("Ejercicio 43 Menor: " + menor(lista));
        System.out.println("Ejercicio 44  Suma posiciones pares: " + sumaPares(lista));
        System.out.println("Ejercicio 45  Suma posiciones impares: " + sumaImpares(lista));
        System.out.println("Ejercicio 46  Contar pares: " + contarPares(lista));
        System.out.println("Ejercicio 47  Contar impares: " + contarImpares(lista));
        System.out.println("Ejercicio 48  Media: " + media(Arrays.asList(4, 6, 10, 0, 8)));
        System.out.println("Ejercicio 49  Media positivos: " + mediaPositivos(Arrays.asList(-3, 4, 10, -1, 6, 0)));
        System.out.println("Ejercicio 50  indexOf manual buscando 7: " + buscarNumero(Arrays.asList(3, 8, 1, 7, 4, 10), 7));
    }
  //  41. Apariciones de un dígito 
    public static int contarApariciones(List<Integer> lista, int digito) {
        Iterator<Integer> it = lista.iterator();
        int contador = 0;

        while (it.hasNext()) {
            if (it.next() == digito) contador++;
        }
        return contador;
    }

    //  42. Mayor 
    public static int mayor(List<Integer> lista) {
        Iterator<Integer> it = lista.iterator();
        int max = it.next();

        while (it.hasNext()) {
            int n = it.next();
            if (n > max) max = n;
        }
        return max;
    }

    //  43. Menor 
    public static int menor(List<Integer> lista) {
        Iterator<Integer> it = lista.iterator();
        int min = it.next();

        while (it.hasNext()) {
            int n = it.next();
            if (n < min) min = n;
        }
        return min;
    }

    //  44. Suma en posiciones pares 
    public static int sumaPares(List<Integer> lista) {
        ListIterator<Integer> it = lista.listIterator();
        int suma = 0;

        while (it.hasNext()) {
            int index = it.nextIndex(); 
            int n = it.next();
            if (index % 2 == 0) suma += n;
        }
        return suma;
    }

    //  45. Suma en posiciones impares 
    public static int sumaImpares(List<Integer> lista) {
        ListIterator<Integer> it = lista.listIterator();
        int suma = 0;

        while (it.hasNext()) {
            int index = it.nextIndex();
            int n = it.next();
            if (index % 2 != 0) suma += n;
        }
        return suma;
    }

    //  46. Contar pares 
    public static int contarPares(List<Integer> lista) {
        Iterator<Integer> it = lista.iterator();
        int contador = 0;

        while (it.hasNext()) {
            if (it.next() % 2 == 0) contador++;
        }
        return contador;
    }

    //  47. Contar impares 
    public static int contarImpares(List<Integer> lista) {
        Iterator<Integer> it = lista.iterator();
        int contador = 0;

        while (it.hasNext()) {
            if (it.next() % 2 != 0) contador++;
        }
        return contador;
    }

    //  48. Media 
    public static double media(List<Integer> lista) {
        Iterator<Integer> it = lista.iterator();
        int suma = 0;
        int total = 0;

        while (it.hasNext()) {
            suma += it.next();
            total++;
        }
        return (double) suma / total;
    }

    //  49. Media solo positivos 
    public static double mediaPositivos(List<Integer> lista) {
        Iterator<Integer> it = lista.iterator();
        int suma = 0;
        int total = 0;

        while (it.hasNext()) {
            int n = it.next();
            if (n > 0) {
                suma += n;
                total++;
            }
        }

        if (total == 0) {
            System.out.println("No hay números positivos.");
            return 0;
        }

        return (double) suma / total;
    }

    //  50. indexOf con iteradores 
    public static int buscarNumero(List<Integer> lista, int buscado) {
        ListIterator<Integer> it = lista.listIterator();

        while (it.hasNext()) {
            int index = it.nextIndex();
            int n = it.next();

            if (n == buscado) return index;
        }

        return -1;
    }   
}
