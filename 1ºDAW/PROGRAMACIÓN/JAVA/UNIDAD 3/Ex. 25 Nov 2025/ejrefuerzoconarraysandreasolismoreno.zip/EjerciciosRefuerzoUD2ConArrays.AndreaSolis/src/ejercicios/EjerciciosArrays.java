package ejercicios;

public class EjerciciosArrays {
    public static void main(String[] args) {
        int[] lista = {4, 6, 8, 6, 10, 6, -3, 4, -1};
        System.out.println("Ejercicio 41: Apariciones del 6 : " + ejercicio41(lista, 6));
        System.out.println("Ejercicio 42: Mayor : " + ejercicio42(lista));
        System.out.println("Ejercicio 43: Menor:  " + ejercicio43(lista));
        System.out.println("Ejercicio 44: Suma pares  :" + ejercicio44(lista));
        System.out.println("Ejercicio 45: Suma impares : " + ejercicio45(lista));
        System.out.println("Ejercicio 46: Cantidad pares : " + ejercicio46(lista));
        System.out.println("Ejercicio 47: Cantidad impares : " + ejercicio47(lista));
        System.out.println("Ejercicio 48: Media total : " + ejercicio48(lista));
        System.out.println("Ejercicio 49: Media positivos : " + ejercicio49(lista));
        System.out.println("Ejercicio 50: Posición del 7 : " + ejercicio50(lista, 7));
    }
        // 41. Contar cuántas veces aparece un número
    public static int ejercicio41(int[] array, int numero){
        int cont = 0;
        for(int e : array){
            if(e == numero) cont++;
        }
        return cont;
    }

    // 42. Devolver el mayor
    public static int ejercicio42(int[] array){
        int mayor = array[0];
        for(int e : array){
            if(e > mayor) mayor = e;
        }
        return mayor;
    }

    // 43. Devolver el menor
    public static int ejercicio43(int[] array){
        int menor = array[0];
        for(int e : array){
            if(e < menor) menor = e;
        }
        return menor;
    }

    // 44. Suma de posiciones pares (0,2,4...)
    public static int ejercicio44(int[] array){
        int suma = 0;
        for(int i = 0; i < array.length; i += 2){
            suma += array[i];
        }
        return suma;
    }

    // 45. Suma de posiciones impares (1,3,5...)
    public static int ejercicio45(int[] array){
        int suma = 0;
        for(int i = 1; i < array.length; i += 2){
            suma += array[i];
        }
        return suma;
    }

    // 46. Contar pares
    public static int ejercicio46(int[] array){
        int cont = 0;
        for(int e : array){
            if(e % 2 == 0) cont++;
        }
        return cont;
    }

    // 47. Contar impares
    public static int ejercicio47(int[] array){
        int cont = 0;
        for(int e : array){
            if(e % 2 != 0) cont++;
        }
        return cont;
    }

    // 48. Media de todos los números
    public static double ejercicio48(int[] array){
        double suma = 0;
        for(int e : array){
            suma += e;
        }
        return suma / array.length;
    }

    // 49. Media solo de positivos
    public static double ejercicio49(int[] array){
        double suma = 0;
        int cont = 0;
        for(int e : array){
            if(e > 0){
                suma += e;
                cont++;
            }
        }
        return cont == 0 ? 0 : suma / cont;
    }

    // 50. Buscar número y devolver posición (como indexOf)
    public static int ejercicio50(int[] array, int numero){
        for(int i=0; i<array.length; i++){
            if(array[i] == numero){
                return i; // posición encontrada
            }
        }
        return -1; // no encontrado
    }
    
}
