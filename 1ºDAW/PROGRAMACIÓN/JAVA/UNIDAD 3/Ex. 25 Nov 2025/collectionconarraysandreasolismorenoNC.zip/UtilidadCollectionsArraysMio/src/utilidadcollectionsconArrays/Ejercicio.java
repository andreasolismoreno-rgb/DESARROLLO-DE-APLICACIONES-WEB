package utilidadcollectionsconArrays;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Ejercicio {

    public static void main(String[] args) {

        ejemploMax();
        ejemploMin();
        ejemploSort();
        ejemploShuffle();
        ejemploReverse();
        ejemploFrequency();
        ejemploFill();
        ejemploCopy();
        ejemploRotate();
        ejemploSwap();
        ejemploReplaceAll();
        ejemploNCopies();
    }

    // 1. Collections.max() con array
    public static void ejemploMax() {
        Integer[] arr = {1, 8, 22, 3};
        int max = Collections.max(Arrays.asList(arr));
        System.out.println("Max array: " + max);
    }

    // 2. Collections.min() con array
    public static void ejemploMin() {
        Integer[] arr = {1, 8, 22, 3};
        int min = Collections.min(Arrays.asList(arr));
        System.out.println("Min array: " + min);
    }

    // 3. Arrays.sort() - Ordena el array
    public static void ejemploSort() {
        Integer[] arr = {1, 8, 22, 3};
        Arrays.sort(arr);
        System.out.println("Sort array: " + Arrays.toString(arr));
    }

    // 4. Collections.shuffle() requiere lista
    public static void ejemploShuffle() {
        Integer[] arr = {1, 8, 22, 3};
        List<Integer> lista = Arrays.asList(arr);
        Collections.shuffle(lista);
        System.out.println("Shuffle array: " + lista);
    }

    // 5. Collections.reverse() requiere lista
    public static void ejemploReverse() {
        Integer[] arr = {1, 8, 22, 3};
        List<Integer> lista = Arrays.asList(arr);
        Collections.reverse(lista);
        System.out.println("Reverse array: " + lista);
    }

    // 6. Collections.frequency() - contar ocurrencias
    public static void ejemploFrequency() {
        Integer[] arr = {1, 2, 3, 2, 2, 4};
        List<Integer> lista = Arrays.asList(arr);
        int freq = Collections.frequency(lista, 2);
        System.out.println("Frequency array (2): " + freq);
    }

    // 7. Arrays.fill() - Rellena array con valor
    public static void ejemploFill() {
        Integer[] arr = {1, 2, 3, 4};
        Arrays.fill(arr, 0);
        System.out.println("Fill array: " + Arrays.toString(arr));
    }

    // 8. Arrays.copyOf() - Copiar array
    public static void ejemploCopy() {
        Integer[] origen = {1, 2, 3, 4, 5};
        Integer[] destino = Arrays.copyOf(origen, origen.length);
        System.out.println("Copy array: " + Arrays.toString(destino));
    }

    // 9. Arrays.rotate() no existe, usamos Collections.rotate() sobre lista
    public static void ejemploRotate() {
        Integer[] arr = {1, 2, 3, 4, 5};
        List<Integer> lista = Arrays.asList(arr);
        Collections.rotate(lista, 2); // rota 2 posiciones a la derecha
        System.out.println("Rotate array: " + lista);
    }

    // 10. Collections.swap() - sobre lista
    public static void ejemploSwap() {
        Integer[] arr = {1, 2, 3, 4, 5};
        List<Integer> lista = Arrays.asList(arr);
        Collections.swap(lista, 0, 2);
        System.out.println("Swap array: " + lista);
    }

    // 11. Collections.replaceAll() - sobre lista
    public static void ejemploReplaceAll() {
        Integer[] arr = {1, 2, 3, 2, 2, 4};
        List<Integer> lista = Arrays.asList(arr);
        Collections.replaceAll(lista, 2, 99);
        System.out.println("ReplaceAll array: " + lista);
    }

    // 12. Collections.nCopies() - lista inmutable
    public static void ejemploNCopies() {
        List<String> lista = Collections.nCopies(5, "Hola");
        System.out.println("NCopies array: " + lista);
    }
    
    private static void ejerciciosindependerdelistas (String [] args){
        int[] arr = {1, 8, 22, 3, 2, 2, 4};

        ejemploMax(arr);
        ejemploMin(arr);
        ejemploSort(arr);
        ejemploShuffle(arr);
        ejemploReverse(arr);
        ejemploFrequency(arr, 2);
        ejemploFill(arr, 0);
        ejemploCopy(arr);
        ejemploRotate(arr, 2);
        ejemploSwap(arr, 0, 2);
        ejemploReplaceAll(arr, 2, 99);
        ejemploNCopies(5, "Hola");
    }

    // 1. Max
    public static void ejemploMax(int[] arr) {
        int max = arr[0];
        for (int n : arr) if (n > max) max = n;
        System.out.println("Max array: " + max);
    }

    // 2. Min
    public static void ejemploMin(int[] arr) {
        int min = arr[0];
        for (int n : arr) if (n < min) min = n;
        System.out.println("Min array: " + min);
    }

    // 3. Sort (burbuja simple)
    public static void ejemploSort(int[] arr) {
        int[] copy = Arrays.copyOf(arr, arr.length);
        for (int i = 0; i < copy.length - 1; i++) {
            for (int j = 0; j < copy.length - i - 1; j++) {
                if (copy[j] > copy[j + 1]) {
                    int temp = copy[j];
                    copy[j] = copy[j + 1];
                    copy[j + 1] = temp;
                }
            }
        }
        System.out.println("Sort array: " + Arrays.toString(copy));
    }

    // 4. Shuffle
    public static void ejemploShuffle(int[] arr) {
        int[] copy = Arrays.copyOf(arr, arr.length);
        Random r = new Random();
        for (int i = copy.length - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            int temp = copy[i];
            copy[i] = copy[j];
            copy[j] = temp;
        }
        System.out.println("Shuffle array: " + Arrays.toString(copy));
    }

    // 5. Reverse
    public static void ejemploReverse(int[] arr) {
        int[] copy = Arrays.copyOf(arr, arr.length);
        for (int i = 0; i < copy.length / 2; i++) {
            int temp = copy[i];
            copy[i] = copy[copy.length - 1 - i];
            copy[copy.length - 1 - i] = temp;
        }
        System.out.println("Reverse array: " + Arrays.toString(copy));
    }

    // 6. Frequency
    public static void ejemploFrequency(int[] arr, int num) {
        int count = 0;
        for (int n : arr) if (n == num) count++;
        System.out.println("Frequency of " + num + ": " + count);
    }

    // 7. Fill
    public static void ejemploFill(int[] arr, int valor) {
        int[] copy = Arrays.copyOf(arr, arr.length);
        Arrays.fill(copy, valor);
        System.out.println("Fill array: " + Arrays.toString(copy));
    }

    // 8. Copy
    public static void ejemploCopy(int[] arr) {
        int[] copy = Arrays.copyOf(arr, arr.length);
        System.out.println("Copy array: " + Arrays.toString(copy));
    }

    // 9. Rotate (derecha)
    public static void ejemploRotate(int[] arr, int posiciones) {
        int[] copy = Arrays.copyOf(arr, arr.length);
        int n = copy.length;
        posiciones %= n;
        int[] temp = Arrays.copyOf(copy, n);
        for (int i = 0; i < n; i++) {
            copy[(i + posiciones) % n] = temp[i];
        }
        System.out.println("Rotate array " + posiciones + ": " + Arrays.toString(copy));
    }

    // 10. Swap
    public static void ejemploSwap(int[] arr, int i, int j) {
        int[] copy = Arrays.copyOf(arr, arr.length);
        int temp = copy[i];
        copy[i] = copy[j];
        copy[j] = temp;
        System.out.println("Swap array: " + Arrays.toString(copy));
    }

    // 11. ReplaceAll
    public static void ejemploReplaceAll(int[] arr, int oldVal, int newVal) {
        int[] copy = Arrays.copyOf(arr, arr.length);
        for (int i = 0; i < copy.length; i++) {
            if (copy[i] == oldVal) copy[i] = newVal;
        }
        System.out.println("ReplaceAll array: " + Arrays.toString(copy));
    }

    // 12. nCopies
    public static void ejemploNCopies(int n, String valor) {
        String[] arr = new String[n];
        Arrays.fill(arr, valor);
        System.out.println("nCopies array: " + Arrays.toString(arr));
    }
}


