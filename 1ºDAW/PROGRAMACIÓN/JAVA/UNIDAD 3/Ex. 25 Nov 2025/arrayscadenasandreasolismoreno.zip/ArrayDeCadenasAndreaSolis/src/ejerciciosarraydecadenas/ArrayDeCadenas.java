package ejerciciosarraydecadenas;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class ArrayDeCadenas {


    public static void main(String[] args) {
        String [] cadenas = {"   hola  "," Pepe  ","Jose Luis","Ana","  Juan    Ramón  ","Betis"};
        //cero es hola, ... pedrito 4
        //pues ahora le asociaremos un número, 2,2,4,2,3,2
        //run:[hola, Pepe, Juanito, Ana, Pedrito, Betis]
        
        
        String [] cadenasEnMinusculas = aMinusculas(cadenas);
        System.out.println("Cadenas en minúsculas:");
        System.out.println(Arrays.toString (cadenasEnMinusculas));
        //run:[   hola  ,  pepe  , jose luis, ana,   juan    ramón  , betis]
        
        String[] cadenasSinBlancos = limpiaBlancos(cadenas);
        System.out.println(Arrays.toString(cadenasSinBlancos));
        
        
        System.out.println(Arrays.toString(cadenas));
        //run:[hola, Pepe, Jose Luis, Ana, Juan    Ramón, Betis]
        
        Integer x = contarVocales("Mundial");

        System.out.println(x);
        //RUN: 3 , tiene 3 vocales la palabra mundial
        // mundial tiene 7 letras, se comienza desde 0,0 al 6, cad.length es 7
        //quiero un array de enteros con el nº de vocales de la tabla de cadenas
        
        System.out.println (numVocalesConListas (cadenas));
        System.out.println (Arrays.toString(numVocalesConArrays (cadenas)));
        
        
        System.out.println(cuentaLetras("Pepe@#3+1*3"));
        
        //¿Cuál es la cadena del array cadenas que tiene más vocales?
        System.out.println (masVocales(cadenas));
        
        //¿Cuál es la cadena del array cadenas que tiene más letras? 
        System.out.println("Cadena con más letras: " + masLetras(cadenas));
        System.out.println (masLetras(cadenas));
        
        //¿Cuál es la cadena del array cadenas que tiene más números? 
        System.out.println (masNumeros(cadenas));
        
        //¿Cuál es la cadena del array cadenas que tiene más caracteris numeros o letras? 
        System.out.println (masAlfanumericos(cadenas));
        
        //Hacer un método que dada una cadena de caracteres me diga si 
        //es o no una contraseña válida. Una contraseña es válida si tiene
        //al menos 7 caracters
        //al menos una mayúsculo
        //al menos un número
        //al menos un carácter no alfanumérico        
        System.out.println ("¿Es válida la contraseña holA23! => " +esContrasenaValida("holA23!"));
        //ESTOS SE ENCUENTRAN FUERA DEL MAIN
    }

        // Método que me dice si una cadena es una contraseña válida
        public static boolean esContrasenaValida(String cad){

            // regla 1: longitud mínima 7
            if (cad.length() < 7) {
                return false;
            }

            boolean tieneMayus = false;
            boolean tieneNumero = false;
            boolean tieneNoAlfanumerico = false;

            for (int i = 0; i < cad.length(); i++){
                char c = cad.charAt(i);

                if (Character.isUpperCase(c)) {
                    tieneMayus = true;
                }
                if (Character.isDigit(c)) {
                    tieneNumero = true;
                }
                if (!Character.isLetterOrDigit(c)) {
                    tieneNoAlfanumerico = true;
                }
            }

            // para ser válida, debe cumplir TODAS
            return tieneMayus && tieneNumero && tieneNoAlfanumerico;
        }
        // ¿Cuál es la cadena del array cadenas que tiene más caracteres (letras o números)?
        public static String masAlfanumericos(String[] cadenas){
            String res = cadenas[0];
            for (int i = 0; i < cadenas.length; i++){
                if (cuentaAlfanumericos(cadenas[i]) > cuentaAlfanumericos(res)) {
                    res = cadenas[i];
                }
            }
            return res;
        }

        // Método que cuenta letras + números
        public static int cuentaAlfanumericos(String cad){
            int cont = 0;
            for (int i = 0; i < cad.length(); i++){
                if (Character.isLetterOrDigit(cad.charAt(i))) {
                    cont++;
                }
            }
            return cont;
        }    
        //¿Cuál es la cadena del array cadenas que tiene más números? 
         public static String masNumeros(String[] cadenas){
        String res = cadenas[0];
        for (int i = 0; i < cadenas.length; i++) {
            if (cuentaNumeros(cadenas[i]) > cuentaNumeros(res)) {
                res = cadenas[i];
            }
        }
        return res;
        }
          //método que cuenta números
        public static int cuentaNumeros(String cad){
        int cont = 0;
        for (int i = 0; i < cad.length(); i++){
            if (Character.isDigit(cad.charAt(i))) {
                cont++;
            }
        }
        return cont;
    }
        //¿Cuál es la cadena del array cadenas que tiene más letras? 
        public static String masLetras(String[] cadenas){
        String res = cadenas[0];
        // recorro el array
        for (int i = 0; i < cadenas.length; i++) {
            // si la actual tiene más letras que la res, la cambio
            if (cuentaLetras(cadenas[i]) > cuentaLetras(res)) {
                res = cadenas[i];
            }
        }
        return res;
    }
        public static String masVocales (String [] cadenas){
            String res = cadenas [0];
            for ( int i=0; i<cadenas.length; i++){
                if (contarVocales (res) < contarVocales (cadenas[i])){
                    res=cadenas[i];
                }
            }
            return res;
        }
        public static String[] limpiaBlancos(String[] cadenas){
            String[] res = new String[cadenas.length];
            for (int i = 0; i < cadenas.length; i++) {
                res[i] = cadenas[i].trim();
            }        
            return res;
        }
        public static String [] aMinusculas (String [] cadenas){
            String [] res= new String [cadenas.length];
            for(int i =0; i < cadenas.length; i++ ){
            
                res [i] = cadenas [i].toLowerCase();

            }
            return res;
        }
        public static int [] numVocalesConArrays (String [] cadenas){ //le tienes que poner un tamaño
        int[] res= new int [cadenas.length]; //NO PONGAS INTEGER, si lo pones aqui y en public static sale NULL, NULL..
            for(int i =0; i < cadenas.length; i++ ){
                //cadenas.length SIN PARÉNTESIS porque es un ARRAY
                res [i] = contarVocales (cadenas[i]);
            }
        return res;
        //RUN:[2, 2, 4, 1, 3, 2]
                
        }
        public static List <Integer> numVocalesConListas (String [] cadenas){
            List <Integer> res = new ArrayList<>();
            for (String cad: cadenas){
                res.add(  contarVocales(cad) );
            }
            return res;
        }
        //RUN:[2, 2, 4, 1, 3, 2]

        public static Integer contarVocales (String cad){
            Integer cont = 0;
            for(int i =0; i < cad.length(); i++ ){
               // cad.length () con paréntesis, es un método
                if(cad.charAt(i) == 'a' || cad.charAt(i)== 'e'
                || cad.charAt(i) == 'i'|| cad.charAt(i) == 'o'
                      || cad.charAt(i) == 'u'  ){
                    cont++;
                }
            } 
            //"a" una lista o cadena  posible de caracteres
            //'a' un caracter
            //"pepe" una lista o cadena posible de caracter 
            //'pepe' no existe, es un error, solo puede haber una cosa
            return cont;
        }
    
        public static Integer cuentaLetras(String cad){
            Integer cont=0;
            for (int i = 0; i < cad.length(); i++) {
                if (Character.isLetter(cad.charAt(i))) {
                cont++;
                }
            }
               return cont;
        }
}

//Si cambias todo a listas, tendrías que reescribir:
//public static String[] limpiaBlancos(String[] cadenas)
//por:
//public static List<String> limpiaBlancos(List<String> cadenas)