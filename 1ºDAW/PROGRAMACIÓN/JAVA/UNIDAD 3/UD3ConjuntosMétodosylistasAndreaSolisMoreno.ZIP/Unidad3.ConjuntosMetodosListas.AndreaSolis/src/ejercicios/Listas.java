package ejercicios;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class Listas {

    public static void main(String[] args) {

        List<String> lista = new ArrayList<>(); // Crear una lista vacía  RUN: Lista inicial: []
        System.out.println("Lista inicial: " + lista);

        
        lista.add("5"); //MUESTRO MI LISTA
        lista.add("3"); 
        lista.add ("7");
        lista.add("5");
 
        
        System.out.println("La lista de números es: " + lista);// add(E e) RUN:La lista de números es: [5, 3, 7, 8]

        lista.add(1, "2"); // MÉTODO 1, indico la posición y el número que quiero colocar ahí
        System.out.println("Quiero añadir a la lista el número 2: " + lista);
        //add(int index, E element) INSERTAR un elemento en una posición que yo quiera, yo he elegido la posicion 1
        //run:Quiero añadir a la lista el número 2: [5, 2, 3, 7, 5]

        
        lista.addAll(2, Arrays.asList("9", "4")); // MÉTODO 2
        System.out.println("Quiero añadir dos números más a la lista, el 9 y el 4 : "  + lista);  
            //addAll(int index, Collection) INSERTA VARIOS elementos a la lista
           //run:Quiero añadir dos números más a la lista, el 9 y el 4 : [5, 2, 9, 4, 3, 7, 5]
        
        System.out.println("Devuelveme el número de la posición segunda posición de la lista: " + lista.get(2)); // MÉTODO 3  get(int index)
        //OBTENER elemento, me da el número 9 de la posición que pido, segunda
          // run: Devuelveme el número de la posición 2: 9


        String antiguo = lista.set(0, "22"); // MÉTODO 4, posicion cero es el número 5 y ahi se coloca el nuevo elemento que es el 22
        System.out.println("Quita el primer elemento de la lista y añade el número 22 : " + lista 
                + " Hemos reemplazado el número: " + antiguo);// set(int index, E element)  REEMPLAZAR elemento por otro
        //lista actual [22, 2, 9, 4, 3, 7, 5]


        String eliminado = lista.remove(2); // MÉTODO 5 ; lista actual [22, 2, 9, 4, 3, 7, 8] 
        //REEMPLAZA un elemento, en este caso pido el que se encuentre en la posición 2, que quitará el 9
        System.out.println("Reemplaza el número de la segunda posición de la lista: " + lista
                + " Hemos eliminado el número: " + eliminado);// remove(int index) 
         //run:Reemplaza el número de la posición 2: [22, 2, 4, 3, 7, 5] Hemos eliminado el número: 9
       
                                                                                                          
                                                                                                          
                                                                                                          
        System.out.println("¿En qué posición de la lista se encuentra el número siete?: "
                + "se encuentra en la posición " + lista.indexOf("7")); // MÉTODO 6 indexOf(Object o)  índice PRIMERA ocurrencia
        //run:¿En qué posición de la lista se encuentra el número siete?: se encuentra en la posición 4.
        
                 lista.add("10"); //añado otro elemento más a la lista, el 10.
        System.out.println("¿En qué posición se encontraría el último cinco?: " 
                + "Se encontraría en la posición : " + lista.lastIndexOf("5") 
                + " y así quedaría la lista : " + lista); // Método 7 lastIndexOf(Object o)  índice ÚLTIMA ocurrenCia
                //run:: Se encontraría en la posición : 5 y así quedaría la lista : [22, 2, 4, 3, 7, 5, 10] añadiendo el último elemento
                
                
        List<String> sub = lista.subList(1,4); // Método 8 subList(int fromIndex, int toIndex) → vista de porción
                                                //OJO!!!!! Con subList(1,4) se come el ultimo número
                                                
        System.out.println("Muestrame la sublista desde la posición primera a la cuarta: " + sub); //lista actual:[2, 4, 3]
        //RUN: [2, 4, 3] de la lista:[22, 2, 4, 3, 7, 5, 10]
        //nuestra lista es esta [22, 2, 4, 3, 7, 5, 10]
        //pues contaría 0, 1, 2, 3, 4 (aquí en el cuatro no lo menciona, solo menciona del 1 al 3.
        // que saldría por pantalla [2,4,3]
        
        
        List<String> subi = lista.subList(5,6); // Método 8 subList(int fromIndex, int toIndex) → vista de porción
                                                //OJO!!!!! Con subList(5,6) se come el ultimo número
                                                //nuestra lista es esta [22, 2, 4, 3, 7, 5, 10]
                                                //pues contaría 0, 1,...5, 6 (aquí en el sexto no lo menciona, solo menciona la quinta posición
                                                 //ya que la sexta posicion es la última
                                                // que saldría por pantalla [5]
                                                //auqnue si cambias el (5,6), por (5,7) si saldrían los dos últimos números [5,10]
                                                //pero si pones (5,8), te da error.
                                                
                                                
                                                
        System.out.println("Muestrame la sublista desde la posición quinta a la sexta: " + subi); 
        //RUN: [8] de la lista:[22, 2, 4, 3, 7, 8, 10]
        

        // Modificar sublista afecta la lista original
        sub.set(0, "17"); //donde pone cero se trata de la posición cero es el elemnto 22 de nuestra lista
                        // el 17 que he puesto, es lo que reemplazaría al que que estaba en la 
                        //posicion 1 de la lista que es el elemento 2
                        //cambia el elemento del índice 0 de la sublista, que corresponde al índice 1 de la lista original.

                       // Antes: lista = [22, 2(índice uno), 9, 4, 3, 7, 8]
                       // sub = [2 (índice cero) , 9, 4]
                       //Ahora: lista = [22, 17, 4, 3, 7, 8, 10]
                       //sub:[17, 4, 3]
        System.out.println("Lista después de modificar sublista: " + lista.subList(1,4) +lista);
        //run:[22, 17, 4, 3, 7, 8, 10]
        
        
    }
}

//COMENTARIOS, ten en mente siempre una caja, hay varias cajas y en cada caja habrá un elemento 
//puede ser números o letras o cualquier cosa,
//en cada una de las cajas encima tienen asignado un número, comenzando con el cero. 
//Yo he decidido poner números pero imaginemos que en vez de números 
//fuesen colores, y tengo una lista con 4 cajas ( azul, rojo, amarillo y  verde), la posiciones sería,
//0, azul; 1, rojo; 2, amarillo; 3, verde

//PRIMERO. CREAR UNA LISTA, ME ESTÁ PIDIENDO UNA LISTA VACÍA run:Lista inicial: []

//MÉTODO 1. Me pide crear una lista ya con elementos, yo he puesto (5,3,7,8)
//void add(int index, E element)--> lista.add(1, "2"); indico la posición, o índice (1) y en elemento lo que quiero colocar ahí(2)
//la lista se modificaría y se quedaría así [5, 2, 3, 7, 8]

//MÉTODO 2.boolean addAll(int index, Collection<? extends E> c) INSERTA VARIOS elementos a la lista, 
//Quiero añadir dos números más a la lista, el 9 y el 4 : [5, 2, 9, 4, 3, 7, 8]

//MÉTODO 3. E get(int index) Me devuelve un elemento de la posición que indico

//MÉTODO 4. E set(int index, E element)Reemplaza el elemento en la posición que indique(index) 
//con el elemento que indique .String antiguo = lista.set(0, "22");posicion cero es el número 5 y 
//ahi se coloca el nuevo elemento que es el 22. Lista actual [22, 2, 9, 4, 3, 7, 8]

//MÉTODO 5:E remove(int index), String eliminado = lista.remove(2)E remove(int index)
//Elimina el elemento en la posición especificada (index) LISTA: [22, 2, 4, 3, 7, 8]

//MÉTODO 6: int indexOf(Object o)lista.indexOf("7")); 
//run:¿En qué posición de la lista se encuentra el número siete?: se encuentra en la posición 4.
//devuelve 0 o -1 si no existe en la lista

//MÉTODO 7: int lastIndexOf(Object o)Devuelve el índice de la última ocurrencia del elemento especificado
//lista.lastIndexOf("10")Se encontraría en la posición : 6 y así quedaría la lista : [22, 2, 4, 3, 7, 8, 10]
//devuelve 0 o -1 si no existe en la lista

//MÉTODO 8: List<E> subList(int fromIndex, int toIndex) 
