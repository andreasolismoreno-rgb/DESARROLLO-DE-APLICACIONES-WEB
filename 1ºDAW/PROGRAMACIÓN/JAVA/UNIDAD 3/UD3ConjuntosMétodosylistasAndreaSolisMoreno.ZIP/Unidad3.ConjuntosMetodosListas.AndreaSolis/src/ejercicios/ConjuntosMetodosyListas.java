package ejercicios;
import java.util.ArrayList;
import java.util.List;
public class ConjuntosMetodosyListas {

    public static void main(String[] args) {

        List<Integer> lista = new ArrayList<>(); // Creamos una lista de enteros

        System.out.println("Lista inicial: " + lista);
        // run: [] nos muestra la lista inciial, que está vacía

        //MÉTODOS
        
        // MÉTODO 1:  Collection: add(E e)
        // Añade elementos a la lista
        lista.add(10);
        lista.add(20);
        lista.add(30);
        lista.add(10); 

        System.out.println("Después de add(): " + lista);
        // RUN: [10, 20, 30, 10] Muestra la lista con los elementos.


        // MÉTODO 2 Collection: size()
        // Devuelve el nº de elementos
        System.out.println("Tamaño de la lista: " + lista.size());
        // RUN: 4 nos muestra el "tamaño" de la lista, es decir, cuantos elementos hay en la lista.


        // MÉTODO 3 Collection: contains(Object o)
        // Comprueba si la lista contiene un elemento concreto
        System.out.println("¿La lista contiene 20? " + lista.contains(20));
        // RUN: true
        System.out.println("¿La lista contiene 8? " + lista.contains(8));
        //run: false 


        // MÉTODO 4 Collection: isEmpty()
        // Comprueba si la lista está vacía
        System.out.println("¿La lista está vacía?: " + lista.isEmpty());
        // RUN: false la lista tiene elementos


        // Creamos dos listas nuevas como hicimos en los métodos con c1 y c2
        List<Integer> lista1 = new ArrayList<>();
        lista1.add(10);
        lista1.add(40);
        lista1.add(50);

        List<Integer> lista2 = new ArrayList<>();
        lista2.add(10);
        lista2.add(20);
        lista2.add(99);
        
        System.out.println("La primera lista es : " + lista1 );
        System.out.println("La segunda lista es : " + lista2);
        //RUN:La primera lista es : [10, 40, 50]
        //La segunda lista es : [10, 20, 99]



        // MÉTODO 5 Collection: containsAll(Collection<?> c)
        // Comprueba si una lista contiene TODOS los elementos de otra
        System.out.println("¿La segunda lista contiene todos los elementos de la primera lista?: " + lista.containsAll(lista1));
        System.out.println("¿La primera lista contiene todos los elementos de la segunda lista?: " + lista.containsAll(lista2));
        //RUN:ambos falsos


        // MÉTODO 6 Collection: addAll(Collection c)
        // Añade TODOS los elementos de otra colección a esta lista
        List<Integer> union = new ArrayList<>(lista2);
        union.addAll(lista1);
        System.out.println("Unión de los elementos de la primera lista a la segunda lista : "+ lista1  + union);
        // En List SÍ se añaden duplicados
        //run: [10, 40, 50] esta es la primera lista y [10, 20, 99, 10, 40, 50] es la segunda lista unida con la lista primera

        // MÉTODO 7 Collection: remove(Object o)
        // Elimina una única instancia del elemento indicado
        // (OJO: diferente de remove(index))
        lista.remove(Integer.valueOf(10)); 
        System.out.println("Elimina el elemento 10 de la lista : " + lista);
        // Solo elimina la primera aparición!!!
        //lista antes (la inicial, ni la primera ni la segunda): [10, 20, 30, 10]
        //lista actual: run :[20, 30, 10]

        // MÉTODO 8 Collection: removeAll(Collection<?> c)
        // Elimina TODOS los elementos que aparecen también en otra colección
        List<Integer> dif1 = new ArrayList<>(lista1);
        dif1.removeAll(lista2);
        System.out.println("Diferencia lista 1 - lista 2: " + dif1);
        //lista 1,[10, 40, 50]
        //lista 2, [10, 20, 99]
        
        //El elemento que se repite es 10 se elimina ese y se muestra los demás elementos. run:[40, 50]
        List<Integer> dif2 = new ArrayList<>(lista2);
        dif2.removeAll(lista1);
        System.out.println("Diferencia lista 1 - lista 2: " + dif2);
        //run:[20, 99]
        
        


        // MÉTODO 9 Collection: retainAll(Collection<?> c)
        // Deja SOLO los elementos en común entre listas (intersección)
        List<Integer> inter = new ArrayList<>(lista1);
        inter.retainAll(lista2);
        System.out.println("Intersección lista1 y  lista2: " + inter);
        //Hemos visto antes que el elemento que se repetía en ambas listas era el nº10
        //run:[10]


        // MÉTODO 10 Collection: clear()
        // Vacía completamente la lista
        List<Integer> vaciar = new ArrayList<>(lista);
        vaciar.clear();
        System.out.println("Lista después de clear(): " + vaciar);
        //run: []

        
        
        
        // MÉTODOS DE LIST 


        // MÉTODO 1 add(int index, E element) Añade el elemento en la posición que yo indique
        lista.add(1, 55);
        System.out.println("Añade en la segunda posición el elemento número 55: " + lista);
        //lista [20, 30, 10]
        //lista actual, al añadir el 55 en la poscion 2. run: [20, 55, 30, 10]


        // MÉTODO 2 addAll(int index, Collection c)
        lista.addAll(2, lista1);
        System.out.println("Añade los elementos de la primera lista a la posición 2 : " + lista);
        //lista 1: [ 10, 40, 50]
        //lista principal: [20, 55, 30, 10]
        //run:[20, 55, 10, 40, 50, 30, 10]

        
        // MÉTODO 3 get(int index)
        System.out.println("¿Qué elemento se encuentra en la posición 3? : " + lista.get(3));
        //De esta lista [20, 55, 10, 40, 50, 30, 10] el elemnto que está en la posición 3 es el nº 40.


        // MÉTODO 4 set(int index, E element)
        lista.set(0, 14);
        System.out.println("En la primera posición de la lista quita el elemento que estaba y añade el número 14 : " + lista);
        // de esta lista [20, 55, 10, 40, 50, 30, 10] en la posicion cero, que se encuentra el elemento nº20, se quita y se añade el 14.
        //run: [14, 55, 10, 40, 50, 30, 10]

        
        // MÉTODO 5 remove(int index)  → ELIMINA POR POSICIÓN, NO POR VALOR
        lista.remove(2);
        System.out.println("Elimina el elemento que se encuntre la posición 2 : " + lista);
        //lista antes [14, 55, 10, 40, 50, 30, 10]
        //lista ahora run: [14, 55, 40, 50, 30, 10]

        // MÉTODO 6 indexOf(Object o)
        System.out.println("Primera posición de 20: " + lista.indexOf(20)); 
        //El nº 20 no aparece en la lista, indexOf es cuadno aparece por 1º vez el nº20. run: -1
        


        // MÉTODO 7 lastIndexOf(Object o)
        lista.add(20); // añadimos duplicado
        System.out.println("Última posición de 20: " + lista.lastIndexOf(20));
        //El nº 20 no aparece en la lista, lastIndexOf es cuando aparece por última vez el nº20. run: 6, pq el último elemento es el quinto.
        //run: 

        // MÉTODO 8 subList(int from, int to)
        List<Integer> sub = lista.subList(1, 4);
        System.out.println("Muéstrame la lista desde la segunda posición hasta la cuarta : " + sub);
        //me muestra solo del 1 al 3, en realidad. 
        //run: [55, 40, 50]

    }
}

