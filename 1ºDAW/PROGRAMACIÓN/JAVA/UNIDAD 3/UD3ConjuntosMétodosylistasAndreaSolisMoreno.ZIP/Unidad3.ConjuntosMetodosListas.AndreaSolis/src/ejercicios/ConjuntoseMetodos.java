package ejercicios;
import java.util.HashSet;
import java.util.Set;
public class ConjuntoseMetodos {

    public static void main(String[] args) {

        Set<Double> conj = new HashSet<>();// Creamos un conjunto (Set) de números decimales (Double)

        System.out.println("Conjunto inicial: " + conj);// MOSTRAMOS EL CONJUNTO VACÍO, esto NO es 
                                                        //un método de Collection, solo impresión
                                                        //RUN:Conjunto inicial: []
                                                        
                                                        
        conj.add(6.66);// 1º MÉTODO Collection: add(E e). AÑADIMOS elementos al conjunto
                       //E es el tipo de elemento que tiene tu colección. Devuelve (BOOLEAN)  true si el elemento se añadió correctamente.
        conj.add(7.0);
        conj.add(4.3);
        conj.add(6.66); // Este no  se repite porque Set no permite duplicados
        conj.add(7.0);  // Este tampoco se repite
        conj.add(3.3);

        System.out.println("Conjunto después de add(): " + conj); //Conjunto despues de add(): [4.3, 6.66, 7.0, 3.3]

        System.out.println("Tamaño del conjunto: " + conj.size());// 2º MÉTODO Collection: size(). DEVUELVE el número de elementos
                                                                //size() te dice cuántos elementos hay actualmente en la colección
                                                                //run:Tamaño del conjunto: 4


        System.out.println("¿El conjunto contiene 4.3? " + conj.contains(4.3));// 3º MÉTODO Collection: contains(Object o)
                                                                                //COMPRUEBA si contiene un elemento específico
                                                                                //Devuelve true si el elemento está en la colección, false si no.
                                                                                //run:¿El conjunto contiene 4.3? true
        Set<Integer> c1 = new HashSet<>();// Creamos dos conjuntos de enteros
        c1.add(7);
        c1.add(4);
        c1.add(3);

        Set<Integer> c2 = new HashSet<>();
        c2.add(8);
        c2.add(2);
        c2.add(3);

        Set<Integer> interseccion = new HashSet<>(c1); // 4º MÉTODO Collection: retainAll(Collection<?> c) INTERSECCIÓN de conjuntos
                                                       //Mantiene solo los elementos que están en ambas colecciones.

        interseccion.retainAll(c2);
        System.out.println("Intersección de c1 y c2: " + interseccion);

        System.out.println("c1 --> " + c1);
        System.out.println("c2 --> " + c2);
        //run:Intersección de c1 y c2: [3]
        
        

        Set<Integer> union = new HashSet<>(c1);// 5º MÉTODO Collection: addAll(Collection<? extends E> c) UNIÓN de conjuntos
                                                //Añade todos los elementos de otra colección, sin duplicados en Set.
        union.addAll(c2);
        System.out.println("Unión de c1 y c2: " + union);
        //run:c1 --> [3, 4, 7]
        //c2 --> [2, 3, 8]
        //Unión de c1 y c2: [2, 3, 4, 7, 8]

        Set<Integer> diferencia = new HashSet<>(c1);// 6º MÉTODO Collection: removeAll(Collection<?> c)  DIFERENCIA de conjuntos
                                                    //run:Diferencia de c1 y c2 (c1 - c2): [4, 7]
        diferencia.removeAll(c2);
        System.out.println("Diferencia de c1 y c2 (c1 - c2): " + diferencia);
        
        
        //Haciendolo al revés la diferencia saldría [2,8]
        Set<Integer> dif = new HashSet<>(c2);// 6º MÉTODO Collection: removeAll(Collection<?> c)  DIFERENCIA de conjuntos
                                                    //run:Diferencia de c1 y c2 (c1 - c2): [2, 8]
        dif.removeAll(c1);
        System.out.println("Diferencia de c1 y c2 (c2 - c1): " + dif);
        
        
        

        System.out.println("¿c1 está vacío? " + c1.isEmpty()); // 7º MÉTODO Collection: isEmpty()  COMPRUEBA si un conjunto está vacío
                                                                //RUN: ¿c1 está vacío? false
                                                                
        System.out.println("¿c2 está vacío? " + c2.isEmpty()); // 7º MÉTODO Collection: isEmpty()  COMPRUEBA si un conjunto está vacío
                                                                //RUN: ¿c2 está vacío? false

        System.out.println("¿c1 contiene todos los elementos de diferencia? " + c1.containsAll(diferencia));// 8º MÉTODO Collection: containsAll(Collection<?> c)
                                //COMPRUEBA si c1 contiene todos los elementos de diferencia
                               //RUN:¿c1 contiene todos los elementos de diferencia? true
                                                                                                        
        System.out.println("¿c2 contiene todos los elementos de diferencia? " + c2.containsAll(diferencia));// 8º MÉTODO Collection: containsAll(Collection<?> c)
                                             //COMPRUEBA si c1 contiene todos los elementos de diferencia
        
                                            //RUN:¿c2 contiene todos los elementos de diferencia? false
        c1.clear();// 9º MÉTODO Collection: clear() → VACÍA, LIMPIA el conjunto
        System.out.println("c1 después de clear(): " + c1);
        //run:c1 después de clear(): []
                                                                                                       
                                                                                                       
                                                                                                       
        c2.clear();// 9º MÉTODO Collection: clear() → VACÍA, LIMPIA el conjunto
        System.out.println("c2 después de clear(): " + c2);
        //run:c2 después de clear(): []

        
        
        
        
        conj.remove(7.0);// 10º MÉTODO Collection: remove(Object o) → ELIMINA un elemento específico
        System.out.println("Conjunto después de eliminar 7.0: " + conj);
        //run:conj después de eliminar 7.0: [4.3, 6.66, 3.3]
        

    }
}

//METODO 1 Add (E e) Poner un objeto dentro de una caja.
//METODO 2 size() Contar cuántos objetos hay dentro de la caja.
//METODO 3 contains(Object o)“¿Está este objeto dentro de la caja?”
//METODO 4 retainAll(Collection<?> c) Intersección ,  De dos cajas, quedarse solo con los objetos que están en ambas.
//METODO 5 addAll(Collection<? extends E> c) Unión, Mezclar dos cajas de objetos en una sola. 
//METODO 6 removeAll(Collection<?> c), diferencia, Quitar de tu caja (c1)todos los objetos que también están en otra caja(c2)
// es decir, un numero del c1 se repite en c2? se quita de c1 y te quedas con los que no se repite en c2.
//METODO 7 isEmpty()Devuelve true si la colección no tiene elementos. “¿Está la caja vacía?”
//METODO 8 containsAll(Collection<?> c) “¿Mi caja (C1)tiene todos los objetos de esta otra caja (C2)?”
//METODO 9 clear();VACÍA TOTALMENTE LA CAJA 
//METODO 10 remove(Object o), elimina UN elemento del conjunto
