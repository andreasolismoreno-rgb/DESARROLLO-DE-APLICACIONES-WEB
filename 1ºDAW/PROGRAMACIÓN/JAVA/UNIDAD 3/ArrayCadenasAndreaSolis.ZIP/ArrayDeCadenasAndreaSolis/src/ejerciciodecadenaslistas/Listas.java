package ejerciciodecadenaslistas;
import java.util.ArrayList;
import java.util.List;
public class Listas {

    public static void main(String[] args) {

        // Lista original
        List<String> cadenas = List.of(
                "   hola  ",
                " Pepe  ",
                "Jose Luis",
                "Ana",
                "  Juan    Ramón  ",
                "Betis"
        );

        // Pasar a minúsculas
        List<String> cadenasMinus = aMinusculas(cadenas);
        System.out.println("En minúsculas: " + cadenasMinus);

        // Quitar espacios
        List<String> cadenasLimpias = limpiaBlancos(cadenas);
        System.out.println("Sin espacios: " + cadenasLimpias);

        // Contar vocales una sola palabra
        System.out.println("Vocales de 'Mundial' => " + contarVocales("Mundial"));

        // Contar vocales de toda la lista
        System.out.println("Vocales de cada cadena => " + numVocales(cadenas));

        // Contar letras de un texto
        System.out.println("Letras de 'Pepe@3#' => " + cuentaLetras("Pepe@3#"));

        // Cadena con más vocales
        System.out.println("Más vocales => " + masVocales(cadenas));

        // Cadena con más letras
        System.out.println("Más letras => " + masLetras(cadenas));

        // Cadena con más números
        System.out.println("Más números => " + masNumeros(cadenas));

        // Cadena con más alfanuméricos
        System.out.println("Más alfanuméricos => " + masAlfanumericos(cadenas));

        // Contraseñas válidas
        System.out.println("¿Es válida 'Pepe123'? => " + esContrasenaValida("Pepe123"));
        System.out.println("¿Es válida 'A3@hola'? => " + esContrasenaValida("A3@hola"));
    }

    // MÉTODOS fuera del main

    // Pasar todas las cadenas a minúsculas
    public static List<String> aMinusculas(List<String> cadenas) {
        List<String> res = new ArrayList<>();
        for (String cad : cadenas) {
            res.add(cad.toLowerCase());
        }
        return res;
    }

    // Quitar espacios al inicio y fin
    public static List<String> limpiaBlancos(List<String> cadenas) {
        List<String> res = new ArrayList<>();
        for (String cad : cadenas) {
            res.add(cad.trim());
        }
        return res;
    }

    // Contar vocales en una sola cadena
    public static int contarVocales(String cad) {
        int cont = 0;
        cad = cad.toLowerCase(); // Para no fallar si hay mayúsculas
        for (int i = 0; i < cad.length(); i++) {
            char c = cad.charAt(i);
            if ("aeiou".indexOf(c) != -1) {
                cont++;
            }
        }
        return cont;
    }

    // Contar vocales de toda la lista
    public static List<Integer> numVocales(List<String> cadenas) {
        List<Integer> res = new ArrayList<>();
        for (String cad : cadenas) {
            res.add(contarVocales(cad));
        }
        return res;
    }

    // Contar letras de una cadena
    public static int cuentaLetras(String cad) {
        int cont = 0;
        for (int i = 0; i < cad.length(); i++) {
            if (Character.isLetter(cad.charAt(i))) {
                cont++;
            }
        }
        return cont;
    }

    // Contar números de una cadena
    public static int cuentaNumeros(String cad) {
        int cont = 0;
        for (int i = 0; i < cad.length(); i++) {
            if (Character.isDigit(cad.charAt(i))) {
                cont++;
            }
        }
        return cont;
    }

    // Contar letras + números
    public static int cuentaAlfanumericos(String cad) {
        int cont = 0;
        for (int i = 0; i < cad.length(); i++) {
            if (Character.isLetterOrDigit(cad.charAt(i))) {
                cont++;
            }
        }
        return cont;
    }

    // Cadena con más vocales
    public static String masVocales(List<String> cadenas) {
        String res = cadenas.get(0);
        for (String cad : cadenas) {
            if (contarVocales(cad) > contarVocales(res)) {
                res = cad;
            }
        }
        return res;
    }

    // Cadena con más letras
    public static String masLetras(List<String> cadenas) {
        String res = cadenas.get(0);
        for (String cad : cadenas) {
            if (cuentaLetras(cad) > cuentaLetras(res)) {
                res = cad;
            }
        }
        return res;
    }

    // Cadena con más números
    public static String masNumeros(List<String> cadenas) {
        String res = cadenas.get(0);
        for (String cad : cadenas) {
            if (cuentaNumeros(cad) > cuentaNumeros(res)) {
                res = cad;
            }
        }
        return res;
    }

    // Cadena con más caracteres alfanuméricos
    public static String masAlfanumericos(List<String> cadenas) {
        String res = cadenas.get(0);
        for (String cad : cadenas) {
            if (cuentaAlfanumericos(cad) > cuentaAlfanumericos(res)) {
                res = cad;
            }
        }
        return res;
    }

    // Validar contraseña
    public static boolean esContrasenaValida(String cad) {

        if (cad.length() < 7) {
            return false;
        }

        boolean tieneMayus = false;
        boolean tieneNum = false;
        boolean tieneEspecial = false;

        for (int i = 0; i < cad.length(); i++) {
            char c = cad.charAt(i);

            if (Character.isUpperCase(c)) tieneMayus = true;
            if (Character.isDigit(c)) tieneNum = true;
            if (!Character.isLetterOrDigit(c)) tieneEspecial = true;
        }

        return tieneMayus && tieneNum && tieneEspecial;
    }
}