package utilidadcollections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class EjercicioutilidadcollectionS {
        
    public static void main(String[] args) {

     ejemploMax();
        ejemploMin();
        ejemploSort();
        ejemploShuffle();
        ejemploReverse();
        ejemploFrequency();
        ejemploFill();
        ejemploCopy();
        ejemploRotate();
        ejemploSwap();
        ejemploReplaceAll();
        ejemploNCopies();
        ejemploUnmodifiableList();
    }

    // 1. Collections.max() - Devuelve el mayor elemento de la lista
    public static void ejemploMax() {
        List<Integer> lista = Arrays.asList(1, 8, 22, 3);
        int mayor = Collections.max(lista);
        System.out.println("Ejemplo max(): " + mayor);
    }

    // 2. Collections.min() - Devuelve el menor elemento de la lista
    public static void ejemploMin() {
        List<Integer> lista = Arrays.asList(1, 8, 22, 3);
        int menor = Collections.min(lista);
        System.out.println("Ejemplo min(): " + menor);
    }

    // 3. Collections.sort() - Ordena la lista de menor a mayor
    public static void ejemploSort() {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 8, 22, 3));
        Collections.sort(lista);
        System.out.println("Ejemplo sort(): " + lista);
    }

    // 4. Collections.shuffle() - Mezcla los elementos de la lista aleatoriamente
    public static void ejemploShuffle() {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 8, 22, 3));
        Collections.shuffle(lista);
        System.out.println("Ejemplo shuffle(): " + lista);
    }

    // 5. Collections.reverse() - Invierte el orden de la lista
    public static void ejemploReverse() {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 8, 22, 3));
        Collections.reverse(lista);
        System.out.println("Ejemplo reverse(): " + lista);
    }

    // 6. Collections.frequency() - Cuenta cuántas veces aparece un elemento
    public static void ejemploFrequency() {
        List<Integer> lista = Arrays.asList(1, 2, 3, 2, 2, 4);
        int freq = Collections.frequency(lista, 2);
        System.out.println("Ejemplo frequency(): El número 2 aparece " + freq + " veces");
    }

    // 7. Collections.fill() - Rellena la lista con un valor
    public static void ejemploFill() {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 2, 3, 4));
        Collections.fill(lista, 0);
        System.out.println("Ejemplo fill(): " + lista);
    }

    // 8. Collections.copy() - Copia elementos de una lista a otra
    public static void ejemploCopy() {
        List<Integer> origen = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> destino = new ArrayList<>(Arrays.asList(0, 0, 0, 0, 0));
        Collections.copy(destino, origen);
        System.out.println("Ejemplo copy(): " + destino);
    }

    // 9. Collections.rotate() - Rota los elementos de la lista
    public static void ejemploRotate() {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        Collections.rotate(lista, 2);
        System.out.println("Ejemplo rotate(): " + lista);
    }

    // 10. Collections.swap() - Intercambia dos elementos en la lista
    public static void ejemploSwap() {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        Collections.swap(lista, 0, 2);
        System.out.println("Ejemplo swap(): " + lista);
    }

    // 11. Collections.replaceAll() - Reemplaza todas las ocurrencias de un valor
    public static void ejemploReplaceAll() {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 2, 3, 2, 2, 4));
        Collections.replaceAll(lista, 2, 99);
        System.out.println("Ejemplo replaceAll(): " + lista);
    }

    // 12. Collections.nCopies() - Crea una lista inmutable con n copias de un valor
    public static void ejemploNCopies() {
        List<String> lista = Collections.nCopies(5, "Hola");
        System.out.println("Ejemplo nCopies(): " + lista);
    }

    // 13. Collections.unmodifiableList() - Lista solo lectura (inmodificable)
    public static void ejemploUnmodifiableList() {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        List<Integer> inmodificable = Collections.unmodifiableList(lista);
        System.out.println("Ejemplo unmodifiableList(): " + inmodificable);
        // inmodificable.add(10); // Esto lanzaría UnsupportedOperationException
    }

}

