package ejercicio;

import java.util.SortedSet;
import java.util.TreeSet;

public class Ejercicio {
    public static void main(String[] args) {

    // Creamos un SortedSet que ordena automáticamente
        SortedSet<Integer> numeros = new TreeSet<>();

        //add()Añade un elemento manteniendo orden
        numeros.add(2);  // añadido
        numeros.add(5);   // añadido
        numeros.add(1);   // añadido
        numeros.add(10);   // añadido

        System.out.println("SortedSet (ordenado): " + numeros);
        // run: [1, 2, 5, 10]

        // first() devuelve el primer elemento (el menor)
        System.out.println("Primer elemento: " + numeros.first());
        //Run: 1     YO VOY ARRASTRANDO ESA LISTA HASTA CREAR UNA NUEVA

        // last()  devuelve el último elemento (el mayor)
        System.out.println("Último elemento: " + numeros.last());
        //run: 10

        // headSet(x)  devuelve los elementos menores que x
        SortedSet<Integer> menoresQue5 = numeros.headSet(5);
        System.out.println("Menores que 5: " + menoresQue5); // RUN: [1, 2]

        // tailSet(x)  devuelve los elementos mayores o iguales que x
        SortedSet<Integer> mayoresOIgualesA5 = numeros.tailSet(5);
        System.out.println("Mayores o iguales que 5: " + mayoresOIgualesA5); // [10]

        // subSet(a, b)  devuelve los elementos entre a (incluido) y b (excluido)
        SortedSet<Integer> rango = numeros.subSet(2, 10);
        System.out.println("Entre 2 y 10: " + rango); // RUN: [2, 5]

        // comparator()  devuelve el comparador si usa uno personalizado
        // Si es null, usa el orden "natural" de los números
        System.out.println("Comparador: " + numeros.comparator()); //  orden natural, por tanto null
    }
}