package ejercicios;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Ejercicios {
     //  Método recursivo de los ejercicios 35 y 37 
    public static int factorial(int n){ 
        return n <= 1 ? 1 : n * factorial(n - 1); 
    } // Factorial recursivo
    
    public static int potencia(int a, int b){ 
        return b == 0 ? 1 : a * potencia(a, b - 1);
    } // Potencia recursiva

    public static void main(String[] args) { //el método principal
        Scanner sc = new Scanner(System.in);
        //Ejercicios de 1 al 40 en un mismo main.
        
        // 1. Números del 1 al 10
        { 
            for(int i=1;i<=10;i++) System.out.println(i); // recorro del 1 al 10 y los muestro
        }

        // 2. Números del 10 al 1
        {
            for(int i=10;i>=1;i--) System.out.println(i); // bajo desde 10 hasta 1
        }

        // 3. Pares del 1 al 20
        {
            for(int i=2;i<=20;i+=2) System.out.print(i+" "); // muestro solo pares sumando de 2 en 2
            System.out.println();
        }

        // 4. Impares del 1 al 20
        {
            for(int i=1;i<=20;i+=2) System.out.print(i+" "); // muestro solo impares
            System.out.println();
        }

        // 5. Positivo, negativo o cero
        {
            System.out.println("Introduce un número:");
            int n = sc.nextInt();
            if(n>0) System.out.println("positivo");
            else if(n<0) System.out.println("negativo");
            else System.out.println("cero");
        }

        // 6. Par o impar
        {
            System.out.println("Introduce un número:");
            int n = sc.nextInt();
            if(n%2==0) System.out.println("par");
            else System.out.println("impar");
        }

        // 7. Mayor de dos números
        {
            System.out.println("Introduce el primer número:");
            int a = sc.nextInt();
            System.out.println("Introduce el segundo número:");
            int b = sc.nextInt();
            if(a>b) System.out.println(a);
            else if(b>a) System.out.println(b);
            else System.out.println("iguales");
        }

        // 8. Menor de dos números
        {
            System.out.println("Introduce el primer número:");
            int a = sc.nextInt();
            System.out.println("Introduce el segundo número:");
            int b = sc.nextInt();
            if(a<b) System.out.println(a);
            else if(b<a) System.out.println(b);
            else System.out.println("iguales");
        }

        // 9. Mayor de tres números
        {
            System.out.println("Introduce el primer número:");
            int a = sc.nextInt();
            System.out.println("Introduce el segundo número:");
            int b = sc.nextInt();
            System.out.println("Introduce el tercer número:");
            int c = sc.nextInt();
            int m=a;
            if(b>m) m=b;
            if(c>m) m=c;
            System.out.println(m);
        }

        // 10. Menor de tres números
        {
            System.out.println("Introduce el primer número:");
            int a = sc.nextInt();
            System.out.println("Introduce el segundo número:");
            int b = sc.nextInt();
            System.out.println("Introduce el tercer número:");
            int c = sc.nextInt();
            int m=a;
            if(b<m) m=b;
            if(c<m) m=c;
            System.out.println(m);
        }

        // 11. Múltiplo de 3
        {
            System.out.println("Introduce un número:");
            int n = sc.nextInt();
            if(n%3==0) System.out.println("multiplo");
            else System.out.println("no multiplo");
        }

        // 12. Día de la semana
        {
            System.out.println("Introduce un número de día (1-7):");
            int d = sc.nextInt();
            switch(d){
                case 1:System.out.println("Lunes");break;
                case 2:System.out.println("Martes");break;
                case 3:System.out.println("Miércoles");break;
                case 4:System.out.println("Jueves");break;
                case 5:System.out.println("Viernes");break;
                case 6:System.out.println("Sábado");break;
                case 7:System.out.println("Domingo");break;
                default:System.out.println("Día no válido");
            }
        }

        // 13. Menú simple
        {
            System.out.println("Introduce la opción (1:Hola, 2:Adiós, 3:Salir):");
            int o = sc.nextInt();
            switch(o){
                case 1:System.out.println("Hola");break;
                case 2:System.out.println("Adiós");break;
                case 3:System.out.println("Salir");break;
            }
        }

        // 14. Nota aprobada o suspensa
        {
            System.out.println("Introduce la nota:");
            double n = sc.nextDouble();
            if(n>=5) System.out.println("Aprobado");
            else System.out.println("Suspenso");
        }

        // 15. Suma 1 a n (for)
        {
            System.out.println("Introduce un número:");
            int n = sc.nextInt(), s=0;
            for(int i=1;i<=n;i++) s+=i;
            System.out.println(s);
        }

        // 16. Suma 1 a n (while)
        {
            System.out.println("Introduce un número:");
            int n = sc.nextInt(), s=0, i=1;
            while(i<=n){ s+=i; i++; }
            System.out.println(s);
        }

        // 17. Tabla del 7
        {
            for(int i=1;i<=10;i++) System.out.println("7 x "+i+" = "+(7*i));
        }

        // 18. Tablas 1 al 5
        {
            for(int n=1;n<=5;n++)
                for(int i=1;i<=10;i++)
                    System.out.println(n+" x "+i+" = "+(n*i));
        }

        // 19. Línea de asteriscos
        {
            System.out.println("Introduce el número de asteriscos:");
            int n = sc.nextInt();
            for(int i=0;i<n;i++) System.out.print("*");
            System.out.println();
        }

        // 20. Cuadrado de asteriscos
        {
            System.out.println("Introduce el tamaño del cuadrado:");
            int n = sc.nextInt();
            for(int i=0;i<n;i++){
                for(int j=0;j<n;j++) System.out.print("*");
                System.out.println();
            }
        }

        // 21. Media de 5 números
        {
            double s=0;
            for(int i=1;i<=5;i++){
                System.out.println("Introduce el número "+i+":");
                s+=sc.nextDouble();
            }
            System.out.println("Media: "+(s/5));
        }

        // 22. Contar negativos
        {
            int c=0;
            for(int i=1;i<=10;i++){
                System.out.println("Introduce el número "+i+":");
                if(sc.nextInt()<0) c++;
            }
            System.out.println("Cantidad de negativos: "+c);
        }

        // 23. Contar positivos
        {
            int c=0;
            for(int i=1;i<=10;i++){
                System.out.println("Introduce el número "+i+":");
                if(sc.nextInt()>0) c++;
            }
            System.out.println("Cantidad de positivos: "+c);
        }

        // 24. Contar ceros
        {
            int c=0;
            for(int i=1;i<=10;i++){
                System.out.println("Introduce el número "+i+":");
                if(sc.nextInt()==0) c++;
            }
            System.out.println("Cantidad de ceros: "+c);
        }

        // 25. Suma de positivos
        {
            int s=0;
            for(int i=1;i<=10;i++){
                System.out.println("Introduce el número "+i+":");
                int n = sc.nextInt();
                if(n>0) s+=n;
            }
            System.out.println("Suma de positivos: "+s);
        }

        // 26. Suma de negativos
        {
            int s=0;
            for(int i=1;i<=10;i++){
                System.out.println("Introduce el número "+i+":");
                int n = sc.nextInt();
                if(n<0) s+=n;
            }
            System.out.println("Suma de negativos: "+s);
        }

        // 27. Suma hasta 0
        {
            int s=0, n;
            do{
                System.out.println("Introduce un número (0 para terminar):");
                n = sc.nextInt();
                s+=n;
            }while(n!=0);
            System.out.println("Suma total: "+s);
        }

        // 28. Contar números hasta 0
        {
            int c=0, n;
            do{
                System.out.println("Introduce un número (0 para terminar):");
                n = sc.nextInt();
                if(n!=0) c++;
            }while(n!=0);
            System.out.println("Cantidad de números introducidos: "+c);
        }

        // 29. Divisores de un número
        {
            System.out.println("Introduce un número:");
            int n = sc.nextInt();
            System.out.print("Divisores: ");
            for(int i=1;i<=n;i++)
                if(n%i==0) System.out.print(i+" ");
            System.out.println();
        }

        // 30. Número primo
        {
            System.out.println("Introduce un número:");
            int n = sc.nextInt();
            boolean primo=true;
            for(int i=2;i<n;i++)
                if(n%i==0) primo=false;
            System.out.println(primo?"primo":"no primo");
        }

        // 31. Número secreto
        {
            int secreto=15;
            for(int i=3;i>0;i--){
                System.out.println("Introduce un número (Intentos restantes: "+i+"): ");
                int n = sc.nextInt();
                if(n==secreto){ System.out.println("Correcto"); break; }
                else System.out.println("Incorrecto");
            }
            System.out.println("Fin del juego");
        }

        // 32. Menú operaciones
        {
            System.out.println("Introduce el primer número:");
            int a = sc.nextInt();
            System.out.println("Introduce el segundo número:");
            int b = sc.nextInt();
            System.out.println("Introduce la opción (1:Suma, 2:Resta, 3:Multiplicación, 4:División):");
            int o = sc.nextInt();
            switch(o){
                case 1:System.out.println(a+b);break;
                case 2:System.out.println(a-b);break;
                case 3:System.out.println(a*b);break;
                case 4:
                    if(b==0) System.out.println("No se puede dividir entre 0");
                    else System.out.println(a/b);
                    break;
            }
        }

        // 33. Evitar división entre 0
        {
            System.out.println("Introduce el numerador:");
            int a = sc.nextInt();
            System.out.println("Introduce el denominador:");
            int b = sc.nextInt();
            if(b==0) System.out.println("No se puede dividir entre 0");
            else System.out.println(a/b);
        }

        // 34. Factorial iterativo
        {
            System.out.println("Introduce un número:");
            int n = sc.nextInt(), f=1;
            for(int i=1;i<=n;i++) f*=i;
            System.out.println("Factorial: "+f);
        }

        // 35. Factorial recursivo
        {
            System.out.println("Introduce un número:");
            int n = sc.nextInt();
            System.out.println("Factorial: "+factorial(n));
        }

        // 36. Potencia a^b (bucle)
        {
            System.out.println("Introduce la base:");
            int a = sc.nextInt();
            System.out.println("Introduce el exponente:");
            int b = sc.nextInt();
            int r=1;
            for(int i=0;i<b;i++) r*=a;
            System.out.println("Resultado: "+r);
        }

        // 37. Potencia recursiva
        {
            System.out.println("Introduce la base:");
            int a = sc.nextInt();
            System.out.println("Introduce el exponente:");
            int b = sc.nextInt();
            System.out.println("Resultado: "+potencia(a,b));
        }

        // 38. Rectángulo
        {
            System.out.println("Introduce la altura:");
            int h = sc.nextInt();
            System.out.println("Introduce la anchura:");
            int w = sc.nextInt();
            for(int i=0;i<h;i++){
                for(int j=0;j<w;j++) System.out.print("*");
                System.out.println();
            }
        }

        // 39. Triángulo creciente
        {
            System.out.println("Introduce la altura del triángulo:");
            int n = sc.nextInt();
            for(int i=1;i<=n;i++){
                for(int j=0;j<i;j++) System.out.print("*");
                System.out.println();
            }
        }

        // 40. Triángulo invertido
        {
            System.out.println("Introduce la altura del triángulo:");
            int n = sc.nextInt();
            for(int i=n;i>0;i--){
                for(int j=0;j<i;j++) System.out.print("*");
                System.out.println();
            }
        }
        //  Ejercicio del 41 al 40, requieren métodos listas fuera del main.
        List<Integer> lista = new ArrayList<>();
        lista.add(4); lista.add(6); lista.add(8); lista.add(6); lista.add(10); lista.add(6);
        lista.add(-3); lista.add(4); lista.add(-1);
        
        System.out.println("Lista: " + lista);
        System.out.println("Ejercicio 41. Apariciones del 6: " + ejercicio41(lista, 6));
        System.out.println("Ejercicio 42. Mayor: " + ejercicio42(lista));
        System.out.println("Ejercicio 43. Menor: " + ejercicio43(lista));
        System.out.println("Ejercicio 44. Suma posiciones pares: " + ejercicio44(lista));
        System.out.println("Ejercicio 45. Suma posiciones impares: " + ejercicio45(lista));
        System.out.println("Ejercicio 46. Cantidad de pares: " + ejercicio46(lista));
        System.out.println("Ejercicio 47. Cantidad de impares: " + ejercicio47(lista));
        System.out.println("Ejercicio 48. Media de todos: " + ejercicio48(lista));
        System.out.println("Ejercicio 49. Media de positivos: " + ejercicio49(lista));
        System.out.println("Ejercicio 50. Posición del 7: " + ejercicio50(lista, 7));
        
    }
            
    // 41. Apariciones de un dígito
    public static int ejercicio41(List<Integer> lista, int numero){
        int cont = 0;
        for(int e : lista){
            if(e == numero) cont++;
        }
        return cont;
    }
    
    // 42. Mayor de la lista
    public static int ejercicio42(List<Integer> lista){
        int mayor = lista.get(0);
        for(int e : lista){
            if(e > mayor) mayor = e;
        }
        return mayor;
    }
    
    // 43. Menor de la lista
    public static int ejercicio43(List<Integer> lista){
        int menor = lista.get(0);
        for(int e : lista){
            if(e < menor) menor = e;
        }
        return menor;
    }
    
    // 44. Suma posiciones pares
    public static int ejercicio44(List<Integer> lista){
        int suma = 0;
        for(int i = 0; i < lista.size(); i += 2){
            suma += lista.get(i);
        }
        return suma;
    }
    
    // 45. Suma posiciones impares
    public static int ejercicio45(List<Integer> lista){
        int suma = 0;
        for(int i = 1; i < lista.size(); i += 2){
            suma += lista.get(i);
        }
        return suma;
    }
    
    // 46. Contar pares
    public static int ejercicio46(List<Integer> lista){
        int cont = 0;
        for(int e : lista){
            if(e % 2 == 0) cont++;
        }
        return cont;
    }
    
    // 47. Contar impares
    public static int ejercicio47(List<Integer> lista){
        int cont = 0;
        for(int e : lista){
            if(e % 2 != 0) cont++;
        }
        return cont;
    }
    
    // 48. Media de todos
    public static double ejercicio48(List<Integer> lista){
        double suma = 0;
        for(int e : lista) suma += e;
        return lista.size() > 0 ? suma / lista.size() : 0;
    }
    
    // 49. Media solo positivos
    public static double ejercicio49(List<Integer> lista){
        double suma = 0;
        int cont = 0;
        for(int e : lista){
            if(e > 0){ suma += e; cont++; }
        }
        return cont > 0 ? suma / cont : 0;
    }
    
    // 50. Índice de un número
    public static int ejercicio50(List<Integer> lista, int numero){
        for(int i = 0; i < lista.size(); i++){
            if(lista.get(i) == numero) return i;
        }
        return -1;
    }
    
}   


       