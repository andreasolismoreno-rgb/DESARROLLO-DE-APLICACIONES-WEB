
package modelo;


public class Persona {
    private String nombre;
    private String apellidos;
    private int edad;
    private double altura;

    public Persona(String nombre, String apellidos, int edad, double altura) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
        this.altura = altura;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public double getAltura() {
        return altura;
    }

    @Override
    public String toString() {
        return nombre + " " + apellidos +
               " | Edad: " + edad +
               " | Altura: " + altura;
    }
}
