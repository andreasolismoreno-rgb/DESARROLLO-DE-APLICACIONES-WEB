
package io;

import modelo.Persona;
import java.io.*;
import java.util.*;
import java.util.function.Function;

public class LectorFicheros {
    public static List<String> leerCadenas(String ruta) {
        List<String> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                lista.add(linea);
            }
        } catch (IOException e) {
            System.out.println("Error cadenas");
        }
        return lista;
    }

    public static List<Integer> leerEnteros(String ruta) {
        List<Integer> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                lista.add(Integer.parseInt(linea));
            }
        } catch (Exception e) {
            System.out.println("Error enteros");
        }
        return lista;
    }

    public static List<Double> leerRealesCsvEnLinea(String ruta) {
        List<Double> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea = br.readLine();
            if (linea != null) {
                String[] partes = linea.split(",");
                for (String p : partes) {
                    lista.add(Double.parseDouble(p));
                }
            }
        } catch (Exception e) {
            System.out.println("Error reales");
        }
        return lista;
    }

    public static List<Persona> leerPersonas(String ruta) {
        List<Persona> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] p = linea.split(",");
                lista.add(new Persona(
                        p[0],
                        p[1],
                        Integer.parseInt(p[2]),
                        Double.parseDouble(p[3])
                ));
            }
        } catch (Exception e) {
            System.out.println("Error personas");
        }
        return lista;
    }

    // Método genérico
    public static <T> List<T> leerGenerico(String ruta, Function<String, T> f) {
        List<T> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                lista.add(f.apply(linea));
            }
        } catch (IOException e) {
            System.out.println("Error genérico");
        }
        return lista;
    }
}
