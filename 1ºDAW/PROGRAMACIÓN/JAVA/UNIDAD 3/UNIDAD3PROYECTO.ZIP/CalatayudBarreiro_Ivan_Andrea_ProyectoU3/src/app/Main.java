
package app;

import io.LectorFicheros;
import modelo.Persona;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        String ruta = "datos/";

        List<String> cadenas = LectorFicheros.leerCadenas(ruta + "cadenas.txt");
        List<Integer> enteros = LectorFicheros.leerEnteros(ruta + "enteros.txt");
        List<Double> reales = LectorFicheros.leerRealesCsvEnLinea(ruta + "reales.csv");
        List<Persona> personas = LectorFicheros.leerPersonas(ruta + "personas.csv");

        System.out.println("Cadenas: " + cadenas);
        System.out.println("Enteros: " + enteros);
        System.out.println("Reales: " + reales);
        System.out.println("Personas:");
        personas.forEach(System.out::println);

        // Genérico
        List<Integer> enterosGen = LectorFicheros.leerGenerico(
                ruta + "enteros.txt",
                Integer::parseInt
        );
        System.out.println("Enteros genéricos: " + enterosGen);
    }
}