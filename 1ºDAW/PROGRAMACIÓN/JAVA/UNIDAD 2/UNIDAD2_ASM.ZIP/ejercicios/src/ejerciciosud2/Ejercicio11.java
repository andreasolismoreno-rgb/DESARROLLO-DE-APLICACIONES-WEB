package ejerciciosud2;
import java.util.Scanner;
public class Ejercicio11 {
 //Escribe un programa que pida dos números enteros  
 //y muestre todos los números primos que
 //hay entre ellos.
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce el primer número: ");
        int inicio = sc.nextInt();

        System.out.print("Introduce el segundo número: ");
        int fin = sc.nextInt();

        // Si el primer número es mayor que el segundo, los intercambiamos
        if (inicio > fin) {
            int aux = inicio;
            inicio = fin;
            fin = aux;
        }

        boolean hayPrimos = false; // Para saber si hemos encontrado alguno

        System.out.println("Números primos entre " + inicio + " y " + fin + ":");

        // Recorremos todos los números del rango
        for (int n = inicio; n <= fin; n++) {

            if (n < 2) continue; // Los menores que 2 no son primos

            boolean esPrimo = true; // Suponemos que es primo

            // Comprobamos si tiene algún divisor
            for (int i = 2; i <= n / 2; i++) {
                if (n % i == 0) {  // Si se divide exacto, no es primo
                    esPrimo = false;
                    break; // No hace falta seguir probando
                }
            }

            // Si sigue siendo primo, lo mostramos
            if (esPrimo) {
                System.out.print(n + " ");
                hayPrimos = true;
            }
        }

        // Si no se ha mostrado ningún primo
        if (!hayPrimos) {
            System.out.println("No hay números primos en ese rango.");
        } else {
            System.out.println(); // Salto de línea final
        }
    }
}