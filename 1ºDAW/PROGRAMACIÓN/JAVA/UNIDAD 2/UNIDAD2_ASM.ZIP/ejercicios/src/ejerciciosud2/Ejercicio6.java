package ejerciciosud2;
import java.util.ArrayList;
import java.util.List;

public class Ejercicio6 {
    //Comprobación en array
    public static void main(String[] args) {
        List<Integer> lista = new ArrayList<>();
        lista.add(7);
        lista.add(4);
        lista.add(3);
        lista.add(10);
        lista.add(6);
        lista.add(7);
        System.out.println(lista);
        Integer n=3;
        boolean existe = false;
        for (int e : lista) {
            if (e == n) {
                existe = true;
                break;
            }
        }
        System.out.println(existe);
     }
    
}

