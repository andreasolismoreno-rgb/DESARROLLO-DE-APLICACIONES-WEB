package ejerciciosud2;
import java.util.Arrays;
public class Ejercicio8 {
    //Mínimo en array
    public static void main (String [] args){
        int[] arr = {7, 4, 3, 10, 6, 7};
        System.out.println("Array: " + Arrays.toString(arr));

        int min = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        System.out.println("El mínimo es: " + min);
    }
}