package ejerciciosud2;
import java.util.Arrays;
//Máximo en array
public class Ejercicio7 {

    public static void main(String[] args) {
        int[] arr = {7, 4, 3, 10, 6, 7};
        System.out.println("Array: " + Arrays.toString(arr));

        int max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        System.out.println("El máximo es: " + max);
    }
}

