package ejerciciosud2;
import java.util.Scanner;
public class Ejercicio19 {
    // Tabla de multiplicar personalizada (con control de errores)
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce el número: ");
        int num = sc.nextInt();
        System.out.print("Introduce inicio del rango: ");
        int inicio = sc.nextInt();
        System.out.print("Introduce fin del rango: ");
        int fin = sc.nextInt();
        if (inicio > fin) {
            int aux = inicio;
            inicio = fin;
            fin = aux;
        }
        System.out.println("Tabla de " + num + " desde " + inicio + " hasta " + fin);
        for (int i = inicio; i <= fin; i++) {
            if (i < 0) continue; // ignorar negativos
            System.out.println(num + " x " + i + " = " + (num * i));
        }
        sc.close();
    }
}
