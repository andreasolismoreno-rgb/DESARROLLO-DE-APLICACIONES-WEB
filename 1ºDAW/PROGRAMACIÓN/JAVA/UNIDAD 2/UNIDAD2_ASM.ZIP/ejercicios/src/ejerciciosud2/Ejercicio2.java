package ejerciciosud2;
import java.util.Scanner;

public class Ejercicio2 {
//Cálculo del mayor de tres números.
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
            System.out.print("Introduce el primer número: "); //Introduce el primer n�mero: 7
        int a = sc.nextInt();
            System.out.print("Introduce el segundo número: "); //Introduce el segundo n�mero: 3
        int b = sc.nextInt();
            System.out.print("Introduce el tercer número: "); //Introduce el segundo n�mero: 9
        int c = sc.nextInt();

            if (a >= b && a>=c) {
            System.out.println(a + " es mayor que " + a + " y " + c); 
            } else if (b > a && b>=c) {
            System.out.println(b + " es mayor que " + a + " y " + c);
            } else {
            System.out.println(c + " es mayor que " + a + " y " + b);// 9 es mayor que 7 y 3
            }
    }
 
}
