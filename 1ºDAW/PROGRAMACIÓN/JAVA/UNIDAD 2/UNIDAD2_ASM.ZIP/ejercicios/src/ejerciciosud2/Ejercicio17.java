package ejerciciosud2;
import java.util.Scanner;
public class Ejercicio17 {
//Conversor de divisas
//Crea un menú con switch que permita convertir:
//Euros → Dólares.
//Euros → Libras.
//Euros → Yenes.
//Salir.
//Los tipos de cambio los defines en constantes.
//El programa debe repetirse con do-while.
    static final double EUR_USD = 1.10;  // ejemplo: 1 EUR = 1.10 USD
    static final double EUR_GBP = 0.86;  // ejemplo: 1 EUR = 0.86 GBP
    static final double EUR_JPY = 156.00; // ejemplo: 1 EUR = 156 JPY

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("1. Euros en Dólares");
            System.out.println("2. Euros en Libras");
            System.out.println("3. Euros en Yenes");
            System.out.println("4. Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Introduce cantidad en Euros: ");
                    double eur1 = sc.nextDouble();
                    System.out.println(eur1 + " EUR = " + (eur1 * EUR_USD) + " USD");
                    break;
                case 2:
                    System.out.print("Introduce cantidad en Euros: ");
                    double eur2 = sc.nextDouble();
                    System.out.println(eur2 + " EUR = " + (eur2 * EUR_GBP) + " GBP");
                    break;
                case 3:
                    System.out.print("Introduce cantidad en Euros: ");
                    double eur3 = sc.nextDouble();
                    System.out.println(eur3 + " EUR = " + (eur3 * EUR_JPY) + " JPY");
                    break;
                case 4:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 4);
        sc.close();
    }
}