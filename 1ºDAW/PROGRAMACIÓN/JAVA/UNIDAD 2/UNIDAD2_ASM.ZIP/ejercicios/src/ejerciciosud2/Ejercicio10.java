package ejerciciosud2;
import java.util.Arrays;
public class Ejercicio10 {
    //Media en array
    public static void main(String[] args) {
        int[] arr = {7, 4, 3, 10, 6, 7};
        System.out.println("Array: " + Arrays.toString(arr));

        int suma = 0;
        for (int e : arr) suma += e;
        double media = (double) suma / arr.length;

        System.out.println("La media es: " + media);
    }
}
