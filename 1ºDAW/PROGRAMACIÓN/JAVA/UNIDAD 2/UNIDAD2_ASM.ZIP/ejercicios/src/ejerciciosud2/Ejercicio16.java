package ejerciciosud2;
import java.util.Scanner ;
public class Ejercicio16 {
 public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double suma = 0;
        int count = 0;
        double max = Double.NEGATIVE_INFINITY;
        double min = Double.POSITIVE_INFINITY;
        int aprobados = 0;
        int suspensos = 0;

        System.out.println("Introduce notas (pulsa -1 para terminar):");
        while (true) {
            System.out.print("Nota: ");
            double nota = sc.nextDouble();
            if (nota == -1) break;
            // opcional: validar rango 0-10
            suma += nota;
            count++;
            if (nota > max) max = nota;
            if (nota < min) min = nota;
            if (nota >= 5) aprobados++; else suspensos++;
        }

        if (count == 0) {
            System.out.println("No se han introducido notas.");
        } else {
            double media = suma / count;
            System.out.println("Media: " + media);
            System.out.println("Nota más alta: " + max);
            System.out.println("Nota más baja: " + min);
            System.out.println("Aprobados: " + aprobados);
            System.out.println("Suspensos: " + suspensos);
        }
        sc.close();
    }
}
