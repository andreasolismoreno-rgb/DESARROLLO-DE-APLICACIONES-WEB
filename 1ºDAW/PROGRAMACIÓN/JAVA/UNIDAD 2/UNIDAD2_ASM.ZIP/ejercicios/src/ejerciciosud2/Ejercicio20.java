package ejerciciosud2;
import java.util.Scanner;
public class Ejercicio20 {
    // Sistema de login con 3 intentos
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        final String USUARIO_CORRECTO = "admin";
        final String PASS_CORRECTA = "1234";

        int intentos = 0;
        boolean acceso = false;

        while (intentos < 3 && !acceso) {
            System.out.print("Usuario: ");
            String user = sc.next();
            System.out.print("Contraseña: ");
            String pass = sc.next();

            if (USUARIO_CORRECTO.equals(user) && PASS_CORRECTA.equals(pass)) {
                System.out.println("Acceso concedido.");
                acceso = true;
            } else {
                intentos++;
                System.out.println("Credenciales incorrectas. Intento " + intentos + " de 3.");
            }
        }

        if (!acceso) {
            System.out.println("Has fallado los 3 intentos. Acceso bloqueado.");
        }
        sc.close();
    }
}  
