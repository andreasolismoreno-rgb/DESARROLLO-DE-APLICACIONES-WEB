package ejerciciosud2;
import java.util.Scanner;
import java.util.Arrays;
public class Ejercicio9 {
    //contador en array
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] arr = {7, 4, 3, 10, 6, 7};
        System.out.println("Array: " + Arrays.toString(arr));
        System.out.print("Introduce número para contar : ");
        int n = sc.nextInt();

        int contador = 0;
        for (int e : arr) {
            if (e == n) contador++;
        }

        System.out.println("El número " + n + " aparece " + contador + " veces.");
    }
}
