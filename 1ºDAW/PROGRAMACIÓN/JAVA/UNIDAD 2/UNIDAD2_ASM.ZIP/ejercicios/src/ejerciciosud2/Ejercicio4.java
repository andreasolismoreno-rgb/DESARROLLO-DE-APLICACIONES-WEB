package ejerciciosud2;

import java.util.ArrayList;
import java.util.List;

public class Ejercicio4 {
//Suma acumulada.
    public static void main(String[] args) {
        List<Integer> lista = new ArrayList<>();
        lista.add(7);
        lista.add(4);
        lista.add(3);
        lista.add(10);
        lista.add(6);
        lista.add(7);
        System.out.println(lista);
        System.out.println(lista.size());
        System.out.println(lista.get(2));

        Integer suma = 0;
//        for (int i = 0; i< lista.size(); i++){
//            suma += lista.get (i);
//        }
        for (Integer e : lista) {
            suma += e;
        }

        System.out.println("La suma es:" + suma);

    }
}
