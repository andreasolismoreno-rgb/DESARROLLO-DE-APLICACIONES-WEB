
package ejerciciosud2;

import java.util.Scanner;

public class Ejercicio3 {
    //Tabla de multiplicar 
    public static void main (String [] args){
         Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número del que quieras saber la tabla de multiplicar: ");
        int n = sc.nextInt();

        System.out.println("Tabla de multiplicar de " + n + ":");
        for (int i = 1; i <= 10; i++) { // inicio; condición;incremento
            System.out.println(n + " x " + i + " = " + (n * i));
        }
    }
}

