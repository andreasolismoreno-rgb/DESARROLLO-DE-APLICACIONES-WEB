/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosud2;
import java.util.Scanner;
public class Ejercicio14 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número entero: ");
        int n = sc.nextInt();

        if (n < 0) {
            System.out.println(n + " no es capicúa (negativo).");
        } else {
            int original = n;
            int invertido = 0;
            while (n > 0) {
                invertido = invertido * 10 + (n % 10);
                n /= 10;
            }
            if (original == invertido) {
                System.out.println(original + " es capicúa.");
            } else {
                System.out.println(original + "  no es capicúa.");
            }
        }
    }
}