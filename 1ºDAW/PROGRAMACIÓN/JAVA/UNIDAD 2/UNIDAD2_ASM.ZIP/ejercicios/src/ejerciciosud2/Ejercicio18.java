package ejerciciosud2;
import java.util.Scanner;
public class Ejercicio18 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número: ");
        int n = sc.nextInt();

        if (n <= 0) {
            System.out.println("Introduce un número natural positivo.");
        } else {
            int suma = 0;
            for (int i = 1; i <= n / 2; i++) {
                if (n % i == 0) suma += i;
            }
            if (suma == n) {
                System.out.println(n + " es un número perfecto.");
            } else {
                System.out.println(n + " no es un número perfecto.");
            }
        }
        sc.close();
    }
}
