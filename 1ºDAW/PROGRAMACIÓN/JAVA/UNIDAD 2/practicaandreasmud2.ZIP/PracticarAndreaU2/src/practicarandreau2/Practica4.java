package practicarandreau2;
import java.util.ArrayList;
import java.util.List;
public class Practica4 {
    
    public static void main(String[] args) {
        // ==================== EJERCICIO 1 ====================
        System.out.println("=== EJERCICIO 1: Multiplos de 4 o 5 ===");
        List<Integer> lista1 = new ArrayList<>();
        for (int i = 1; i <= 15; i++) { // voy metiendo los números del 1 al 15
            lista1.add(i);
        }
        System.out.println("La lista original es: " + lista1);
        System.out.println("Los múltiplos de 4 o 5 son:");
        System.out.println(ejercicio1(lista1));

        // ==================== EJERCICIO 2 ====================
        System.out.println("\n=== EJERCICIO 2: While y suma acumulada ===");
        ejercicio2(); // no devuelve nada, solo imprime

        // ==================== EJERCICIO 3 ====================
        System.out.println("\n=== EJERCICIO 3: Cuadrados ===");
        List<Integer> cuadrados = ejercicio3(lista1);
        System.out.println("Los cuadrados de los números del 1 al 15 son: " + cuadrados);

        // ==================== EJERCICIO 4 ====================
        System.out.println("\n=== EJERCICIO 4: Números primos ===");
        System.out.println("Los primos en la lista son: " + ejercicio4(lista1));

        // ==================== EJERCICIO 5 ====================
        System.out.println("\n=== EJERCICIO 5: Factorial (recursivo) ===");
        System.out.println("Factorial de 5 = " + factorial(5));
        System.out.println("Factorial de 7 = " + factorial(7));

        // ==================== EJERCICIO 6 ====================
        System.out.println("\n=== EJERCICIO 6: Suma alterna recursiva ===");
        System.out.println("sumaAlterna(5) = " + sumaAlterna(5));
        System.out.println("sumaAlterna(10) = " + sumaAlterna(10));

        // ==================== EJERCICIO 7 ====================
        System.out.println("\n=== EJERCICIO 7: Switch - Día de la semana ===");
        Integer dia = 3; // podría ser cualquier número del 1 al 7
        System.out.println("El día " + dia + " es " + ejercicio7(dia));

        // ==================== EJERCICIO 8 ====================
        System.out.println("\n=== EJERCICIO 8: Función misteriosa ===");
        for (Integer n : lista1) {
            System.out.println("Número original: " + n + " → Resultado misterioso: " + misteriosa(n));
        }

        // ==================== EJERCICIO 9 ====================
        System.out.println("\n=== EJERCICIO 9: Rotar lista ===");
        List<Integer> lista2 = new ArrayList<>();
        for (int i = 1; i <= 8; i++) {
            lista2.add(i);
        }
        System.out.println("Antes: " + lista2);
        System.out.println("Después: " + rotarLista(lista2));

        // ==================== EJERCICIO 10 ====================
        System.out.println("\n=== EJERCICIO 10: Recursividad Final Boss ===");
        for (int i = 0; i <= 10; i++) {
            System.out.println("f(" + i + ") = " + f(i));
        }
    }

    // ==================== FUNCIONES ====================

    // Ejercicio 1: Múltiplos de 4 o 5
    public static List<Integer> ejercicio1(List<Integer> lista) {
        List<Integer> res = new ArrayList<>();
        for (Integer e : lista) { // recorro cada número
            if (e % 4 == 0 || e % 5 == 0) { // si es múltiplo de 4 o 5
                res.add(e); // lo añado a la lista resultado
            }
        }
        System.out.println("Cantidad de números que cumplen: " + res.size());
        return res;
    }

    // Ejercicio 2: While y suma acumulada
    public static void ejercicio2() {
        Integer i = 1;
        Integer suma = 0;
        while (i <= 10) { // mientras no llegue a 10
            suma = suma + i; // sumo el actual
            System.out.println("Hasta " + i + " la suma es " + suma);
            i++; // incremento el contador
        }
    }

    // Ejercicio 3: Cuadrados
    public static List<Integer> ejercicio3(List<Integer> lista) {
        List<Integer> res = new ArrayList<>();
        for (Integer e : lista) { // recorro cada número
            res.add(e * e); // lo elevo al cuadrado y lo añado
        }
        return res;
    }

    // Ejercicio 4: Números primos
    public static List<Integer> ejercicio4(List<Integer> lista) {
        List<Integer> primos = new ArrayList<>();
        for (Integer n : lista) {
            if (esPrimo(n)) { // si es primo
                primos.add(n);
            }
        }
        return primos;
    }

    // Función auxiliar para comprobar si un número es primo
    public static boolean esPrimo(Integer n) {
        if (n <= 1) return false; // los menores o iguales a 1 no son primos
        for (int i = 2; i <= Math.sqrt(n); i++) { // pruebo divisores hasta raíz cuadrada
            if (n % i == 0) {
                return false; // si divide exacto, no es primo
            }
        }
        return true; // si no tiene divisores, es primo
    }

    // Ejercicio 5: Factorial recursivo
    public static Integer factorial(Integer n) {
        if (n < 0) return -1; // control de error
        if (n == 0) return 1; // caso base
        return n * factorial(n - 1); // caso recursivo
    }

    // Ejercicio 6: Suma alterna recursiva
    public static Integer sumaAlterna(Integer n) {
        if (n == 0) return 0; // caso base
        if (n % 2 == 0) { // si n es par, resto
            return sumaAlterna(n - 1) - n;
        } else { // si es impar, sumo
            return sumaAlterna(n - 1) + n;
        }
    }

    // Ejercicio 7: Switch - Días de la semana
    public static String ejercicio7(Integer dia) {
        String res;
        switch (dia) {
            case 1:
                res = "Lunes";
                break;
            case 2:
                res = "Martes";
                break;
            case 3:
                res = "Miércoles";
                break;
            case 4:
                res = "Jueves";
                break;
            case 5:
                res = "Viernes";
                break;
            case 6:
                res = "Sábado";
                break;
            case 7:
                res = "Domingo";
                break;
            default:
                res = "Día no válido";
                break;
        }
        return res;
    }

    // Ejercicio 8: Misteriosa
    public static Integer misteriosa(Integer n) {
        if (n % 2 == 0 && n > 10) {
            return n / 2;
        } else if (n % 2 != 0 && n <= 10) {
            return n * 3 + 1;
        } else {
            return n;
        }
    }

    // Ejercicio 9: Rotar lista
    public static List<Integer> rotarLista(List<Integer> lista) {
        if (lista.isEmpty()) return lista;
        Integer primero = lista.get(0);
        for (int i = 0; i < lista.size() - 1; i++) {
            lista.set(i, lista.get(i + 1)); // desplazo cada elemento a la izquierda
        }
        lista.set(lista.size() - 1, primero); // el primero pasa al final
        return lista;
    }

    // Ejercicio 10: Recursividad final boss
    public static Integer f(Integer n) {
        if (n == 0) return 0;
        if (n == 1) return 1;
        if (n == 2) return 2;
        return f(n - 1) + f(n - 2) - f(n - 3);
    }
}
