package practicarandreau2;
import java.util.ArrayList;
import java.util.List;
public class PracticarAndreaU2 {

    public static void main(String[] args) {

        // ---- EJERCICIO 1: Precio en el parque mágico ----
        System.out.println("Ejercicio 1 ------------------");
        System.out.println("Persona 10 años, socia -> " + ejercicio1(10.0, 10, true));
        System.out.println("Persona 70 años, no socia -> " + ejercicio1(10.0, 70, false));

        // ---- EJERCICIO 2: Mensaje del genio ----
        System.out.println("\nEjercicio 2 ------------------");
        System.out.println("Mensaje del genio si digo 'fuego' -> " + ejercicio2("fuego"));
        System.out.println("Mensaje del genio si digo 'agua' -> " + ejercicio2("agua"));
        System.out.println("Mensaje del genio si digo 'viento' -> " + ejercicio2("viento"));
        System.out.println("Mensaje del genio si digo 'nada' -> " + ejercicio2("nada"));

        // ---- EJERCICIO 3: Reparto de caramelos ----
        System.out.println("\nEjercicio 3 ------------------");
        List<Integer> caramelos = new ArrayList<>();
        caramelos.add(5);
        caramelos.add(3);
        caramelos.add(0);
        caramelos.add(2);
        caramelos.add(4);
        System.out.println("Lista: " + caramelos);
        System.out.println("Resultado: " + ejercicio3(caramelos));

        // ---- EJERCICIO 4: Promedio de lista ----
        System.out.println("\nEjercicio 4 ------------------");
        System.out.println("Promedio: " + ejercicio4(caramelos));

        // ---- EJERCICIO 5: Puerta secreta ----
        System.out.println("\nEjercicio 5 ------------------");
        List<Integer> puertas = new ArrayList<>();
        puertas.add(3);
        puertas.add(5);
        puertas.add(1);
        puertas.add(9);
        puertas.add(2);
        puertas.add(8);
        puertas.add(6);
        puertas.add(7);
        puertas.add(10);
        puertas.add(4);
        System.out.println("Puertas: " + puertas);
        System.out.println("La puerta secreta 7 se abre en " + ejercicio5(puertas, 7) + " intentos.");

        // ---- EJERCICIO 6: Calabazas defectuosas ----
        System.out.println("\nEjercicio 6 ------------------");
        List<Double> calabazas = new ArrayList<>();
        calabazas.add(2.3);
        calabazas.add(3.1);
        calabazas.add(0.0);
        calabazas.add(4.5);
        System.out.println("Se procesan " + ejercicio6(calabazas) + " calabazas (hasta el 0 incluido)");

        // ---- EJERCICIO 7: Auditoría de notas ----
        System.out.println("\nEjercicio 7 ------------------");
        List<Integer> notas = new ArrayList<>();
        notas.add(8);
        notas.add(null);
        notas.add(5);
        notas.add(9);
        notas.add(null);
        notas.add(4);
        System.out.println("Notas: " + notas);
        System.out.println("Aptos: " + ejercicio7Aptos(notas));
        System.out.println("No nulos: " + ejercicio7NoNulos(notas));
        System.out.println("Porcentaje de aptos: " + ejercicio7Porcentaje(notas) + "%");

        // ---- EJERCICIO 8: Energía por criaturas ----
        System.out.println("\nEjercicio 8 ------------------");
        List<String> criaturas = new ArrayList<>();
        criaturas.add("zombie");
        criaturas.add("bruja");
        criaturas.add("fantasma");
        criaturas.add(null);
        criaturas.add("hombreLobo");
        criaturas.add("otro");
        System.out.println("Lista: " + criaturas);
        System.out.println("Energía total: " + ejercicio8(criaturas));

        // ---- EJERCICIO 9: Factorial recursivo ----
        System.out.println("\nEjercicio 9 ------------------");
        System.out.println("Factorial de 5 = " + factorial(5));

        // ---- EJERCICIO 10: Fibonacci / Tribonacci / Cuatrinacci ----
        System.out.println("\nEjercicio 10 ------------------");

        System.out.println("Fibonacci hasta 10:");
        for (int i = 0; i <= 10; i++) {
            System.out.println("fibo(" + i + ") = " + fibonacci(i));
        }

        System.out.println("\nTribonacci hasta 10:");
        for (int i = 0; i <= 10; i++) {
            System.out.println("tri(" + i + ") = " + tribonacci(i));
        }

        System.out.println("\nCuatrinacci hasta 10:");
        for (int i = 0; i <= 10; i++) {
            System.out.println("cuatri(" + i + ") = " + cuatrinacci(i));
        }
    }

    // ---- MÉTODOS ----

    public static Double ejercicio1(Double base, Integer edad, Boolean socio) {
        Double res = base;
        if (edad < 12) res = res * 0.5;
        else if (edad >= 65) res = res * 0.7;
        if (socio) res = res * 0.9;
        return res;
    }

    public static String ejercicio2(String palabra) {
        String res = "...";
        switch (palabra) {
            case "fuego":
                res = " ¡Fuego mágico!";
                break;
            case "agua":
                res = " ¡Ola gigante!";
                break;
            case "viento":
                res = "️ ¡Torbellino!";
                break;
        }
        return res;
    }

    public static Integer ejercicio3(List<Integer> lista) {
        Integer suma = 0;
        for (Integer e : lista) {
            suma += e;
            if (e == 0) suma = 0;
        }
        return suma;
    }

    public static Double ejercicio4(List<Integer> lista) {
        Double suma = 0.0;
        for (Integer e : lista) {
            suma += e;
        }
        if (lista.size() > 0) {
            suma = suma / lista.size();
        }
        return suma;
    }

    public static Integer ejercicio5(List<Integer> lista, Integer secreto) {
        Integer intentos = 0;
        for (Integer puerta : lista) {
            intentos++;
            if (puerta.equals(secreto)) {
                break;
            }
        }
        return intentos;
    }

    public static Integer ejercicio6(List<Double> lista) {
        Integer contador = 0;
        for (Double peso : lista) {
            contador++;
            if (peso == 0.0) {
                break;
            }
        }
        return contador;
    }

    public static Integer ejercicio7Aptos(List<Integer> lista) {
        Integer cont = 0;
        for (Integer e : lista) {
            if (e != null && e >= 5) {
                cont++;
            }
        }
        return cont;
    }

    public static Integer ejercicio7NoNulos(List<Integer> lista) {
        Integer cont = 0;
        for (Integer e : lista) {
            if (e != null) {
                cont++;
            }
        }
        return cont;
    }

    public static Double ejercicio7Porcentaje(List<Integer> lista) {
        return 100.0 * ejercicio7Aptos(lista) / ejercicio7NoNulos(lista);
    }

    public static Integer ejercicio8(List<String> lista) {
        Integer suma = 0;
        for (String e : lista) {
            if (e == null) continue;
            switch (e) {
                case "vampiro":
                    suma += 5;
                    break;
                case "zombie":
                    suma += 3;
                    break;
                case "bruja":
                    suma += 7;
                    break;
                case "fantasma":
                    suma += 4;
                    break;
                case "hombreLobo":
                    suma += 6;
                    break;
                default:
                    suma += 1;
                    break;
            }
        }
        return suma;
    }

    public static Integer factorial(Integer n) {
        if (n < 0) return -1;
        if (n == 0) return 1;
        return n * factorial(n - 1);
    }

    public static Integer fibonacci(Integer n) {
        if (n == 0) return 0;
        if (n == 1) return 1;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }

    public static Integer tribonacci(Integer n) {
        if (n == 0) return 0;
        if (n == 1 || n == 2) return 1;
        return tribonacci(n - 1) + tribonacci(n - 2) + tribonacci(n - 3);
    }

    public static Integer cuatrinacci(Integer n) {
        if (n == 0) return 0;
        if (n == 1 || n == 2 || n == 3) return 1;
        return cuatrinacci(n - 1) + cuatrinacci(n - 2) + cuatrinacci(n - 3) + cuatrinacci(n - 4);
    }
}
