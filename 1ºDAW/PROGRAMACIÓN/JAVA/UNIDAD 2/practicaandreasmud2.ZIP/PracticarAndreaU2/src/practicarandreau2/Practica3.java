package practicarandreau2;
import java.util.ArrayList;
import java.util.List;

public class Practica3 {
    

    public static void main(String[] args) {

        // ================== EJERCICIO 1 ==================
        // Crear una lista con los primeros 10 números naturales
        System.out.println("EJERCICIO 1: Crear lista ------------------");
        List<Integer> lista = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            lista.add(i); // voy añadiendo del 1 al 10
        }
        System.out.println("Lista inicial: " + lista);

        // ================== EJERCICIO 2 ==================
        // Calcular el cuadrado de cada número
        System.out.println("\nEJERCICIO 2: Cuadrados ------------------");
        mostrarCuadrados(lista);

        // ================== EJERCICIO 3 ==================
        // Contar cuántos números son múltiplos de 3
        System.out.println("\nEJERCICIO 3: Múltiplos de 3 ------------------");
        System.out.println("Cantidad de múltiplos de 3: " + contarMultiplosDe3(lista));

        // ================== EJERCICIO 4 ==================
        // Mostrar la suma acumulada con while
        System.out.println("\nEJERCICIO 4: Suma acumulada (while) ------------------");
        sumaAcumuladaWhile(lista);

        // ================== EJERCICIO 5 ==================
        // Usar switch para decir si un número es bajo, medio o alto
        System.out.println("\nEJERCICIO 5: Switch según rango ------------------");
        for (Integer n : lista) {
            System.out.println("El número " + n + " es " + rangoNumero(n));
        }

        // ================== EJERCICIO 6 ==================
        // Calcular el producto de todos los números de la lista
        System.out.println("\nEJERCICIO 6: Producto total ------------------");
        System.out.println("Producto de todos los números = " + productoLista(lista));

        // ================== EJERCICIO 7 ==================
        // Mostrar el número más pequeño y el más grande
        System.out.println("\nEJERCICIO 7: Mínimo y máximo ------------------");
        System.out.println("Menor = " + menor(lista));
        System.out.println("Mayor = " + mayor(lista));

        // ================== EJERCICIO 8 ==================
        // Recursividad: suma de los primeros n números
        System.out.println("\nEJERCICIO 8: Suma recursiva ------------------");
        System.out.println("Suma de los primeros 5 números = " + sumaRecursiva(5));

        // ================== EJERCICIO 9 ==================
        // Recursividad: número de Fibonacci n
        System.out.println("\nEJERCICIO 9: Fibonacci recursivo ------------------");
        for (int i = 0; i <= 8; i++) {
            System.out.println("fibo(" + i + ") = " + fibonacci(i));
        }

        // ================== EJERCICIO 10 ==================
        // Recursividad: Potencia (base^exponente)
        System.out.println("\nEJERCICIO 10: Potencia recursiva ------------------");
        System.out.println("2^5 = " + potencia(2, 5));
        System.out.println("3^4 = " + potencia(3, 4));
    }

    // ================== MÉTODOS ==================

    // Ejercicio 2: mostrar el cuadrado de cada número
    public static void mostrarCuadrados(List<Integer> lista) {
        for (Integer e : lista) {
            Integer cuadrado = e * e;
            System.out.println(e + "^2 = " + cuadrado);
        }
    }

    // Ejercicio 3: contar múltiplos de 3
    public static Integer contarMultiplosDe3(List<Integer> lista) {
        Integer cont = 0;
        for (Integer e : lista) {
            if (e % 3 == 0) { // si es múltiplo de 3
                cont++;
            }
        }
        return cont;
    }

    // Ejercicio 4: while para mostrar suma acumulada
    public static void sumaAcumuladaWhile(List<Integer> lista) {
        Integer i = 0;
        Integer suma = 0;
        while (i < lista.size()) {
            suma = suma + lista.get(i);
            System.out.println("Hasta el " + lista.get(i) + " la suma es " + suma);
            i++; // incremento manual
        }
    }

    // Ejercicio 5: switch para clasificar número
    public static String rangoNumero(Integer n) {
        String res;
        switch (n / 4) { // divido entre 4 para agrupar por rango
            case 0:
                res = "bajo";
                break;
            case 1:
                res = "medio";
                break;
            case 2:
                res = "alto";
                break;
            default:
                res = "muy alto";
        }
        return res;
    }

    // Ejercicio 6: producto de la lista
    public static Integer productoLista(List<Integer> lista) {
        Integer prod = 1;
        for (Integer e : lista) {
            prod = prod * e;
        }
        return prod;
    }

    // Ejercicio 7: mínimo y máximo
    public static Integer menor(List<Integer> lista) {
        Integer min = lista.get(0);
        for (Integer e : lista) {
            if (e < min) {
                min = e;
            }
        }
        return min;
    }

    public static Integer mayor(List<Integer> lista) {
        Integer max = lista.get(0);
        for (Integer e : lista) {
            if (e > max) {
                max = e;
            }
        }
        return max;
    }

    // Ejercicio 8: recursividad - suma 1 + 2 + ... + n
    public static Integer sumaRecursiva(Integer n) {
        if (n == 0) return 0; // caso base
        return n + sumaRecursiva(n - 1); // llamada recursiva
    }

    // Ejercicio 9: fibonacci recursivo
    public static Integer fibonacci(Integer n) {
        if (n == 0) return 0;
        if (n == 1) return 1;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }

    // Ejercicio 10: potencia recursiva (base^exponente)
    public static Integer potencia(Integer base, Integer exp) {
        if (exp == 0) return 1; // caso base
        return base * potencia(base, exp - 1); // llamada recursiva
    }
}

