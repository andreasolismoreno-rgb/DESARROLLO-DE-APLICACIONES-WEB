/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practicarandreau2;
import java.util.ArrayList;
import java.util.List;

public class Practica5 {
    public static void main(String[] args) {

        // === BONUS 1: Factorial doble ===
        System.out.println("=== BONUS 1: Factorial Doble ===");
        System.out.println("factorialDoble(7) = " + factorialDoble(7));
        System.out.println("factorialDoble(8) = " + factorialDoble(8));

        // === BONUS 2: Lista invertida ===
        System.out.println("\n=== BONUS 2: Invertir lista ===");
        List<Integer> lista = new ArrayList<>();
        lista.add(10); lista.add(20); lista.add(30); lista.add(40);
        System.out.println("Original: " + lista);
        System.out.println("Invertida: " + invertirLista(lista));

        // === BONUS 3: Contar pares e impares ===
        System.out.println("\n=== BONUS 3: Contar pares e impares ===");
        List<Integer> lista2 = new ArrayList<>();
        for (int i = 1; i <= 6; i++) lista2.add(i);
        System.out.println(contarParesImpares(lista2));

        // === BONUS 4: Suma de dígitos recursiva ===
        System.out.println("\n=== BONUS 4: Suma de dígitos recursiva ===");
        System.out.println("sumaDigitos(1234) = " + sumaDigitos(1234));
        System.out.println("sumaDigitos(98765) = " + sumaDigitos(98765));

        // === BONUS 5: Secuencia personalizada ===
        System.out.println("\n=== BONUS 5: Secuencia personalizada ===");
        for (int i = 0; i <= 10; i++)
            System.out.println("serieExtra(" + i + ") = " + serieExtra(i));
    }

    // === FUNCIONES ===

    public static Integer factorialDoble(Integer n) {
        if (n <= 1) return 1;
        return n * factorialDoble(n - 2);
    }

    public static List<Integer> invertirLista(List<Integer> lista) {
        List<Integer> invertida = new ArrayList<>();
        for (int i = lista.size() - 1; i >= 0; i--)
            invertida.add(lista.get(i));
        return invertida;
    }

    public static String contarParesImpares(List<Integer> lista) {
        int pares = 0, impares = 0;
        for (Integer n : lista) {
            if (n % 2 == 0) pares++;
            else impares++;
        }
        return "Hay " + pares + " pares y " + impares + " impares.";
    }

    public static Integer sumaDigitos(Integer n) {
        if (n < 10) return n;
        return (n % 10) + sumaDigitos(n / 10);
    }

    public static Integer serieExtra(Integer n) {
        if (n == 0) return 1;
        if (n == 1) return 2;
        if (n == 2) return 3;
        return serieExtra(n - 1) * 2 - serieExtra(n - 3);
    }
}