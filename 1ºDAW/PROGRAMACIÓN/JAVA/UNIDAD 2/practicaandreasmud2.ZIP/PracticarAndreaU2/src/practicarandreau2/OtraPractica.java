package practicarandreau2;
import java.util.ArrayList;
import java.util.List;
public class OtraPractica {
    public static void main(String[] args) {

        // ---- EJERCICIO 1: Crear una lista de números del 1 al 10 ----
        System.out.println("Ejercicio 1 ------------------");
        List<Integer> lista = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            lista.add(i);
        }
        System.out.println("Lista: " + lista);

        // ---- EJERCICIO 2: Sumar todos los números de la lista ----
        System.out.println("\nEjercicio 2 ------------------");
        System.out.println("Suma total: " + sumaLista(lista));

        // ---- EJERCICIO 3: Contar los números pares ----
        System.out.println("\nEjercicio 3 ------------------");
        System.out.println("Cantidad de pares: " + contarPares(lista));

        // ---- EJERCICIO 4: Obtener una lista solo con los impares ----
        System.out.println("\nEjercicio 4 ------------------");
        System.out.println("Impares: " + listaImpares(lista));

        // ---- EJERCICIO 5: Saber si un número es primo ----
        System.out.println("\nEjercicio 5 ------------------");
        System.out.println("¿Es primo 7? " + esPrimo(7));
        System.out.println("¿Es primo 8? " + esPrimo(8));

        // ---- EJERCICIO 6: Contar cuántos primos hay en la lista ----
        System.out.println("\nEjercicio 6 ------------------");
        System.out.println("Cantidad de primos: " + contarPrimos(lista));

        // ---- EJERCICIO 7: Buscar el mayor número primo de la lista ----
        System.out.println("\nEjercicio 7 ------------------");
        System.out.println("Mayor primo: " + mayorPrimo(lista));

        // ---- EJERCICIO 8: Calcular el promedio de la lista ----
        System.out.println("\nEjercicio 8 ------------------");
        System.out.println("Promedio: " + promedio(lista));

        // ---- EJERCICIO 9: Calcular factorial recursivo ----
        System.out.println("\nEjercicio 9 ------------------");
        System.out.println("Factorial de 5 = " + factorial(5));

        // ---- EJERCICIO 10: Fibonacci recursivo ----
        System.out.println("\nEjercicio 10 ------------------");
        for (int i = 0; i <= 10; i++) {
            System.out.println("fibo(" + i + ") = " + fibonacci(i));
        }
    }

    // ---- MÉTODOS ----

    // Ejercicio 2: suma de los elementos de una lista
    public static Integer sumaLista(List<Integer> lista) {
        Integer suma = 0;
        // recorro la lista con un for-each
        for (Integer e : lista) {
            suma = suma + e; // acumulo la suma
        }
        return suma;
    }

    // Ejercicio 3: contar pares
    public static Integer contarPares(List<Integer> lista) {
        Integer cont = 0;
        for (Integer e : lista) {
            if (e % 2 == 0) { // si es divisible entre 2
                cont++;
            }
        }
        return cont;
    }

    // Ejercicio 4: devolver lista de impares
    public static List<Integer> listaImpares(List<Integer> lista) {
        List<Integer> impares = new ArrayList<>();
        for (Integer e : lista) {
            if (e % 2 != 0) {
                impares.add(e);
            }
        }
        return impares;
    }

    // Ejercicio 5: saber si un número es primo
    public static Boolean esPrimo(Integer n) {
        if (n < 2) return false; // los menores que 2 no son primos
        for (int i = 2; i <= n / 2; i++) { // pruebo divisores
            if (n % i == 0) {
                return false; // si es divisible, no es primo
            }
        }
        return true; // si no se dividió, es primo
    }

    // Ejercicio 6: contar los primos de una lista
    public static Integer contarPrimos(List<Integer> lista) {
        Integer cont = 0;
        for (Integer e : lista) {
            if (esPrimo(e)) {
                cont++;
            }
        }
        return cont;
    }

    // Ejercicio 7: mayor número primo
    public static Integer mayorPrimo(List<Integer> lista) {
        Integer mayor = null;
        for (Integer e : lista) {
            if (esPrimo(e)) {
                if (mayor == null || e > mayor) {
                    mayor = e;
                }
            }
        }
        return mayor;
    }

    // Ejercicio 8: promedio de una lista
    public static Double promedio(List<Integer> lista) {
        Double suma = 0.0;
        for (Integer e : lista) {
            suma = suma + e;
        }
        if (lista.size() > 0) {
            suma = suma / lista.size();
        }
        return suma;
    }

    // Ejercicio 9: factorial recursivo
    public static Integer factorial(Integer n) {
        if (n == 0) return 1;
        return n * factorial(n - 1);
    }

    // Ejercicio 10: fibonacci recursivo
    public static Integer fibonacci(Integer n) {
        if (n == 0) return 0;
        if (n == 1) return 1;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}

