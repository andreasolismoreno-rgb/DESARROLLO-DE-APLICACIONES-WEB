/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practicarandreau2;

import java.util.ArrayList;
import java.util.List;
public class Practica2 {
    public static void main (String [] args){

        // === EJERCICIO 1 ===
        // Crear una lista de números del 1 al 12
        // (así tenemos pares, impares y primos)
        System.out.println("Ejercicio 1 --------------------");
        List<Integer> lista = new ArrayList<>();
        for (int i = 1; i <= 12; i++) {
            lista.add(i); // voy añadiendo los números del 1 al 12
        }
        System.out.println("Lista inicial: " + lista);

        // === EJERCICIO 2 ===
        // Mostrar los números pares
        System.out.println("\nEjercicio 2 --------------------");
        mostrarPares(lista);

        // === EJERCICIO 3 ===
        // Mostrar los números impares
        System.out.println("\nEjercicio 3 --------------------");
        mostrarImpares(lista);

        // === EJERCICIO 4 ===
        // Sumar todos los pares e impares por separado
        System.out.println("\nEjercicio 4 --------------------");
        System.out.println("Suma de pares = " + sumaPares(lista));
        System.out.println("Suma de impares = " + sumaImpares(lista));

        // === EJERCICIO 5 ===
        // Comprobar cuáles son primos y cuál es el mayor
        System.out.println("\nEjercicio 5 --------------------");
        System.out.println("Lista de primos: " + listaPrimos(lista));
        System.out.println("Mayor primo: " + mayorPrimo(lista));

        // === EJERCICIO 6 ===
        // Factorial recursivo
        System.out.println("\nEjercicio 6 --------------------");
        System.out.println("Factorial de 5 = " + factorial(5));

        // === EJERCICIO 7 ===
        // Fibonacci recursivo
        System.out.println("\nEjercicio 7 --------------------");
        for (int i = 0; i <= 10; i++) {
            System.out.println("fibo(" + i + ") = " + fibonacci(i));
        }

        // === EJERCICIO 8 ===
        // Tribonacci recursivo
        System.out.println("\nEjercicio 8 --------------------");
        for (int i = 0; i <= 10; i++) {
            System.out.println("tribo(" + i + ") = " + tribonacci(i));
        }

        // === EJERCICIO 9 ===
        // Cuatrinacci recursivo
        System.out.println("\nEjercicio 9 --------------------");
        for (int i = 0; i <= 10; i++) {
            System.out.println("cuatrinacci(" + i + ") = " + cuatrinacci(i));
        }

        // === EJERCICIO 10 ===
        // Uso de switch con mensaje según número
        System.out.println("\nEjercicio 10 --------------------");
        for (Integer n : lista) {
            System.out.println("Para " + n + ": " + mensajeSegunNumero(n));
        }
    }

    // === FUNCIONES ===

    // Mostrar los números pares
    public static void mostrarPares(List<Integer> lista) {
        for (Integer e : lista) {
            if (e % 2 == 0) { // si es divisible entre 2
                System.out.println(e + " es par");
            }
        }
    }

    // Mostrar los impares
    public static void mostrarImpares(List<Integer> lista) {
        for (Integer e : lista) {
            if (e % 2 != 0) { // si no es divisible entre 2
                System.out.println(e + " es impar");
            }
        }
    }

    // Sumar los pares
    public static Integer sumaPares(List<Integer> lista) {
        Integer suma = 0;
        for (Integer e : lista) {
            if (e % 2 == 0) {
                suma = suma + e; // acumulo solo los pares
            }
        }
        return suma;
    }

    // Sumar los impares
    public static Integer sumaImpares(List<Integer> lista) {
        Integer suma = 0;
        for (Integer e : lista) {
            if (e % 2 != 0) {
                suma = suma + e; // acumulo solo los impares
            }
        }
        return suma;
    }

    // Saber si un número es primo
    public static Boolean esPrimo(Integer n) {
        if (n < 2) return false;
        for (int i = 2; i <= n / 2; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }

    // Crear lista con los números primos
    public static List<Integer> listaPrimos(List<Integer> lista) {
        List<Integer> primos = new ArrayList<>();
        for (Integer e : lista) {
            if (esPrimo(e)) {
                primos.add(e);
            }
        }
        return primos;
    }

    // Devolver el mayor número primo
    public static Integer mayorPrimo(List<Integer> lista) {
        Integer mayor = null;
        for (Integer e : lista) {
            if (esPrimo(e)) {
                if (mayor == null || e > mayor) {
                    mayor = e;
                }
            }
        }
        return mayor;
    }

    // Factorial recursivo
    public static Integer factorial(Integer n) {
        if (n < 0) return -1; // si es negativo, error
        if (n == 0) return 1; // caso base
        return n * factorial(n - 1); // llamada recursiva
    }

    // Fibonacci recursivo
    public static Integer fibonacci(Integer n) {
        if (n == 0) return 0;
        if (n == 1) return 1;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }

    // Tribonacci recursivo (suma los tres anteriores)
    public static Integer tribonacci(Integer n) {
        if (n == 0) return 0;
        if (n == 1 || n == 2) return 1;
        return tribonacci(n - 1) + tribonacci(n - 2) + tribonacci(n - 3);
    }

    // Cuatrinacci recursivo (suma los cuatro anteriores)
    public static Integer cuatrinacci(Integer n) {
        if (n == 0) return 0;
        if (n == 1 || n == 2 || n == 3) return 1;
        return cuatrinacci(n - 1) + cuatrinacci(n - 2) + cuatrinacci(n - 3) + cuatrinacci(n - 4);
    }

    // Switch con mensaje según el número
    public static String mensajeSegunNumero(Integer n) {
        String res;
        switch (n % 4) { // uso el resto para variar los mensajes
            case 0:
                res = " Es múltiplo de 4";
                break;
            case 1:
                res = " Es resto 1 al dividir entre 4";
                break;
            case 2:
                res = "️ Es resto 2 al dividir entre 4";
                break;
            case 3:
                res = " Es resto 3 al dividir entre 4";
                break;
            default:
                res = "...";
        }
        return res;
    }
}
