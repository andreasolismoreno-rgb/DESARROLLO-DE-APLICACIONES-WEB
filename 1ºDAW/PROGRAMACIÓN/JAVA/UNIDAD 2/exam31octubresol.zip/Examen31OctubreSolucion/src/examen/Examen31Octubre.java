
package examen;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Examen31Octubre {
    public static void main(String[] args) {
        System.out.println("Ejercicio1: persona con 5 años disfrazada");
        System.out.println(ejercicio1(10.0, 5, true));
        System.out.println("Ejercicio1: persona con 55 años no disfrazada");
        System.out.println(ejercicio1(10.0, 55, false));
        System.out.println("");
        System.out.println("Ejercicio2: Que dice la buja????");
        System.out.println(ejercicio2("bruja"));
        System.out.println("Ejercicio2: Que dice el hombre lobo????");
        System.out.println(ejercicio2("hombreLobo"));
        System.out.println("Ejercicio2: Y si le paso algo que no coincida????");
        System.out.println(ejercicio2("superman"));
        List<Integer> lista = new ArrayList<>();
        lista.add(7);lista.add(3);lista.add(0);lista.add(5);lista.add(3);
        System.out.println("Ejercicio3: Para la lista "+lista+" el resultado es");
        System.out.println(ejercicio3(lista));
        System.out.println(ejercicio4(lista));
        List<Integer> puertas = new ArrayList<>();
        puertas.add(1);puertas.add(3);puertas.add(7);puertas.add(5);
        puertas.add(8);puertas.add(10);puertas.add(4);puertas.add(6);
        puertas.add(9);puertas.add(2);
        System.out.println("Si la las puertas son "+ puertas);
        System.out.println("Y la llave secreta es "+ 7);
        System.out.println("La puerta se abre en "+ ejercicio5(puertas, 7)+ " intentos");
    
//        for (int i = 0; i <= 20; i++) {
//            if (i%2==0) {
//                System.out.println("Para i="+i+" vale "+trifibo(i));                
//            }
//        }
        Stream.iterate(0, i->i<=20, i->i+1)
                .filter(i->i%2==0)
                .forEach(i->System.out.println("Para i="+i+" vale "+trifibo(i)));
        
        
        System.out.println("Ejercicio 6 --------------------------");
        List<Double> listaReales = new ArrayList<>();
        listaReales.add(3.1);listaReales.add(6.1);
        listaReales.add(4.2);listaReales.add(0.0);
        listaReales.add(3.4);listaReales.add(3.6);
        System.out.println("Si la lista es "+listaReales);
        System.out.println("Se procesan "+ejercicio6(listaReales)+ " calabazas");
    
        System.out.println("Ejercicio 7 --------------------------");
        List<Integer> listaEnteros = new ArrayList<>();
        listaEnteros.add(3);listaEnteros.add(7);
        listaEnteros.add(9);listaEnteros.add(null);
        listaEnteros.add(8);listaEnteros.add(null);
        System.out.println("Si la lista es "+listaEnteros);
        System.out.println("Hay "+ejercicio7Aptos(listaEnteros)+ " aptos");
        System.out.println("Hay "+ejercicio7ANoNulos(listaEnteros)+ " no nulos");
        System.out.println("El porcentaje sobre el total no null es "+ ejercicio7Porcentaje(listaEnteros));
        
//        Cada criatura da puntos: 
//        vampiro=5, zombie=3, bruja=7, fantasma=4, hombreLobo=6, otro=1. 
//        Crea un método que, dada una lista de criaturas (List<String>), 
//        devuelva la suma total y omita nulos.
        List<String> criaturas = new ArrayList<>();
        criaturas.add("vampiro");criaturas.add(null);
        criaturas.add("vampiro");
        System.out.println("Si la lista es "+criaturas);
        System.out.println("La suma es: "+ejercicio8(criaturas));
    }
    public static Integer ejercicio8(List<String> criaturas){
        Integer suma=0;
        for (String e : criaturas) {
            if (e!=null) {
                if (e.equals("vampiro")) {
                    suma = suma + 5;
                } else if (e.equals("zombie")) {
                    suma = suma + 3;
                } else if (e.equals("bruja")) {
                    suma = suma + 7;
                } else if (e.equals("fantasma")) {
                    suma = suma + 4;
                } else if (e.equals("hombreLobo")) {
                    suma = suma + 6;
                } else {
                    suma = suma + 1;
                }
            }
        }
        return suma;
    }
    public static Double ejercicio7Porcentaje(List<Integer> lis){
        return 100.0*ejercicio7Aptos(lis)/ejercicio7ANoNulos(lis);
    }
    public static Integer ejercicio7ANoNulos(List<Integer> lis){
        Integer cont=0;
        for (Integer e : lis) {          
          if (e!=null) {
                    cont++;
            }
            
        }
        return cont;
    }
    public static Integer ejercicio7Aptos(List<Integer> lis){
        Integer cont=0;
        for (Integer e : lis) {          
          if (e!=null) {
                if (e >= 6) {
                    cont++;
                }
            }    
        }
        return cont;
    }
    public static Integer ejercicio6(List<Double> lis){
        Integer cont = 0;
        for (Double e : lis) {
            cont++;
            if (e==0.0) {
                break;
            }
        }
        return cont;
    }
    public static  Integer factorialRecursivo(Integer n){
        Integer res = null;
        if(n<0){
            res=-1;
        }else if (n==0) {
            res = 1;
        } else {
            res = n* factorialRecursivo(n-1);
        }
        return res;
    }
    
    public static Integer trifibo(Integer n){
        Integer res=null;
        if(n==0){
            res = 0;
        } else if (n==1 || n==2) {
            res = 1;
        } else {
            res = trifibo(n-1) + trifibo(n-2) +trifibo(n-3);
        }
        return res;
    }
    public static Integer ejercicio5(List<Integer> lista, Integer secreto){
        Integer cont = 0;
        for (Integer e : lista) {
            cont++;
            if (e==secreto) {
                break;
            }
        }
        return cont;
    }
    public static Double ejercicio4(List<Integer> lista){
        Double res=0.0;
        for (Integer e : lista) {
            res = res + e;
        }
        if (lista.size()>0) {
            res=res/lista.size();
        }
        return res;
    }
    public static Integer ejercicio3(List<Integer> lista){
        Integer res=0;
        for (Integer e : lista) {
            res = res + e;
            if (e==0) {
                res=0;
            }
        }
        return res;
    }
    
    public static String ejercicio2(String criatura){
        String res="...";
        switch (criatura) {
            case "vampiro": res="¡Sangreee!";
            break;
            case "bruja": res="¡Abracadabra!";
            break;
            case "fantasma": res="¡Buuu!";
            break;
            case "hombreLobo": res="¡Auuuuuu!";
            break;
        }
        return res;
    }
    public static Double ejercicio1(Double precioBase, Integer edad, Boolean estaDisfrazado){
        Double res=precioBase;
        if (edad<12 ) {
            res = res*0.5;
        } else if(edad >= 65){
            res = res*(1-0.3);
        }
        if (estaDisfrazado) {
            res = res*(1-0.1);
        }
        return res;
    }
}
