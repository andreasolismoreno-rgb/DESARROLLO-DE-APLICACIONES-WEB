/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividades;

//Comprobación en array (existe o no)
//Muy parecido al anterior, pero solo devuelvo true/false o un mensaje de existencia.
import java.util.Scanner;
public class Ejercicio6 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Tamaño del array: ");
        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) arr[i] = sc.nextInt();

        System.out.print("Valor a comprobar: ");
        int valor = sc.nextInt();

        boolean existe = false;
        for (int v : arr) {
            if (v == valor) { existe = true; break; }
        }

        System.out.println(existe ? "Existe en el array." : "No existe en el array.");
        sc.close();
    }
}
    

