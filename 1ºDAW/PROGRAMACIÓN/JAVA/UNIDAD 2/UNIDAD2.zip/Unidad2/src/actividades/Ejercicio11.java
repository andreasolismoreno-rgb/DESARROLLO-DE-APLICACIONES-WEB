package actividades;

import java.util.Scanner;

public class Ejercicio11 {
        public static boolean esPrimo(int n) {
        if (n < 2) return false;
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce el inicio: ");
        int a = sc.nextInt();
        System.out.print("Introduce el fin: ");
        int b = sc.nextInt();
        if (a > b) { int tmp = a; a = b; b = tmp; }

        boolean hayPrimos = false;
        System.out.println("Primos en el rango:");
        for (int x = a; x <= b; x++) {
            if (esPrimo(x)) { System.out.println(x); hayPrimos = true; }
        }
        if (!hayPrimos) System.out.println("No hay números primos en ese rango.");
        sc.close();
    }
}
