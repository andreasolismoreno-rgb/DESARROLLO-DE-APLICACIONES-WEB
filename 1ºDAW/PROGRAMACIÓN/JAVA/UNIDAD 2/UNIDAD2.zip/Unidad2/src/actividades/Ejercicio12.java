
package actividades;

 import java.util.Scanner;
public class Ejercicio12 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("\n--- MENÚ ---");
            System.out.println("1) Factorial");
            System.out.println("2) Potencia (base^exponente)");
            System.out.println("3) Raíz cuadrada");
            System.out.println("4) Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Introduce un entero no negativo: ");
                    int n = sc.nextInt();
                    long fact = 1;
                    if (n < 0) System.out.println("No existe factorial para negativos.");
                    else {
                        for (int i = 1; i <= n; i++) fact *= i;
                        System.out.println("Factorial de " + n + " = " + fact);
                    }
                    break;
                case 2:
                    System.out.print("Base: "); double base = sc.nextDouble();
                    System.out.print("Exponente: "); double exp = sc.nextDouble();
                    System.out.println(base + "^" + exp + " = " + Math.pow(base, exp));
                    break;
                case 3:
                    System.out.print("Número: "); double x = sc.nextDouble();
                    if (x < 0) System.out.println("La raíz cuadrada no es real para negativos.");
                    else System.out.println("Raíz cuadrada = " + Math.sqrt(x));
                    break;
                case 4:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 4);
        sc.close();
    }
}
