/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividades;


import java.util.Scanner;

public class Ejercicio8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Tamaño del array: ");
        int n = sc.nextInt();
        if (n <= 0) {
            System.out.println("Array vacío.");
            sc.close();
            return;
        }
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) arr[i] = sc.nextInt();

        int min = arr[0];
        for (int i = 1; i < n; i++) if (arr[i] < min) min = arr[i];

        System.out.println("Mínimo = " + min);
        sc.close();
    }
}

