/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividades;
import java.util.Scanner;
public class Ejercicio16 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce notas (termina con -1):");

        double suma = 0;
        int n = 0;
        double max = Double.NEGATIVE_INFINITY, min = Double.POSITIVE_INFINITY;
        int aprobados = 0, suspensos = 0;
        while (true) {
            double nota = sc.nextDouble();
            if (nota == -1) break;
            suma += nota;
            n++;
            if (nota > max) max = nota;
            if (nota < min) min = nota;
            if (nota >= 5) aprobados++; else suspensos++;
        }

        if (n == 0) {
            System.out.println("No se introdujeron notas.");
        } else {
            System.out.println("Media: " + (suma / n));
            System.out.println("Nota más alta: " + max);
            System.out.println("Nota más baja: " + min);
            System.out.println("Aprobados: " + aprobados);
            System.out.println("Suspensos: " + suspensos);
        }
        sc.close();
    }
} 

