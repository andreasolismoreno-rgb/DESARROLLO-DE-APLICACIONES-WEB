/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividades;

import java.util.Scanner;
public class Ejercicio17 {

   
    static final double EUR_TO_USD = 1.10;  // 1 EUR = 1.10 USD (ejemplo)
    static final double EUR_TO_GBP = 0.88;  // 1 EUR = 0.88 GBP
    static final double EUR_TO_JPY = 151.20; // 1 EUR = 151.20 JPY

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("\nConversor: 1)EUR->USD 2)EUR->GBP 3)EUR->JPY 4)Salir");
            System.out.print("Elige: ");
            opcion = sc.nextInt();
            if (opcion >= 1 && opcion <= 3) {
                System.out.print("Introduce cantidad en EUR: ");
                double euros = sc.nextDouble();
                switch (opcion) {
                    case 1: System.out.println(euros + " EUR = " + (euros * EUR_TO_USD) + " USD"); break;
                    case 2: System.out.println(euros + " EUR = " + (euros * EUR_TO_GBP) + " GBP"); break;
                    case 3: System.out.println(euros + " EUR = " + (euros * EUR_TO_JPY) + " JPY"); break;
                }
            } else if (opcion == 4) {
                System.out.println("Saliendo del conversor.");
            } else {
                System.out.println("Opción no válida.");
            }
        } while (opcion != 4);
        sc.close();
    }
}  

