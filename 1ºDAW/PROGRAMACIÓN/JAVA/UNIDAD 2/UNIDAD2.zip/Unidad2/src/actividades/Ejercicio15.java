/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividades;
    import java.util.Random;

import java.util.Scanner;

public class Ejercicio15 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rnd = new Random();
        int secreto = rnd.nextInt(100) + 1; // 1..100
        int intento;
        int contador = 0;
        System.out.println("Adivina el número entre 1 y 100.");

        while (true) {
            System.out.print("Tu intento: ");
            intento = sc.nextInt();
            contador++;
            if (intento == secreto) {
                System.out.println("¡Correcto! Lo has adivinado en " + contador + " intentos.");
                break;
            } else if (intento < secreto) {
                System.out.println("El número buscado es mayor.");
            } else {
                System.out.println("El número buscado es menor.");
            }
        }
        sc.close();
    }
}

