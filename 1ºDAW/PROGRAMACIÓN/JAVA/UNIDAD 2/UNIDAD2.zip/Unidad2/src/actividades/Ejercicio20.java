/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividades;

import java.util.Scanner;

public class Ejercicio20 {
     public static void main(String[] args) {
        final String USUARIO_CORRECTO = "admin";
        final String PASS_CORRECTA = "1234";
        Scanner sc = new Scanner(System.in);

        int intentos = 3;
        boolean acceso = false;

        while (intentos > 0 && !acceso) {
            System.out.print("Usuario: ");
            String u = sc.next();
            System.out.print("Contraseña: ");
            String p = sc.next();
            if (u.equals(USUARIO_CORRECTO) && p.equals(PASS_CORRECTA)) {
                acceso = true;
                System.out.println("Acceso concedido. ¡Bienvenido!");
            } else {
                intentos--;
                if (intentos > 0) System.out.println("Usuario o contraseña incorrectos. Te quedan " + intentos + " intentos.");
                else System.out.println("Has fallado los 3 intentos. Acceso bloqueado.");
            }
        }
        sc.close();
    }
}
