
package actividades;

import java.util.Scanner;
public class Ejercicio2 {
    //Ejercicio 2 — Cálculo del mayor de tres números
    //Pedir tres números y mostrar el mayor.
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
            System.out.print("a = "); int a = sc.nextInt(); // a= 2
            System.out.print("b = "); int b = sc.nextInt(); // b = 3
            System.out.print("c = "); int c = sc.nextInt(); // c = 5


            int mayor = a;
            if (b > mayor) mayor = b;
            if (c > mayor) mayor = c;


            System.out.println("El mayor es: " + mayor); //El mayor es: 5
    }
}
