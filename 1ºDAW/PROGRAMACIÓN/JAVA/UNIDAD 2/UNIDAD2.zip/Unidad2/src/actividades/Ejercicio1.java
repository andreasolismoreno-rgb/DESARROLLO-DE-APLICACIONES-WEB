package actividades;

import java.util.Scanner; //Creamos Scanner para leer entrada.
        
public class Ejercicio1 {
    //Cálculo del mayor de dos números
    //Pedir dos números y mostrar cuál es el mayor (o indicar si son iguales).
       
        public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
            System.out.print("Introduce el primer número: "); //Introduce el primer n�mero: 7
        int a = sc.nextInt();
            System.out.print("Introduce el segundo número: "); //Introduce el segundo n�mero: 3
        int b = sc.nextInt();


            if (a > b) {
            System.out.println(a + " es mayor que " + b); //7 es mayor que 3
            } else if (a < b) {
            System.out.println(b + " es mayor que " + a);
            } else {
            System.out.println("Los dos números son iguales: " + a);
            }
    }
 
}
