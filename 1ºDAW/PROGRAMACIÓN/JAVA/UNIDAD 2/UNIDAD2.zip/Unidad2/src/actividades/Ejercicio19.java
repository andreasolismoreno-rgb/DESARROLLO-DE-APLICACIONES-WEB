/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividades;

import java.util.Scanner;

public class Ejercicio19 {
     public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Número: ");
        int num = sc.nextInt();
        System.out.print("Inicio: ");
        int inicio = sc.nextInt();
        System.out.print("Fin: ");
        int fin = sc.nextInt();

        if (inicio > fin) {
            int tmp = inicio; inicio = fin; fin = tmp; // intercambiar
        }

        for (int i = inicio; i <= fin; i++) {
            if (i < 0) continue; // ignorar negativos
            System.out.println(num + " x " + i + " = " + (num * i));
        }
        sc.close();
    }
}

