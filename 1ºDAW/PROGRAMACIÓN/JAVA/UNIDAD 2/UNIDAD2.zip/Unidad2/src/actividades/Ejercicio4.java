package actividades;

import java.util.Scanner;

public class Ejercicio4 {
    //Suma acumulada
    //Sumar números consecutivos o sumar n números según enunciado. 
    //Interpretación: suma de 1 hasta n.

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("¿Cuántos números quieres sumar? ");
        int count = sc.nextInt();

        double suma = 0;
        for (int i = 1; i <= count; i++) {
            System.out.print("Número " + i + ": ");
            suma += sc.nextDouble();
        }

        System.out.println("Suma acumulada = " + suma);
        sc.close();
    }
}