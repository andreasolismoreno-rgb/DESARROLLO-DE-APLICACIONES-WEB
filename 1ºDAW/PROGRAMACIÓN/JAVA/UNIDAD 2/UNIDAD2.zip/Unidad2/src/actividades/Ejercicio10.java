package actividades;

import java.util.Scanner;

public class Ejercicio10 {
public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Tamaño: ");
        int n = sc.nextInt();
        if (n <= 0) {
            System.out.println("Array vacío.");
            sc.close();
            return;
        }
        double suma = 0;
        for (int i = 0; i < n; i++) {
            System.out.print("Dato " + (i+1) + ": ");
            suma += sc.nextDouble();
        }
        System.out.println("Media = " + (suma / n));
        sc.close();
    }
}