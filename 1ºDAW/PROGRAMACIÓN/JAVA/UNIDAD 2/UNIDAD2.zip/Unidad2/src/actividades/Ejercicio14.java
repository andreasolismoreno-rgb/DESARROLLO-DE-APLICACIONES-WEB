/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividades;
import java.util.Scanner;

public class Ejercicio14 {
     public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un entero: ");
        int n = sc.nextInt();
        if (n < 0) {
            System.out.println("No se considera capicúa (negativo).");
            sc.close();
            return;
        }
        int original = n;
        int rev = 0;
        while (n > 0) {
            rev = rev * 10 + (n % 10);
            n /= 10;
        }
        System.out.println(original == rev ? "Es capicúa." : "No es capicúa.");
        sc.close();
    }
}
