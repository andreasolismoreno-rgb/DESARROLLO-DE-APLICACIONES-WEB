/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividades;

import java.util.Scanner;
public class Ejercicio18 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número entero positivo: ");
        int n = sc.nextInt();
        if (n <= 0) {
            System.out.println("Debe ser positivo.");
            sc.close();
            return;
        }
        int suma = 0;
        for (int i = 1; i <= n / 2; i++) {
            if (n % i == 0) suma += i;
        }
        System.out.println(suma == n ? n + " es perfecto." : n + " no es perfecto.");
        sc.close();
    }
}
