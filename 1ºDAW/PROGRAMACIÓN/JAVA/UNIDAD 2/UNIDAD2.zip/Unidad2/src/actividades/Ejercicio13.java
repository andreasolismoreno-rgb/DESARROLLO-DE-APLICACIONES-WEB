/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividades;

import java.util.Scanner;

public class Ejercicio13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("¿Cuántos términos quieres? ");
        int n = sc.nextInt();
        if (n < 1) {
            System.out.println("Error: n debe ser >= 1.");
            sc.close();
            return;
        }
        long a = 0, b = 1;
        System.out.println("Serie de Fibonacci:");
        for (int i = 1; i <= n; i++) {
            System.out.print(a + (i == n ? "\n" : " "));
            long siguiente = a + b;
            a = b;
            b = siguiente;
        }
        sc.close();
    }
}
