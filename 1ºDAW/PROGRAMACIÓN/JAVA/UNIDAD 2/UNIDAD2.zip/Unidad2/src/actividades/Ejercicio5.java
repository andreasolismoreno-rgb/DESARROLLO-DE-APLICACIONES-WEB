package actividades;
import java.util.Scanner;
public class Ejercicio5 {
    // Búsqueda en array (linear search)
    //Buscar un valor en un array y devolver la posición (o indicar que no está).
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
            int[] array  = {3, 7, 1, 9, 4};
        System.out.print("Número a buscar: ");
            int x = sc.nextInt();
            int pos = -1; // -1 indica no encontrado
            
            for (int i = 0; i < array.length; i++) {
            if (array [i] == x) {
            pos = i; // guardamos la primera posición
            break; // salir si queremos sólo la primera aparición
                }
            }           
            if (pos != -1) System.out.println("Encontrado en la posición " + pos);
            else System.out.println("No encontrado");
    }
}

