/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosud2;

/**
 *
 * @author DAW1-M
 */
import java.util.ArrayList;
import java.util.List;


public class Ejercicio4 {
    public static void main (String [] args){
        List <Integer> lista = new ArrayList <>();
        lista.add (7); lista.add(4); lista.add(3);
        lista.add (10); lista.add(6); lista.add(7);
        System.out.println(lista);
        System.out.println(lista.size());
        System.out.println(lista.get (2));
        
    }
}
