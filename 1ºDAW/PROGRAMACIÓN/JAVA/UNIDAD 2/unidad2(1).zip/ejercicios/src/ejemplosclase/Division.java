/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplosclase;

/**
 *
 * @author DAW1-M
 */
public class Division {
    public static void main (String [] args){
        System.out.println ("32/7");
        Integer dividendo = 32;
        Integer divisor = 7;
        Integer n=dividendo;    Integer division=0;
        while (n - divisor >=0){
            division ++;
            n = n - divisor;
        }
        System.out.println ("Resultado: " + division);
        
        Integer a = 17;
        Integer b = 8;
        if ( a > b){
          Integer aux = a;
          a=b;
          b=aux;
}
        for( int i = a; i<=b; i++){
            if(i%2==0){
            System.out.println ( i + "");
}
}
}
}
