/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplosclase;

/**
 *
 * @author DAW1-M
 */
public class NumerosPrimos {
    public static void main (String [] args){
        for ( int n=10; n<=20;n++){
            Boolean es = true;
            for(int i=2 ; i<n; i++){
                if (n%i==0) {
                    es =false;
                    break;
                }
            }
            if (es) {
                System.out.print(n +" ");
            }
        }
        System.out.println("");
    }
}
