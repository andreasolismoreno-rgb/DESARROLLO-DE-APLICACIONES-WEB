
package ejerciciosud2;
//Comprobación en array
public class Ejercicio6 {
    
    
}
