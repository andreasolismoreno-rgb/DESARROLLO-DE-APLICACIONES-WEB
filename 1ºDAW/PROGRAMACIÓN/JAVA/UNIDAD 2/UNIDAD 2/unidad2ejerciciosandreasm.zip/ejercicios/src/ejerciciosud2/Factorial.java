package ejerciciosud2;
public class Factorial {
   public static void main (String [] args){
       System.out.println("Con Bucles");
       for (int i = 0; i<=4;i++){
        System.out.println (i+"! = "+ factorialBucle(i));
   }
        System.out.println("Recursivamente");
       for (int i = 0; i<=4;i++){
        System.out.println (i+"! = "+ factorialRecursivo(i));
        }
   } 
    public static Integer factorialBucle (Integer n){
        Integer res = 1;
        for (int i = 1; i <=n; i++){
            res = res*i;
        }
        return res;
    }
        public static Integer factorialRecursivo (Integer n) {
            Integer res =  null;
            if (n==0){
                res = 1;
            } else {
                res = n * factorialRecursivo (n-1);
            }
            return  res;
        }
}
