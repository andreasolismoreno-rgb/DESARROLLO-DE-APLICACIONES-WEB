package proyecto;
public class ProyectoParesImpares {
    public static void main(String[] args) {

        int[] numeros = {3, 8, 2, 7, 9, 4, 6};
        int suma = 0;
        int pares = 0;
        int impares = 0;
        int mayor = numeros[0];
        int menor = numeros[0];

        for (int n : numeros) {
            suma += n;
            if (n % 2 == 0) pares++;
            else impares++;

            if (n > mayor) mayor = n;
            if (n < menor) menor = n;
        }

        System.out.println("===== ESTADÍSTICAS BÁSICAS =====");
        System.out.println("Suma: " + suma);
        System.out.println("Media: " + (double) suma / numeros.length);
        System.out.println("Cantidad pares: " + pares);
        System.out.println("Cantidad impares: " + impares);
        System.out.println("¿Todos son pares?: " + (pares == numeros.length));
        System.out.println("¿Todos son impares?: " + (impares == numeros.length));
        System.out.println("¿Hay alguno par?: " + (pares > 0));
        System.out.println("¿Hay alguno impar?: " + (impares > 0));
        System.out.println("Mayor: " + mayor);
        System.out.println("Menor: " + menor);
    }
}
