package ejerciciosud2;
import java.util.ArrayList;
import java.util.List;
public class Ejercicio16ConFunciones {
    public static void main(String[] args) {
        List<Integer> notas = new ArrayList<>();
        notas.add(4);
        notas.add(7);
        notas.add(9);
        notas.add(3);
        notas.add(10);
        notas.add(5);
        notas.add(2);
        
        estadisticasNotas(notas);
    }
    public static void estadisticasNotas(List<Integer> notas){
        int suma = 0;
        int max = notas.get(0);
        int min = notas.get(0);
        int aprobados = 0;
        int suspensos = 0;
        for (Integer n : notas) {
            suma += n;
            if (n > max) max = n;
            if (n < min) min = n;
            if (n >= 5) aprobados++;
            else suspensos++;
        }
        double media = 1.0 * suma / notas.size();
        System.out.println("===== ESTADÍSTICAS DE NOTAS (FUNCIÓN) =====");
        System.out.println("Notas: " + notas);
        System.out.println("Media: " + media);
        System.out.println("Máxima: " + max);
        System.out.println("Mínima: " + min);
        System.out.println("Aprobados: " + aprobados);
        System.out.println("Suspensos: " + suspensos);
    }
}
