package ejemplosclase;

import static ejerciciosud2.Ejercicio9ConFuncionesDeOtraForma.cuentaPares;
import java.util.ArrayList;
import java.util.List;

public class PreguntaDeExamenLista {
    //Contador en Array
    public static void main (String [] args){
        List<Integer> lista = new ArrayList<>();
        lista.add(7);lista.add(4);lista.add(3);
        lista.add(10);lista.add(6);lista.add(7);
        System.out.println(lista);
        Integer c = cuentaPares(lista,0);
        System.out.println("Hay " +c+ " elementos pares en la lista");
    }

    public static Integer cuentaPares(List<Integer> lis, int i) {
        Integer c = null;
        if (i==lis.size()) {
            c=0;
        } else {
            if(lis.get(i)%2 == 0){
                c = 1 + cuentaPares (lis, i+1);
            }
            else{
                c = cuentaPares (lis, i+1);
            }
        }
        return c;
    }
}
        
//        int i= 0;
//        while (i <lis.size()){
//            if(lis.get(i) % 2 == 0){
//                c++;
//            }
//            i++;
//        }
//    return c;

