package proyecto;
import java.util.Scanner;
public class ProyectoArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // 1️⃣ Declaramos un array
        int[] numeros = {3, 8, 2, 7, 9, 4, 6};

        // 2️⃣ Mostramos el array
        System.out.print("Array: ");
        for (int n : numeros) System.out.print(n + " ");
        System.out.println();

        // 3️⃣ Calculamos estadísticas
        System.out.println("Suma: " + suma(numeros));
        System.out.println("Media: " + media(numeros));
        System.out.println("Máximo: " + maximo(numeros));
        System.out.println("Mínimo: " + minimo(numeros));

        // 4️⃣ Búsqueda de un número
        System.out.print("Introduce un número a buscar: ");
        int buscar = sc.nextInt();
        if (existe(numeros, buscar)) {
            System.out.println("✅ El número " + buscar + " existe en el array");
        } else {
            System.out.println("❌ El número " + buscar + " NO existe en el array");
        }
    }

    // ============================================================
    // FUNCIONES AUXILIARES
    // ============================================================

    public static int suma(int[] lista) {
        int total = 0;
        for (int n : lista) total += n;
        return total;
    }

    public static double media(int[] lista) {
        return (double) suma(lista) / lista.length;
    }

    public static int maximo(int[] lista) {
        int max = lista[0];
        for (int n : lista) if (n > max) max = n;
        return max;
    }

    public static int minimo(int[] lista) {
        int min = lista[0];
        for (int n : lista) if (n < min) min = n;
        return min;
    }

    public static boolean existe(int[] lista, int valor) {
        for (int n : lista) if (n == valor) return true;
        return false;
    }
}
