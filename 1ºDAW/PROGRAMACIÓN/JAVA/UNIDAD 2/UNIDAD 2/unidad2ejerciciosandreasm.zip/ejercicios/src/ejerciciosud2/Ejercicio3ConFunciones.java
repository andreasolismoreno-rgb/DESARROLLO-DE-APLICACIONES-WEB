package ejerciciosud2;
public class Ejercicio3ConFunciones {
    public static void main (String [] args){
        tabla();
    }

    private static void tabla() {
        for (int i= 1; i <=10; i++){
            for (int j = 1; j<= 10; j++){
                System.out.print (i+ "*" + j + " = "+ i*j+" ");
            }
            System.out.println("");
        }
    }
}