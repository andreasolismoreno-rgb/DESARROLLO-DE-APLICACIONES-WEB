
package ejemplosclase;


public class NumerosPrimos {
    public static void main (String [] args){
        for ( int n=10; n<=20;n++){
            Boolean es = true;
            for(int i=2 ; i<n; i++){
                if (n%i==0) {
                    es =false;
                    break;
                }
            }
            if (es) {
                System.out.print(n +" ");
            }
        }
        System.out.println("");
    }
}
