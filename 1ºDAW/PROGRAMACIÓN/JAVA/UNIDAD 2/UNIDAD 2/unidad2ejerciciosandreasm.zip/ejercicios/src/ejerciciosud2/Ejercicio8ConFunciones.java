package ejerciciosud2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Ejercicio8ConFunciones {
      public static void main (String [] args){
        List <Integer> lista = creaLista();
        System.out.println (lista);
        System.out.println ("El mínimo es " +calculaMinimo(lista));
    }
    public static List <Integer> creaLista() {
        List <Integer> lista = new ArrayList <>();
        lista.add(7);lista.add(4);lista.add(3);
        lista.add(10);lista.add(6);lista.add(7);
        return lista;
    }
    public static Integer calculaMinimo (List<Integer> lis){
        return Collections.min(lis);
    }  
}