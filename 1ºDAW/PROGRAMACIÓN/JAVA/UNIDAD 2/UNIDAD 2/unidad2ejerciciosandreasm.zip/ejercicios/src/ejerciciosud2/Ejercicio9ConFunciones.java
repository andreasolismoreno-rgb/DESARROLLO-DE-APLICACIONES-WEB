package ejerciciosud2;

import java.util.ArrayList;
import java.util.List;

public class Ejercicio9ConFunciones {
    //Contador en Array
    public static void main (String [] args){
        List<Integer> lista = new ArrayList<>();
        lista.add(7);lista.add(4);lista.add(3);
        lista.add(10);lista.add(6);lista.add(7);
        System.out.println(lista);
        Integer cont = cuentaPares(lista);
        System.out.println("Hay " +cont+ " elementos pares en la lista");
    }

    public static Integer cuentaPares(List<Integer> lis) {
        Integer c = 0;
        for(Integer e : lis){
            if(e%2==0){
                c ++;
            }
        }
        return c;
    }
}
