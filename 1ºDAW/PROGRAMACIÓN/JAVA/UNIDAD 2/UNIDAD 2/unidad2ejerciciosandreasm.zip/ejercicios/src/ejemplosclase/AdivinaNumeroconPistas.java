
package ejemplosclase;

import java.util.Scanner ;
public class AdivinaNumeroconPistas {
    public static void main (String [] args ) {
        Scanner sc = new Scanner ( System.in);
            Integer secreto = 60;
            Integer n = null;
            Integer intentos = 0;
            do{
                System.out.println ("Deme un número :");
                n = sc.nextInt();
                
                if (n == secreto ){
                    
                    System.out.println ("Bien!!!");
                    
                }else{
                    
                    System.out.println ("Siga buscando!!");  
                    if(n>secreto) {
                        System.out.println ("...que sepas que es menor");
                    } else {
                        System.out.println ("...que sepas que es mayor");
                    }
                }
                intentos ++;
            } while ( n!=secreto);
            System.out.println ("Lo has acertado en el intento " + intentos);
            sc.close ();
    }
}