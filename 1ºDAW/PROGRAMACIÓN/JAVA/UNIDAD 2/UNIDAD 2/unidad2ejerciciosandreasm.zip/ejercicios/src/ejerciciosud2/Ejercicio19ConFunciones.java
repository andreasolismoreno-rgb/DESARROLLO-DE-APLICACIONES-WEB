package ejerciciosud2;
public class Ejercicio19ConFunciones {
    public static void main(String[] args) {
        mostrarTabla(8, 10, 5);
    }

    public static void mostrarTabla(int numero, int inicio, int fin) {
        if (inicio > fin) {
            int temp = inicio;
            inicio = fin;
            fin = temp;
        }

        System.out.println("===== TABLA DE MULTIPLICAR (FUNCIÓN) =====");
        for (int i = inicio; i <= fin; i++) {
            if (i < 0) continue;
            System.out.println(numero + " x " + i + " = " + (numero * i));
        }
    }
}