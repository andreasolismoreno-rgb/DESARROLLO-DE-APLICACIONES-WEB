package proyecto;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class ProyectoUnidoEncontrandoParesEImpares {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n===== MENÚ PRINCIPAL - UNIDAD 3 =====");
            System.out.println("1️⃣ Conversor de divisas");
            System.out.println("2️⃣ Número perfecto");
            System.out.println("3️⃣ Tabla de multiplicar personalizada");
            System.out.println("4️⃣ Sistema de login (3 intentos)");
            System.out.println("5️⃣ Estadísticas básicas con for extendido");
            System.out.println("6️⃣ Recursividad (factorial y Fibonacci)");
            System.out.println("0️⃣ Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1 -> conversorDivisas();
                case 2 -> numeroPerfecto();
                case 3 -> tablaMultiplicar();
                case 4 -> login();
                case 5 -> estadisticas();
                case 6 -> recursividad();
                case 0 -> System.out.println("👋 Saliendo del programa...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    // ============================================================
    // 1️⃣ CONVERSOR DE DIVISAS
    // ============================================================
    public static void conversorDivisas() {
        double euros = 150;
        double DOLAR = 1.08;
        double LIBRA = 0.86;
        double YEN = 162.33;

        System.out.println("\n===== CONVERSOR DE DIVISAS =====");
        System.out.println("Euros: " + euros);
        System.out.println("Dólares: " + (euros * DOLAR));
        System.out.println("Libras: " + (euros * LIBRA));
        System.out.println("Yenes: " + (euros * YEN));
    }

    public static void numeroPerfecto() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nIntroduce un número: ");
        int num = sc.nextInt();
        int suma = 0;

        for (int i = 1; i < num; i++) {
            if (num % i == 0) suma += i;
        }

        if (suma == num)
            System.out.println(num + " es un número perfecto ✅");
        else
            System.out.println(num + " no es perfecto ❌");
    }
    public static void tablaMultiplicar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nNúmero: ");
        int num = sc.nextInt();
        System.out.print("Inicio: ");
        int inicio = sc.nextInt();
        System.out.print("Fin: ");
        int fin = sc.nextInt();

        if (inicio > fin) {
            int temp = inicio;
            inicio = fin;
            fin = temp;
        }

        for (int i = inicio; i <= fin; i++) {
            if (i < 0) continue;
            System.out.println(num + " x " + i + " = " + (num * i));
        }
    }

    public static void login() {
        Scanner sc = new Scanner(System.in);
        String usuarioCorrecto = "admin";
        int passCorrecta = 1234;
        int intentos = 3;

        while (intentos > 0) {
            System.out.print("\nUsuario: ");
            String usuario = sc.next();
            System.out.print("Contraseña: ");
            int pass = sc.nextInt();

            if (usuario.equals(usuarioCorrecto) && pass == passCorrecta) {
                System.out.println("✅ Login correcto. Bienvenido!");
                return;
            } else {
                intentos--;
                System.out.println("❌ Error. Intentos restantes: " + intentos);
            }
        }
        System.out.println("⛔ Acceso bloqueado.");
    }
    public static void estadisticas() {
        int[] lista = {3, 8, 2, 7, 9, 4, 6};

        System.out.println("\n===== ESTADÍSTICAS BÁSICAS =====");
        System.out.println("Suma: " + suma(lista));
        System.out.println("Media: " + media(lista));
        System.out.println("Mayor: " + mayor(lista));
        System.out.println("Menor: " + menor(lista));
        System.out.println("Cantidad pares: " + contarPares(lista));
        System.out.println("Cantidad impares: " + contarImpares(lista));
        System.out.println("¿Todos pares?: " + todosPares(lista));
        System.out.println("¿Todos impares?: " + todosImpares(lista));
        System.out.println("¿Alguno par?: " + algunoPar(lista));
        System.out.println("¿Alguno impar?: " + algunoImpar(lista));

        // 🔹 Mostrar los valores concretos:
        System.out.println("Pares encontrados: " + listaDePares(lista));
        System.out.println("Impares encontrados: " + listaDeImpares(lista));
    }

    // 🔸 FUNCIONES AUXILIARES 🔸
    public static int suma(int[] lista) {
        int total = 0;
        for (int n : lista) total += n;
        return total;
    }

    public static double media(int[] lista) {
        return (double) suma(lista) / lista.length;
    }

    public static int mayor(int[] lista) {
        int max = lista[0];
        for (int n : lista) if (n > max) max = n;
        return max;
    }

    public static int menor(int[] lista) {
        int min = lista[0];
        for (int n : lista) if (n < min) min = n;
        return min;
    }

    public static int contarPares(int[] lista) {
        int cont = 0;
        for (int n : lista) if (n % 2 == 0) cont++;
        return cont;
    }

    public static int contarImpares(int[] lista) {
        int cont = 0;
        for (int n : lista) if (n % 2 != 0) cont++;
        return cont;
    }

    public static boolean todosPares(int[] lista) {
        for (int n : lista) if (n % 2 != 0) return false;
        return true;
    }

    public static boolean todosImpares(int[] lista) {
        for (int n : lista) if (n % 2 == 0) return false;
        return true;
    }

    public static boolean algunoPar(int[] lista) {
        for (int n : lista) if (n % 2 == 0) return true;
        return false;
    }

    public static boolean algunoImpar(int[] lista) {
        for (int n : lista) if (n % 2 != 0) return true;
        return false;
    }

    // 🔹 NUEVO: MOSTRAR QUÉ NÚMEROS SON LOS PARES E IMPARES
    public static String listaDePares(int[] lista) {
        List<Integer> pares = new ArrayList<>();
        for (int n : lista) if (n % 2 == 0) pares.add(n);
        return pares.isEmpty() ? "Ninguno" : pares.toString();
    }

    public static String listaDeImpares(int[] lista) {
        List<Integer> impares = new ArrayList<>();
        for (int n : lista) if (n % 2 != 0) impares.add(n);
        return impares.isEmpty() ? "Ninguno" : impares.toString();
    }

    // ============================================================
    // 6️⃣ RECURSIVIDAD: FACTORIAL Y FIBONACCI
    // ============================================================
    public static void recursividad() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nIntroduce un número para factorial y Fibonacci: ");
        int n = sc.nextInt();

        System.out.println("Factorial(" + n + ") = " + factorial(n));
        System.out.println("Fibonacci(" + n + ") = " + fibonacci(n));
    }

    public static int factorial(int n) {
        if (n <= 1) return 1;
        return n * factorial(n - 1);
    }

    public static int fibonacci(int n) {
        if (n <= 1) return n;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}
