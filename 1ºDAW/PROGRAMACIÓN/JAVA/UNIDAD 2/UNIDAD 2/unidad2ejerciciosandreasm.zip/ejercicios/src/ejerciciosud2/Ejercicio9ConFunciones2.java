package ejerciciosud2;

import java.util.ArrayList;
import java.util.List;

public class Ejercicio9ConFunciones2 {
    //Contador en Array
    public static void main (String [] args){
        List<Integer> lista = new ArrayList<>();
        lista.add(7);lista.add(4);lista.add(3);
        lista.add(10);lista.add(6);lista.add(7);
        System.out.println(lista);
        Integer n=7;
        Integer c = cuentaMultiplos(lista, n);
        System.out.println("Hay " +c+ " elementos multiplos de " +n+ " en la lista");
    }

    public static Integer cuentaMultiplos (List<Integer> lis, Integer n) {
        Integer c = 0;
        for(Integer e : lis){
            if(e%n==0){
                c ++;
            }
        }
        return c;
    }
}
