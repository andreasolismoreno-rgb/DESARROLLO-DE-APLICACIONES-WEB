package ejemplosclase;
public class Factorial {
  public static void main (String [] args)  {
      Integer n = 5;
      Long res = factorialBucle(n);
      System.out.println("El factorial de "+n+ " es " +res);
      res = factorialRecursivo(n);
      System.out.println("El factorial de "+n+ " es " +res);
  }
    public static Long factorialRecursivo (Integer n){
        Long res = null;
            if (n==0) {
                res = 1L;
            } else {
                res = n * factorialRecursivo (n-1);
            }
            return res; 
    }
    
  public static Long factorialBucle (Integer n){
      Long res = 1L;
      for ( int i = 1; i<=n;i++){
          res =  res * i;
      }
      return res;
  }
}
