package ejerciciosud2;
public class Ejercicio17 {
    public static void main(String[] args) {
        
        double euros = 100;
        double dolares = euros * 1.08;
        double libras = euros * 0.86;
        double yenes = euros * 162.33;
        
        System.out.println("===== CONVERSOR DE DIVISAS (BÁSICA) =====");
        System.out.println("Euros: " + euros);
        System.out.println("Dólares: " + dolares);
        System.out.println("Libras: " + libras);
        System.out.println("Yenes: " + yenes);
    }
}
