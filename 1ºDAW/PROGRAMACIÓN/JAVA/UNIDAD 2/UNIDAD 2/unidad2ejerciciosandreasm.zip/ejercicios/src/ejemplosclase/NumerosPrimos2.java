package ejemplosclase;
public class NumerosPrimos2 {
    public static void main (String [] args){
        System.out.println ("Primos");
        Integer res =cuentaPrimos (1000);
        System.out.println ("Hay "+ res +" primos hasta el numero 1000");
    }
    public static Integer cuentaPrimos (Integer n){
        Integer cont = 0;
        for (int i=2; i<n;i++){
            if (esPrimo(i)) {
                cont++;
            }
        }
        return cont;
    }
    public static Boolean esPrimo(Integer i){
        Boolean es = true;
        for (int j = 2; j<i; j++){
            if(i%j==0){
                es = false;
                break;
            }
        }
        return es;
    }
}