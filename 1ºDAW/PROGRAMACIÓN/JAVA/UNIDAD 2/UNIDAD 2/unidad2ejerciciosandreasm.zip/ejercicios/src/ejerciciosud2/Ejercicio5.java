package ejerciciosud2;

import java.util.ArrayList;
import java.util.List;

public class Ejercicio5 {
    public static void main(String[] args) {
        List<Integer> lista = new ArrayList<>();
        lista.add(7);lista.add(4);lista.add(3);
        lista.add(10);lista.add(6);lista.add(7);
        System.out.println(lista);
        Integer n = 3;
        Boolean enc = false;
        for (Integer e : lista) {
            if (e == n) {
                enc=true;
                break;
            }
        }
        System.out.println(enc);
         //RUN [7, 4, 3, 10, 6, 7] true
        
    }
}