package ejemplosclase;


public class FiguraTablerodeAjedrez {
    public static void main (String [] args){
        
        for (int i= 0; i < 10; i++){
            for (int j= 0; j < 10; j++){
                if (i==j || i==5 || j==4 || j+i==9) {
                    System.out.print (" 1 "); 
                } else {
                    System.out.print (" 0 "); 
                }
             }
            System.out.println(" ");
        }
    }

}
