package ejerciciosud2;

import java.util.Scanner;

public class Ejercicio15 {
        public static void main (String [] args ) {
        Scanner sc = new Scanner ( System.in);
            Integer secreto = 60;
            Integer n = null;
            do{
                System.out.println ("Deme un número :");
                n = sc.nextInt();
                
                if (n == secreto ){
                    
                    System.out.println ("Bien!!!");
                    
                }else{
                    System.out.println ("Siga buscando!!");  
                }
            } while ( n!=secreto);
            
            sc.close ();
    }
}
