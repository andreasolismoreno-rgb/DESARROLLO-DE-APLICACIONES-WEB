package ejerciciosud2;
//Serie de Fibonacci
//Pide un número n y muestra los n primeros términos de la serie de Fibonacci.
//Utiliza for y variables auxiliares.
//Si n es menor que 1, muestra un mensaje de error.

public class Ejercicio13 {
    public static void main(String[] args) {
        Integer n = 6;
        if (n < 1) {
            System.out.println("Error");
        } else if (n == 1) {
            System.out.println("1");
        } else if (n == 2) {
            System.out.println("1 1");
        } else {
            System.out.print("1 1");
            Integer anterior = 1;
            Integer anteriorAlAnterior = 1;
            for (int i = 1; i <= n-2 ; i++) {
                Integer toca = anterior + anteriorAlAnterior;
                System.out.print(" "+toca);
                anteriorAlAnterior = anterior;
                anterior = toca;
            }
        }
        System.out.println("");  
    }
}