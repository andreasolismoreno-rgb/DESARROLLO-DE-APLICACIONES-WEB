package ejerciciosud2;
import java.util.Scanner;
//
//Sistema de login con 3 intentos
//Crea un programa que simule un login:
//● Usuario correcto: admin.
//● Contraseña correcta: 1234.
//● El usuario tiene 3 intentos para acertar.
//● Usa while + if-else.
//● Si falla los 3 intentos, bloquea el acceso.
public class Ejercicio20 {
    public static void main (String [] args){
        String usuarioCorrecto = "admin";
        Integer numeroCorrecto = 1234;
        Scanner sc = new Scanner (System.in);
        System.out.println ("Deme el usuario: "); 
        String usuario = sc.next();
        System.out.println ("Deme la contraseña: "); 
        Integer numero = sc.nextInt();
        Integer contador = 1;
        
        while( !usuario.equals(usuarioCorrecto) || !numero.equals(numeroCorrecto)){
                    contador++;
                    if(contador > 3){
                        break;
                    }
                    System.out.println("No es correcto inténtelo de nuevo");
                    System.out.println ("Deme el usuario: "); 
                    usuario = sc.next();
                    System.out.println ("Deme la contraseña: "); 
                    numero = sc.nextInt();
        }
        if (contador > 3){
            System.out.println ("Me quedo con tu tarjeta");
        }else{
            System.out.println ("Logeado al intento " + contador);
        }
        
    }
}
