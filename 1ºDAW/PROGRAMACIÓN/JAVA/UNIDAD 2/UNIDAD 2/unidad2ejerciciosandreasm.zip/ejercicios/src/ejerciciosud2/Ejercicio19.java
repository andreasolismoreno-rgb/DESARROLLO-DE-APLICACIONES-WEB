package ejerciciosud2;
public class Ejercicio19 {
    public static void main(String[] args) {
        int numero = 7;
        int inicio = 1;
        int fin = 9;
        // Intercambiar si inicio > fin
        if (inicio > fin) {
            int temp = inicio;
            inicio = fin;
            fin = temp;
        }

        System.out.println("===== TABLA DE MULTIPLICAR (BÁSICA) =====");
        for (int i = inicio; i <= fin; i++) {
            if (i < 0) continue;
            System.out.println(numero + " x " + i + " = " + (numero * i));
        }
    }
}