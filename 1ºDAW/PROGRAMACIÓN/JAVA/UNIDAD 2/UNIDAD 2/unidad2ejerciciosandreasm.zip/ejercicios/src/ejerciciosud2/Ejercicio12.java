package ejerciciosud2;
//12. Menú de operaciones matemáticas
//Crea un menú con switch-case que permita:

import java.util.Scanner;

//1. Calcular el factorial de un número.
//2. Calcular la potencia de un número (base y exponente).
//3. Calcular la raíz cuadrada.
//4. Salir. 5
// Usa do-while para repetir hasta que el usuario elija salir.
public class Ejercicio12 {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        Integer opcion = null;
        do {
            System.out.println("1. Calcular el factorial de un número.");
            System.out.println("2. Calcular la potencia de un número");
            System.out.println("3. Calcular la raíz cuadrada");
            System.out.println("4. Salir");
            opcion = sc.nextInt();
            switch (opcion) {
                case 1:
                    calculaFactorial();
                    break;
                case 2:
                    calculaPotencia();
                    break;
                case 3:
                    calculaRaizCuadrada();
                    break;
                case 4:
                    System.out.println("Hasta luego!!");
                    break;
                default:
                    System.out.println("Déjate de rollo y pon un número válido");
            }
        } while (opcion != 4);
    }

    public static void calculaFactorial() {
        System.out.println("Vamos a hacer el factorial");
        Integer n = sc.nextInt();
        Integer res = 1;
        for (int i = 1; i <= n; i++) {
            res = res * i;
        }
        System.out.println("El factorial de " + n + " es " + res);
    }

    public static void calculaPotencia() {
        System.out.println("Vamos a calcular la potencia");
        System.out.println("Deme base");
        Integer base = sc.nextInt();
        System.out.println("Deme exponente");
        Integer exponente = sc.nextInt();
        System.out.println(base + "^" + exponente + " = " + Math.pow(base, exponente));
    }

    public static void calculaRaizCuadrada() {
        System.out.println("Vamos a calcular la raiz cuadrada");
        System.out.println("Deme un número");
        Integer a = sc.nextInt();
        System.out.println("La raiz cuadrada de " + a + " es " + Math.sqrt(a));
    }
}
