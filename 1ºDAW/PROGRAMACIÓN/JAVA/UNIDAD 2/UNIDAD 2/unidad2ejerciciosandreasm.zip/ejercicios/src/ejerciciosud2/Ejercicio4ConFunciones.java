/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosud2;

/**
 *
 * @author DAW1-M
 */
public class Ejercicio4ConFunciones {
    
}
