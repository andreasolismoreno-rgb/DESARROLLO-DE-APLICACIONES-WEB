package ejerciciosud2;
public class Ejercicio17Recurisvo {
    public static void main(String[] args) {
        
        double[] eurosLista = {50, 100, 250, 500};
        
        System.out.println("===== CONVERSOR DE DIVISAS (RECURSIVO) =====");
        convertirRecursivo(eurosLista, 0);
    }
    
    public static void convertirRecursivo(double[] lista, int i){
        if (i == lista.length) return;
        
        double DOLAR = 1.08;
        double LIBRA = 0.86;
        double YEN = 162.33;
        
        double euros = lista[i];
        double dolares = euros * DOLAR;
        double libras = euros * LIBRA;
        double yenes = euros * YEN;
        
        System.out.println("Euros: " + euros + " = " + dolares + " USD / " + libras + " GBP / " + yenes + " JPY");
        
        convertirRecursivo(lista, i + 1);
    }
}