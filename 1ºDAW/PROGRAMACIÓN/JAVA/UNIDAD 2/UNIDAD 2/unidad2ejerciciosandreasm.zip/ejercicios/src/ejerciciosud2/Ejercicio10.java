package ejerciciosud2;
//Media en Array
import java.util.ArrayList;
import java.util.List;
public class Ejercicio10 {
    public static void main (String [] args){
        System.out.println ("Ejercicio 10: Media de un....lo que sea");
        List <Integer> lis=new ArrayList<>();
        lis.add(7);lis.add(3);lis.add(5);lis.add(5);
        Double media =hacerMedia(lis);
        System.out.println("La media de "+ lis );
        System.out.println("Es: "+ media);
    }
    public static Double hacerMedia (List<Integer> lis){
        Double res = 0.0;
        Integer suma = 0;
        for(Integer e : lis){
            suma += e;
        }
        if (lis.size()>0){
            res = 1.0 * suma / lis.size ();
        }
        return res;
    }
            
//        }
//        res =1.0 * suma/lis.size();
//        return res;
//    }
}
//NaN significa Not A Number