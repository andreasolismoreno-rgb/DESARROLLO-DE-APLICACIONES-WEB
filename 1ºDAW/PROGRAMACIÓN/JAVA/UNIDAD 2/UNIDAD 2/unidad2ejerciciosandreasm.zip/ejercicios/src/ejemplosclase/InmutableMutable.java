package ejemplosclase;

import java.util.ArrayList;
import java.util.List;

public class InmutableMutable {
    public static void main (String [] args){
        Integer x = 7;
        pepito(x); // para crear el main de este, Alt Intro
        System.out.println("x vale "+ x);
        List <Integer> lista = new ArrayList<>();
        lista.add(5);lista.add(4);
        juanito(lista);
        System.out.println("La lista es "+lista);
    }

    private static void pepito(Integer x) {
        x = x+3;
    }

    private static void juanito(List<Integer> lista) {
        lista.add (8);
        lista.add(13);
    }
    
}
