package ejemplosclase;
public class FactorialSuma {
    public static void main (String [] args){
        Integer n = 5;
        Long res = sumaFact(n);
        System.out.println("La suma de los "+n+"primeros factoriales es " + res);
    }
    public static Long sumaFact (Integer n){
        Long suma = 0L;
        for (int i = 0; i <= n; i++) {
        suma = suma + factorialBucle(i);
        }
        return suma;
        
    }
     public static Long factorialBucle (Integer n){
      Long res = 1L;
      for ( int i = 1; i<=n;i++){
          res =  res * i;
      }
      return res;
  }
}
