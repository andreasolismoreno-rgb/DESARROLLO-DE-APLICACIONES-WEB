package ejerciciosud2;
public class Ejercicio18Recursivo {
    public static void main(String[] args) {
        int numero = 28;
        int suma = sumaDivisores(numero, 1);
        System.out.println("===== NÚMERO PERFECTO (RECURSIVO) =====");
        if (suma == numero)
            System.out.println(numero + " es perfecto.");
        else
            System.out.println(numero + " no es perfecto.");
    }

    public static int sumaDivisores(int n, int i) {
        if (i == n) return 0;
        if (n % i == 0)
            return i + sumaDivisores(n, i + 1);
        else
            return sumaDivisores(n, i + 1);
    }
}