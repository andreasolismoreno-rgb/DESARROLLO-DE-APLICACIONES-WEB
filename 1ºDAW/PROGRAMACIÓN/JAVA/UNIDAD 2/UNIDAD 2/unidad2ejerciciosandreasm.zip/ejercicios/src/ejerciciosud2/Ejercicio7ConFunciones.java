package ejerciciosud2;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
public class Ejercicio7ConFunciones {
    public static void main (String [] args){
        List <Integer> lista = creaLista();
        System.out.println (lista);
        System.out.println ("El máximo es " +calculaMaximo(lista));
    }
    public static List <Integer> creaLista() {
        List <Integer> lista = new ArrayList <>();
        lista.add(7);lista.add(4);lista.add(3);
        lista.add(10);lista.add(6);lista.add(7);
        return lista;
    }
    public static Integer calculaMaximo (List<Integer> lis){
        return Collections.max(lis);
    }
}