package ejerciciosud2;
public class NumeroPerfecto {
    public static void main (String [] args){
        for (int i = 1; i <= 10000; i++){
            if(esPerfecto(i)){
                System.out.println(i);
            }
        }
    }
    public static Boolean esPerfecto (Integer n){
        Integer suma = 0;
        for (int i = 1; i < n ; i++){
            if (n% i == 0){
                suma +=i;
            }
        }
        return suma.equals(n);
    }
}
