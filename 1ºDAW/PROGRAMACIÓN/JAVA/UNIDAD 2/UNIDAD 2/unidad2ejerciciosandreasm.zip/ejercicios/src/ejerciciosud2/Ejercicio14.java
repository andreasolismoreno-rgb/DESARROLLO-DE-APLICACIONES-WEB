package ejerciciosud2;
public class Ejercicio14 {
        public static void main(String[] args) {
        Integer n=3113;
        
        Integer numCifras = 1;
        Integer aux = n;
        while(aux/10>0){
            numCifras++;
            aux=aux/10;
        }
        System.out.println(n+" tiene "+numCifras+ " cifras");
        
        Integer nreves = 0;
        aux = n;
        for (int i = numCifras-1; i >=0 ; i--) {
            nreves += aux%10 * (int)Math.pow(10, i);
            aux = aux/10;
        }
        System.out.println("El numero al reves es "+nreves);
        if (n==nreves) {
            System.out.println("Son capicua");
        } else {
             System.out.println("No son capicua");
        }
    }
}
