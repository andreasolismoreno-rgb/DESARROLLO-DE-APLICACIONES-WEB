package ejerciciosud2;

public class SerieFibonacciRecursivo {
    public static void main (String [] args){
        for(int i = 1; i <=100 ; i++){
            System.out.println ("a" +i+ " = " + Fibonacci (i)+ " ");

        }
        System.out.println(""); 
    }
    public static Integer Fibonacci (Integer n){
        Integer res = null;
                 if (n==1 || n==2){
             res = 1;
         }
         else{
             res = Fibonacci (n-1) + Fibonacci (n-2);
         }
          return res; 
     }   
}
