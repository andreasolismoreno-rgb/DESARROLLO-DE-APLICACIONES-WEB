package ejerciciosud2;
public class Ejercicio18ConFunciones {
    public static void main(String[] args) {
        int numero = 6;
        if (esPerfecto(numero)) {
            System.out.println(numero + " es perfecto.");
        } else {
            System.out.println(numero + " no es perfecto.");
        }
    }

    public static boolean esPerfecto(int n) {
        int suma = 0;
        for (int i = 1; i < n; i++) {
            if (n % i == 0) suma += i;
        }
        return suma == n;
    }
}
