package proyecto;
public class ProyectoForExtendido {

    public static void main(String[] args) {
        int[] numeros = {3, 8, 2, 7, 9, 4, 6};
        
        System.out.println("===== PROYECTO FOR EXTENDIDO =====");
        mostrarEstadisticas(numeros);
    }

    public static void mostrarEstadisticas(int[] lista) {
        System.out.println("Lista: ");
        for (int n : lista) System.out.print(n + " ");
        System.out.println("\n----------------------------------");

        System.out.println("Suma total: " + suma(lista));
        System.out.println("Media: " + media(lista));
        System.out.println("Cantidad pares: " + contarPares(lista));
        System.out.println("Cantidad impares: " + contarImpares(lista));
        System.out.println("¿Todos pares?: " + todosPares(lista));
        System.out.println("¿Todos impares?: " + todosImpares(lista));
        System.out.println("¿Hay alguno par?: " + algunoPar(lista));
        System.out.println("¿Hay alguno impar?: " + algunoImpar(lista));
        System.out.println("Número mayor: " + mayor(lista));
        System.out.println("Número menor: " + menor(lista));
    }

    // ---- FUNCIONES REUTILIZADAS ----
    public static int suma(int[] lista) {
        int total = 0;
        for (int n : lista) total += n;
        return total;
    }

    public static double media(int[] lista) {
        return (double) suma(lista) / lista.length;
    }

    public static int contarPares(int[] lista) {
        int cont = 0;
        for (int n : lista) if (n % 2 == 0) cont++;
        return cont;
    }

    public static int contarImpares(int[] lista) {
        int cont = 0;
        for (int n : lista) if (n % 2 != 0) cont++;
        return cont;
    }

    public static boolean todosPares(int[] lista) {
        for (int n : lista) if (n % 2 != 0) return false;
        return true;
    }

    public static boolean todosImpares(int[] lista) {
        for (int n : lista) if (n % 2 == 0) return false;
        return true;
    }

    public static boolean algunoPar(int[] lista) {
        for (int n : lista) if (n % 2 == 0) return true;
        return false;
    }

    public static boolean algunoImpar(int[] lista) {
        for (int n : lista) if (n % 2 != 0) return true;
        return false;
    }

    public static int mayor(int[] lista) {
        int max = lista[0];
        for (int n : lista) if (n > max) max = n;
        return max;
    }

    public static int menor(int[] lista) {
        int min = lista[0];
        for (int n : lista) if (n < min) min = n;
        return min;
    }
}
