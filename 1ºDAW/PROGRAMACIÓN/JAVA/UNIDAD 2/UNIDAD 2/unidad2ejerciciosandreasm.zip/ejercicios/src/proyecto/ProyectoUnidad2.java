package proyecto;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ProyectoUnidad2 {
    public static void main(String[] args) {
        Integer opcion = null;
        List <Integer> lista = new ArrayList<>();
        do {            
            muestraMenu();
            opcion = elegirOpcion();
            switch (opcion) {
                case 1: System.out.println ("Adiós!!!");
                    
                    break;
                    
                case 2: System.out.println("Cargamos los datos");
                        cargarDatos(lista);
                    break;
                    
                case 3: System.out.println("Mostramos la lista actual");
                        System.out.println ("La lista es: " +lista);
                    break;
                    
                case 4: System.out.println("Estadísticas básicas");
                        muestraEstadistica(lista);
                    break;
                    
                case 5: System.out.println("Función recursiva");
                        hacerFibonacci();
                    break;
                    
                case 6: System.out.println("Filtro por condición");
                        
                    break;
                    

                default: System.out.println ("Opción no valida");

            }
        } while (opcion!=1);
    }


    public static void muestraMenu(){
        System.out.println("1.Salir");
        System.out.println("2. Cargar datos (teclado o valores demo).");
        System.out.println("3. Mostrar lista actual.");
        System.out.println("4. Estadísticas básicas: min, max, media, suma, media,...");
        System.out.println("5. Al menos una función recursiva, Fibonacci/Factorial de n-ésimo.");
        System.out.println("6. Filtro por condición (if/else) — p. ej., números positivos/negativos o ≥ umbral.");
    }
    private static Integer elegirOpcion(){
        Scanner sc = new Scanner (System.in);
        System.out.println ("Elija una opción: ");
        return sc.nextInt();
        
    }
    private static void cargarDatos(List <Integer> lista){
        lista.add(8);lista.add(4); lista.add(1); lista.add(7);
    
    }
        private static void muestraEstadistica(List<Integer> lista) {
        Integer suma =hacerSuma(lista);
        System.out.println("La suma es " + suma);
        Double media = hacerMedia(lista);
        System.out.println("La media es "+ media);
    }
        private static Integer hacerSuma(List <Integer> lista){
            Integer res=0;
            for (Integer e : lista){
                res +=e;
            }
            return res;
        }
        private static Double hacerMedia (List <Integer> lista){
            Double res =0.0;
            if (lista.size()>0) {
                res = 1.0*hacerSuma(lista)/lista.size();
            }
            return res;
        }
        private static void hacerFibonacci(){
            System.out.println("Vamos a hacer fibonacci de los 10 primeros números");
            for (int i = 1; i <= 10; i++) {
                System.out.println("Fibonacci de "+i+ " es "+fibo(i));
            }
        }
        private static Integer fibo(Integer i){
            Integer res = null;
            if (i==1 || i==2) {
                res = 1;
            } else {
                res = fibo (i-1) + fibo (i-2);
            }
            return res;
        }

}
