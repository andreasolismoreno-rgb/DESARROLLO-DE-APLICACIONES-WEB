package proyecto;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class ProyectoMio {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Integer> lista = new ArrayList<>();
        int opcion;

        // MENÚ PRINCIPAL CONTROLADO POR WHILE
        do {
            mostrarMenu();
            opcion = leerEntero(sc, "Elija una opción: ");

            switch (opcion) {
                case 1:
                    System.out.println("Adiós, programa finalizado.");
                    break;

                case 2:
                    System.out.println("Cargando datos...");
                    lista = cargarDatos(sc);
                    break;

                case 3:
                    mostrarLista(lista);
                    break;

                case 4:
                    mostrarEstadisticas(lista);
                    break;

                case 5:
                    menuRecursivo(sc);
                    break;

                case 6:
                    filtroPorCondicion(lista, sc);
                    break;

                default:
                    System.out.println(" Opción no válida. Intenta de nuevo.");
            }

            System.out.println();
        } while (opcion != 1);

        sc.close();
    }

    // =====================================================
    // 🧾 MENÚ PRINCIPAL
    // =====================================================
    public static void mostrarMenu() {
        System.out.println("==========================================");
        System.out.println("         PROYECTO UNIDAD 2");
        System.out.println("==========================================");
        System.out.println("1. Salir");
        System.out.println("2. Cargar datos (teclado o demo)");
        System.out.println("3. Mostrar lista actual");
        System.out.println("4. Estadísticas básicas (min, max, suma, media)");
        System.out.println("5. Cálculo recursivo (Fibonacci o Factorial)");
        System.out.println("6. Filtro por condición (pares / umbral)");
        System.out.println("==========================================");
    }

    // =====================================================
    // 📥 CARGA DE DATOS
    // =====================================================
    public static List<Integer> cargarDatos(Scanner sc) {
        List<Integer> lista = new ArrayList<>();
        System.out.print("¿Quieres introducir los datos manualmente (m) o usar datos demo (d)? ");
        String eleccion = sc.next();

        if (eleccion.equalsIgnoreCase("m")) {
            int n = leerEntero(sc, "¿Cuántos números vas a introducir?: ");
            for (int i = 1; i <= n; i++) {
                int valor = leerEntero(sc, "Número " + i + ": ");
                lista.add(valor);
            }
        } else {
            lista.add(7);
            lista.add(4);
            lista.add(3);
            lista.add(10);
            lista.add(6);
            lista.add(7);
            System.out.println(" Datos demo cargados.");
        }

        return lista;
    }

    // =====================================================
    // 👁️ MOSTRAR LISTA
    // =====================================================
    public static void mostrarLista(List<Integer> lista) {
        if (lista.isEmpty()) {
            System.out.println("️ La lista está vacía. Carga datos primero.");
        } else {
            System.out.println(" Lista actual: " + lista);
        }
    }

    // =====================================================
    // 📊 ESTADÍSTICAS BÁSICAS
    // =====================================================
    public static void mostrarEstadisticas(List<Integer> lista) {
        if (lista.isEmpty()) {
            System.out.println(" La lista está vacía. No hay estadísticas.");
            return;
        }

        int suma = calculaSuma(lista);
        int min = calculaMinimo(lista);
        int max = calculaMaximo(lista);
        double media = hacerMedia(lista);

        System.out.println("===== ESTADÍSTICAS =====");
        System.out.println("🔸 Suma: " + suma);
        System.out.println("🔸 Mínimo: " + min);
        System.out.println("🔸 Máximo: " + max);
        System.out.println("🔸 Media: " + media);
    }

    public static int calculaSuma(List<Integer> lista) {
        int suma = 0;
        for (int e : lista) suma += e;
        return suma;
    }

    public static int calculaMinimo(List<Integer> lista) {
        int min = lista.get(0);
        for (int e : lista) if (e < min) min = e;
        return min;
    }

    public static int calculaMaximo(List<Integer> lista) {
        int max = lista.get(0);
        for (int e : lista) if (e > max) max = e;
        return max;
    }

    public static double hacerMedia(List<Integer> lista) {
        if (lista.isEmpty()) return 0;
        return (double) calculaSuma(lista) / lista.size();
    }

    // =====================================================
    // 🔁 RECURSIVIDAD (FACTORIAL / FIBONACCI)
    // =====================================================
    public static void menuRecursivo(Scanner sc) {
        System.out.println("===== CÁLCULO RECURSIVO =====");
        System.out.println("1. Factorial");
        System.out.println("2. Fibonacci");
        int tipo = leerEntero(sc, "Elige tipo: ");

        int n = leerEntero(sc, "Introduce el número: ");

        if (tipo == 1) {
            System.out.println("El factorial de " + n + " es " + factorial(n));
        } else if (tipo == 2) {
            System.out.println("El Fibonacci de " + n + " es " + fibo(n));
        } else {
            System.out.println("⚠️ Opción no válida.");
        }
    }

    // Factorial recursivo
    public static long factorial(int n) {
        if (n <= 1) return 1;
        return n * factorial(n - 1);
    }

    // Fibonacci recursivo
    public static long fibo(int n) {
        if (n == 1 || n == 2) return 1;
        return fibo(n - 1) + fibo(n - 2);
    }

    // =====================================================
    // 🔎 FILTRO POR CONDICIÓN (IF/ELSE)
    // =====================================================
    public static void filtroPorCondicion(List<Integer> lista, Scanner sc) {
        if (lista.isEmpty()) {
            System.out.println("️ La lista está vacía.");
            return;
        }

        System.out.println("===== FILTRO POR CONDICIÓN =====");
        System.out.println("1. Suma de pares");
        System.out.println("2. Números mayores o iguales que un umbral");
        int tipo = leerEntero(sc, "Elige tipo de filtro: ");

        if (tipo == 1) {
            int suma = 0;
            for (int e : lista) {
                if (e % 2 == 0) suma += e;
            }
            System.out.println("🔸 La suma de los pares es: " + suma);
        } else if (tipo == 2) {
            int umbral = leerEntero(sc, "Introduce el valor umbral: ");
            System.out.print("🔸 Números mayores o iguales que " + umbral + ": ");
            for (int e : lista) {
                if (e >= umbral) System.out.print(e + " ");
            }
            System.out.println();
        } else {
            System.out.println(" Opción no válida.");
        }
    }

    // =====================================================
    // 🧮 LECTURA SEGURA DE ENTEROS
    // =====================================================
    public static int leerEntero(Scanner sc, String mensaje) {
        System.out.print(mensaje);
        while (!sc.hasNextInt()) {
            System.out.println("Error: ingresa un número válido.");
            sc.next();
            System.out.print(mensaje);
        }
        return sc.nextInt();
    }
}