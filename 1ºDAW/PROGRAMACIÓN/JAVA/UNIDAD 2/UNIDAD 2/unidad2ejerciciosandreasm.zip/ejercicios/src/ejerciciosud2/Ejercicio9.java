package ejerciciosud2;

import java.util.ArrayList;
import java.util.List;

public class Ejercicio9 {
    //Contador en Array
    public static void main (String [] args){
        List<Integer> lista = new ArrayList<>();
        lista.add(7);lista.add(4);lista.add(3);
        lista.add(10);lista.add(6);lista.add(7);
        System.out.println(lista);
        Integer cont = 0;
        for(Integer e : lista){
            if(e%2==0){
                cont ++;
            }
        }
        System.out.println("Hay " +cont+ " elementos pares en la lista");
    }
}
