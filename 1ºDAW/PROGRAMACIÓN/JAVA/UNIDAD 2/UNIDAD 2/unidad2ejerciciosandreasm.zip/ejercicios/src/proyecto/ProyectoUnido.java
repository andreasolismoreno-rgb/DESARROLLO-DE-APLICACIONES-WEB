package proyecto;
import java.util.Scanner;
public class ProyectoUnido {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n===== MENÚ PRINCIPAL - UNIDAD 3 =====");
            System.out.println("1️⃣ Conversor de divisas");
            System.out.println("2️⃣ Número perfecto");
            System.out.println("3️⃣ Tabla de multiplicar personalizada");
            System.out.println("4️⃣ Sistema de login (3 intentos)");
            System.out.println("5️⃣ Estadísticas básicas con for extendido");
            System.out.println("6️⃣ Recursividad (factorial y Fibonacci)");
            System.out.println("0️⃣ Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1 -> conversorDivisas();
                case 2 -> numeroPerfecto();
                case 3 -> tablaMultiplicar();
                case 4 -> login();
                case 5 -> estadisticas();
                case 6 -> recursividad();
                case 0 -> System.out.println("Saliendo del programa...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    // ============================================================
    // 1️⃣ CONVERSOR DE DIVISAS (con función)
    // ============================================================
    public static void conversorDivisas() {
        double euros = 150;
        double DOLAR = 1.08;
        double LIBRA = 0.86;
        double YEN = 162.33;

        double dolares = euros * DOLAR;
        double libras = euros * LIBRA;
        double yenes = euros * YEN;

        System.out.println("\n===== CONVERSOR DE DIVISAS =====");
        System.out.println("Euros: " + euros);
        System.out.println("Dólares: " + dolares);
        System.out.println("Libras: " + libras);
        System.out.println("Yenes: " + yenes);
    }

    // ============================================================
    // 2️⃣ NÚMERO PERFECTO (for + if)
    // ============================================================
    public static void numeroPerfecto() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nIntroduce un número: ");
        int num = sc.nextInt();

        int sumaDivisores = 0;
        for (int i = 1; i < num; i++) {
            if (num % i == 0) sumaDivisores += i;
        }

        if (sumaDivisores == num)
            System.out.println(num + " es un número perfecto ✅");
        else
            System.out.println(num + " no es perfecto ❌");
    }

    // ============================================================
    // 3️⃣ TABLA DE MULTIPLICAR PERSONALIZADA (for + if + continue)
    // ============================================================
    public static void tablaMultiplicar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nNúmero para la tabla: ");
        int num = sc.nextInt();
        System.out.print("Inicio del rango: ");
        int inicio = sc.nextInt();
        System.out.print("Fin del rango: ");
        int fin = sc.nextInt();

        if (inicio > fin) {
            int temp = inicio;
            inicio = fin;
            fin = temp;
        }

        System.out.println("===== TABLA DE " + num + " =====");
        for (int i = inicio; i <= fin; i++) {
            if (i < 0) continue;
            System.out.println(num + " x " + i + " = " + (num * i));
        }
    }

    // ============================================================
    // 4️⃣ LOGIN CON 3 INTENTOS (while + funciones)
    // ============================================================
    public static void login() {
        Scanner sc = new Scanner(System.in);
        String usuarioCorrecto = "admin";
        int passwordCorrecta = 1234;
        int intentos = 3;

        while (intentos > 0) {
            System.out.print("\nUsuario: ");
            String usuario = sc.next();
            System.out.print("Contraseña: ");
            int pass = sc.nextInt();

            if (usuario.equals(usuarioCorrecto) && pass == passwordCorrecta) {
                System.out.println("✅ Acceso concedido. Bienvenido!");
                return;
            } else {
                intentos--;
                System.out.println("❌ Usuario o contraseña incorrectos. Te quedan " + intentos + " intentos.");
            }
        }
        System.out.println("⛔ Acceso bloqueado. Demasiados intentos fallidos.");
    }

    // ============================================================
    // 5️⃣ ESTADÍSTICAS BÁSICAS (for extendido + funciones)
    // ============================================================
    public static void estadisticas() {
        int[] numeros = {3, 8, 2, 7, 9, 4, 6};

        System.out.println("\n===== ESTADÍSTICAS BÁSICAS =====");
        System.out.println("Suma: " + suma(numeros));
        System.out.println("Media: " + media(numeros));
        System.out.println("Cantidad pares: " + contarPares(numeros));
        System.out.println("Cantidad impares: " + contarImpares(numeros));
        System.out.println("¿Todos pares?: " + todosPares(numeros));
        System.out.println("¿Todos impares?: " + todosImpares(numeros));
        System.out.println("¿Alguno par?: " + algunoPar(numeros));
        System.out.println("¿Alguno impar?: " + algunoImpar(numeros));
        System.out.println("Mayor: " + mayor(numeros));
        System.out.println("Menor: " + menor(numeros));
    }

    // FUNCIONES AUXILIARES PARA ESTADÍSTICAS
    public static int suma(int[] lista) {
        int total = 0;
        for (int n : lista) total += n;
        return total;
    }

    public static double media(int[] lista) {
        return (double) suma(lista) / lista.length;
    }

    public static int contarPares(int[] lista) {
        int cont = 0;
        for (int n : lista) if (n % 2 == 0) cont++;
        return cont;
    }

    public static int contarImpares(int[] lista) {
        int cont = 0;
        for (int n : lista) if (n % 2 != 0) cont++;
        return cont;
    }

    public static boolean todosPares(int[] lista) {
        for (int n : lista) if (n % 2 != 0) return false;
        return true;
    }

    public static boolean todosImpares(int[] lista) {
        for (int n : lista) if (n % 2 == 0) return false;
        return true;
    }

    public static boolean algunoPar(int[] lista) {
        for (int n : lista) if (n % 2 == 0) return true;
        return false;
    }

    public static boolean algunoImpar(int[] lista) {
        for (int n : lista) if (n % 2 != 0) return true;
        return false;
    }

    public static int mayor(int[] lista) {
        int max = lista[0];
        for (int n : lista) if (n > max) max = n;
        return max;
    }

    public static int menor(int[] lista) {
        int min = lista[0];
        for (int n : lista) if (n < min) min = n;
        return min;
    }

    // ============================================================
    // 6️⃣ RECURSIVIDAD (Factorial y Fibonacci)
    // ============================================================
    public static void recursividad() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nIntroduce un número para factorial y Fibonacci: ");
        int n = sc.nextInt();

        System.out.println("Factorial(" + n + ") = " + factorial(n));
        System.out.println("Fibonacci(" + n + ") = " + fibonacci(n));
    }

    public static int factorial(int n) {
        if (n <= 1) return 1;
        return n * factorial(n - 1);
    }

    public static int fibonacci(int n) {
        if (n <= 1) return n;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}
