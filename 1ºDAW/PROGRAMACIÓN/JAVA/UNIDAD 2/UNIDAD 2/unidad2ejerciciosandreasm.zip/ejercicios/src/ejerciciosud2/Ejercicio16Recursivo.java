package ejerciciosud2;
import java.util.ArrayList;
import java.util.List;
public class Ejercicio16Recursivo {
    public static void main(String[] args) {
        List<Integer> notas = new ArrayList<>();
        notas.add(4);
        notas.add(7);
        notas.add(9);
        notas.add(3);
        notas.add(10);
        notas.add(5);
        notas.add(2);
        System.out.println("===== ESTADÍSTICAS DE NOTAS (RECURSIVA) =====");
        int suma = sumaRecursiva(notas, 0);
        int max = maxRecursivo(notas, 0, notas.get(0));
        int min = minRecursivo(notas, 0, notas.get(0));
        int aprobados = contarAprobados(notas, 0);
        int suspensos = notas.size() - aprobados;
        double media = 1.0 * suma / notas.size();
        
        System.out.println("Notas: " + notas);
        System.out.println("Media: " + media);
        System.out.println("Máxima: " + max);
        System.out.println("Mínima: " + min);
        System.out.println("Aprobados: " + aprobados);
        System.out.println("Suspensos: " + suspensos);
    }
    public static int sumaRecursiva(List<Integer> lista, int i){
        if (i == lista.size()) return 0;
        return lista.get(i) + sumaRecursiva(lista, i + 1);
    }
    public static int maxRecursivo(List<Integer> lista, int i, int max){
        if (i == lista.size()) return max;
        if (lista.get(i) > max) max = lista.get(i);
        return maxRecursivo(lista, i + 1, max);
    }
    public static int minRecursivo(List<Integer> lista, int i, int min){
        if (i == lista.size()) return min;
        if (lista.get(i) < min) min = lista.get(i);
        return minRecursivo(lista, i + 1, min);
    }
    public static int contarAprobados(List<Integer> lista, int i){
        if (i == lista.size()) return 0;
        int cont = lista.get(i) >= 5 ? 1 : 0;
        return cont + contarAprobados(lista, i + 1);
    }
}
