package ejerciciosud2;
public class Ejercicio17ConFunciones {
    public static void main(String[] args) {
        double euros = 200;
        convertirDivisas(euros);
    }
    
    public static void convertirDivisas(double euros){
        double DOLAR = 1.08;
        double LIBRA = 0.86;
        double YEN = 162.33;
        
        double dolares = euros * DOLAR;
        double libras = euros * LIBRA;
        double yenes = euros * YEN;
        
        System.out.println("===== CONVERSOR DE DIVISAS (FUNCIÓN) =====");
        System.out.println("Euros: " + euros);
        System.out.println("Dólares: " + dolares);
        System.out.println("Libras: " + libras);
        System.out.println("Yenes: " + yenes);
    }
}
