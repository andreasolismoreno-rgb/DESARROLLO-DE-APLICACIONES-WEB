package ejerciciosud2;
import java.util.Scanner;
public class Ejercicio20DeOtraManera {
    public static void main(String[] args) {
        iniciarSesion();
    }
    public static void iniciarSesion() {
        Scanner sc = new Scanner(System.in);
        String usuarioCorrecto = "admin";
        int numeroCorrecto = 1234;
        int intentos = 3;
        int contador = 1;

        System.out.println("===== LOGIN CON FUNCIONES =====");

        String usuario = pedirUsuario(sc, "Deme el usuario: ");
        int numero = pedirNumero(sc, "Deme la contraseña (numérica): ");

        while (!esCorrecto(usuario, numero, usuarioCorrecto, numeroCorrecto)) {
            System.out.println("No es correcto. Inténtelo de nuevo.");
            contador++;
            if (contador > intentos) break;

            usuario = pedirUsuario(sc, "Deme el usuario: ");
            numero = pedirNumero(sc, "Deme la contraseña (numérica): ");
        }

        if (contador > intentos) {
            System.out.println(" Me quedo con tu tarjeta ");
        } else {
            System.out.println("Logeado al intento " + contador);
        }
        sc.close();
    }

    public static String pedirUsuario(Scanner sc, String mensaje) {
        System.out.print(mensaje);
        return sc.next();
    }

    public static int pedirNumero(Scanner sc, String mensaje) {
        System.out.print(mensaje);
        return sc.nextInt();
    }

    public static boolean esCorrecto(String user, int pass, String correctoUser, int correctoPass) {
        return user.equals(correctoUser) && pass == correctoPass;
    }
}
