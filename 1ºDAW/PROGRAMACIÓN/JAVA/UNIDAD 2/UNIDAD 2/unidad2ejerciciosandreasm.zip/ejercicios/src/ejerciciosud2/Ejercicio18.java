package ejerciciosud2;
public class Ejercicio18 {
    public static void main(String[] args) {
        int numero = 28;
        int suma = 0;

        for (int i = 1; i < numero; i++) {
            if (numero % i == 0) {
                suma += i;
            }
        }

        System.out.println("===== NÚMERO PERFECTO (BÁSICO) =====");
        if (suma == numero) {
            System.out.println(numero + " es un número perfecto.");
        } else {
            System.out.println(numero + " no es un número perfecto.");
        }
    }
}