package proyecto;
public class ProyectoRecursividad {

    public static void main(String[] args) {
        int n = 6;

        System.out.println("===== RECURSIVIDAD =====");
        System.out.println("Factorial de " + n + " = " + factorial(n));
        System.out.println("Fibonacci de " + n + " = " + fibonacci(n));
    }

    public static int factorial(int n) {
        if (n <= 1) return 1;
        else return n * factorial(n - 1);
    }

    public static int fibonacci(int n) {
        if (n <= 1) return n;
        else return fibonacci(n - 1) + fibonacci(n - 2);
    }
}
