package ejemplosclase;
public class SeriedeFibonacci {
    public static void main (String [] args){
        Long x = fibo(30);
        System.out.println ("El fibonacci de "+30+" es: " +x);
        // a1=1 a2=1 a3=2 a4=3 a5=5 a6=8 -->
        //tres y cinco son ocho, me lo lee de esa manera, de dos en dos. 
    }
//    public static Long fibo (Integer n){
//        Long res = null;
//        if (n==1 || n==2) {
//            res = 1L;
//        } else {
//            res = fibo (n-1) + fibo (n-2);
//        }
//        return res; 
//    }
    public static Long fibo (Integer n){
        Long res = null;
        if (n==1 || n==2 || n==3) {
            res = 2L;
        } else {
            res = fibo (n-1) + fibo (n-2) + fibo (n-3);
        }
        return res; 
    }
    // a1=2 a2=2 a3=2, solo suma los 3 primeros numeros a4=6 
    //(6 + 2 + 2 son 10 )a5=10 a6=18 
}
    
