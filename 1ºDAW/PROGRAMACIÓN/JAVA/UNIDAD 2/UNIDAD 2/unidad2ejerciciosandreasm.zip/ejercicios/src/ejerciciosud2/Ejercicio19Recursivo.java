package ejerciciosud2;
public class Ejercicio19Recursivo {
    public static void main(String[] args) {
        int numero = 5;
        int inicio = -2;
        int fin = 3;

        if (inicio > fin) {
            int temp = inicio;
            inicio = fin;
            fin = temp;
        }

        System.out.println("===== TABLA DE MULTIPLICAR (RECURSIVA) =====");
        mostrarTablaRecursiva(numero, inicio, fin);
    }

    public static void mostrarTablaRecursiva(int numero, int inicio, int fin) {
        if (inicio > fin) return;
        if (inicio >= 0)
            System.out.println(numero + " x " + inicio + " = " + (numero * inicio));
        mostrarTablaRecursiva(numero, inicio + 1, fin);
    }
}