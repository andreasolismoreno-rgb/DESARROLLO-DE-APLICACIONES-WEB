package examenud2;
import java.util.ArrayList;
import java.util.List;
public class Examenud2 {

    public static void main(String[] args) {

        // ---------------- LISTAS ----------------
        List<Integer> caramelos = new ArrayList<>();
        caramelos.add(4); caramelos.add(3); caramelos.add(0); caramelos.add(5); caramelos.add(2);

        List<Integer> sustos = new ArrayList<>();
        sustos.add(5); sustos.add(10); sustos.add(7); sustos.add(8);

        List<Integer> puertas = new ArrayList<>();
        puertas.add(3); puertas.add(7); puertas.add(1); puertas.add(10);

        List<Double> calabazas = new ArrayList<>();
        calabazas.add(2.5); calabazas.add(3.0); calabazas.add(4.3); calabazas.add(0.0); calabazas.add(2.1);

        List<Integer> niveles = new ArrayList<>();
        niveles.add(7); niveles.add(3); niveles.add(-1); niveles.add(9); niveles.add(2); niveles.add(-1); niveles.add(10); niveles.add(6);

        List<String> criaturas = new ArrayList<>();
        criaturas.add("vampiro"); criaturas.add("bruja"); criaturas.add("zombie"); criaturas.add("otro");

        // ---------------- EJERCICIOS ----------------
        System.out.println("EJERCICIO 1");
        System.out.println(ejercicio1(10.0, 5, true));     
        System.out.println(ejercicio1(10.0, 55, false));   
        System.out.println(ejercicio1(10.0, 70, true));    

        System.out.println("EJERCICIO 2");
        System.out.println(ejercicio2("vampiro"));
        System.out.println(ejercicio2("bruja"));
        System.out.println(ejercicio2("cosaRara"));

        System.out.println("EJERCICIO 3");
        System.out.println("Total caramelos: " + ejercicio3(caramelos));

        System.out.println("EJERCICIO 4");
        System.out.println("Promedio: " + ejercicio4(sustos));

        System.out.println("EJERCICIO 5");
        System.out.println("Intentos: " + ejercicio5(puertas, 10));

        System.out.println("EJERCICIO 6");
        System.out.println("Calabazas procesadas: " + ejercicio6(calabazas));

        System.out.println("EJERCICIO 7");
        ejercicio7(niveles);

        System.out.println("EJERCICIO 8");
        System.out.println("Total energía: " + ejercicio8(criaturas));

        System.out.println("EJERCICIO 9");
        System.out.println("Factorial de 5: " + ejercicio9(5));

        System.out.println("EJERCICIO 10");
        ejercicio10();
    }

    //EJERCICIO 1 
    public static Double ejercicio1(Double precioBase, Integer edad, Boolean disfraz) {
        Double res = precioBase;
        if (edad < 12) res = res * 0.5;
        else if (edad >= 65) res = res * 0.7;
        if (disfraz) res = res * 0.9;
        return res;
    }

    //EJERCICIO 2 
    public static String ejercicio2(String criatura) {
        switch (criatura) {
            case "vampiro": return " vampiro =  ¡Sangreee!";
            case "bruja": return "bruja = ¡Abracadabra!";
            case "fantasma": return "fantasma = ¡Buuu!";
            case "hombreLobo": return "hombre lobo= Auuuuuu!";
            case "superman" : return "...";
            default: return "...";
        }
    }

    // EJERCICIO 3
    public static Integer ejercicio3(List<Integer> lista) {
        Integer res = 0;
        for (Integer e : lista) {
            if (e == 0) res = 0;
            else res = res + e;
        }
        return res;
    }

    //EJERCICIO 4
    public static Integer ejercicio4(List<Integer> lista) {
        Integer suma = 0;
        for (Integer e : lista) suma = suma + e;
        return suma / lista.size();
    }

    // EJERCICIO 5 
    public static Integer ejercicio5(List<Integer> puertas, Integer secreta) {
        Integer cont = 0;
        for (Integer e : puertas) {
            cont++;
            if (e.equals(secreta)) break;
        }
        return cont;
    }

    //  EJERCICIO 6 
    public static Integer ejercicio6(List<Double> pesos) {
        Integer cont = 0;
        for (Double p : pesos) {
            cont++;
            if (p == 0.0) break;
        }
        return cont;
    }

    //  EJERCICIO 7 
    public static void ejercicio7(List<Integer> lista) {
        Integer total = 0;
        Integer aptos = 0;
        for (Integer nivel : lista) {
            if (nivel == -1) continue;  // -1 = valor inválido
            total++;
            if (nivel >= 6) aptos++;
        }
        Integer porcentaje = (aptos * 100) / total;
        System.out.println("Aptos: " + aptos);
        System.out.println("Total válidos: " + total);
        System.out.println("Porcentaje aptos: " + porcentaje + "%");
    }

    //  EJERCICIO 8 
    public static Integer ejercicio8(List<String> criaturas) {
        Integer res = 0;
        for (String c : criaturas) {
            switch (c) {
                case "vampiro": res += 5; break;
                case "zombie": res += 3; break;
                case "bruja": res += 7; break;
                case "fantasma": res += 4; break;
                case "hombreLobo": res += 6; break;
                default: res += 1;
            }
        }
        return res;
    }

    //  EJERCICIO 9 
    public static Integer ejercicio9(Integer n) {
        if (n < 0) return -1;
        if (n == 0) return 1;
        return n * ejercicio9(n - 1);
    }

    //  EJERCICIO 10 
    public static void ejercicio10() {
        Integer a = 0, b = 1, c = 1;
        while (a <= 20) {
            if (a % 2 == 0) System.out.println(a);
            Integer next = a + b + c;
            a = b; b = c; c = next;
        }
    }
}