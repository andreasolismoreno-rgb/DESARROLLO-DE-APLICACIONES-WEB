/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica;
    import java.util.Scanner; // Importo la clase Scanner para leer datos por teclado
public class Practica10 {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in); // Lee datos

// 1. Pido el nombre (texto completo con espacios)
System.out.print("Introduce tu nombre: ");
String nombre = sc.nextLine(); // Uso nextLine porque quiero leer la línea entera

// 2. Pido la edad (un número entero)
System.out.print("Introduce tu edad: ");
int edad = sc.nextInt(); // Leo el entero
sc.nextLine(); // Limpio el buffer (porque el ENTER se queda pendiente)

// 3. Pido la nota media (número decimal)
System.out.print("Introduce tu nota media: ");
double nota = sc.nextDouble(); // Leo el decimal
sc.nextLine(); // Limpio otra vez por seguridad, en caso de seguir leyendo

// 4. Muestro el resultado con un mensaje
System.out.println("Hola " + nombre + ", tienes " + edad + " años y tu nota media es " + nota);

sc.close(); // Cierro el Scanner
}
}

