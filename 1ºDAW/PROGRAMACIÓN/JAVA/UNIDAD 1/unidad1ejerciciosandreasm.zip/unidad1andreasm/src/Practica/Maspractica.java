/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica;

 import java. util.Scanner;

public class Maspractica {
    public static void main (String [] args) {
        Scanner sc = new Scanner (System.in);
        System.out.print ( "Introduce un numero: ");
        int numero = sc.nextInt();
        System.out.println ("Has escrito: " + numero );
        sc.close();
    }
}
