/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica;
import java.util.Scanner;
public class Practica8 {
    
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);

System.out.print("Introduce tu edad: ");
int edad = sc.nextInt();
sc.nextLine(); // Limpia

System.out.print("Introduce tu nombre: ");
String nombre = sc.nextLine();

System.out.print("Introduce tu altura en metros: ");
double altura = sc.nextDouble();
sc.nextLine(); // Limpieza por si después usamos nextLine

System.out.print("Introduce tu ciudad: ");
String ciudad = sc.nextLine();

System.out.println("\n--- Datos introducidos ---");
System.out.println("Te llamas: " + nombre);
System.out.println("Tienes: " + edad);
System.out.println("Mides: " + altura + " m");
System.out.println("Vives en: " + ciudad);
}
}
