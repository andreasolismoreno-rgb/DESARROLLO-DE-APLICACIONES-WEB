/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica;

public class Precedencia_de_multiplicacion_sobre_suma {
    public static void main (String []args){
        int res = 2 + 3 * 4 ; //Primero se hace 3*4=12, luego 2+12=14
        System.out.println(res); // 14
    }
}
