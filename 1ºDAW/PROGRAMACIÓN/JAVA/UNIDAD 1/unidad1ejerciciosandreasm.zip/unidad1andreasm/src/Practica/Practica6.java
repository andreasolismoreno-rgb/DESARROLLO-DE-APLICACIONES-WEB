/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica;
import java.util.Scanner;
public class Practica6 {
    
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);


System.out.print("¿Te gusta leer? (true o false) : ");
boolean gusta = sc.nextBoolean(); // Lee true o false

if (gusta) {
System.out.println("¡Genial!");
} else {
System.out.println("No pasa nada, con el tiempo puede gustarte más.");
}

sc.close();
}}
