/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica;

import java.util.Scanner;

public class Practica4 {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);

System.out.print("Introduce el precio de un producto: ");
double precio = sc.nextDouble(); // Lee el número decimal // 22
System.out.println("El precio con IVA es: " + (precio * 1.21)); 
                                //26.619999999999997

sc.close();
}
} 

