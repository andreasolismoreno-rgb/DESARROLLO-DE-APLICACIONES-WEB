/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica;
import java.util.Scanner;
public class Practica7 {

public static void main(String[] args) {
Scanner sc = new Scanner(System.in);

System.out.print("Dime tu edad: ");
int edad = sc.nextInt();

sc.nextLine(); // Limpia el buffer

System.out.print("Dime tu nombre: ");
String nombre = sc.nextLine();

System.out.println("Tienes : " + edad);
System.out.println("Tu Nombre es: " + nombre);
}
}

