
package Practica;

import java.util.Scanner;
public class Practica5 {
  
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);

System.out.print("Introduce tu nombre completo: "); //Andrea Solis
String nombre = sc.nextLine(); // Lee toda la línea
System.out.println("Hola " + nombre + ", bienvenido!");
//Hola Andrea Solis, bienvenido!

sc.close();
}
} 
