/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica;
import java.util.Scanner;

public class Practica3 {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);

System.out.print("Introduce tu edad: "); //21
int edad = sc.nextInt(); // Lee el entero
System.out.println("Dentro de 10 años tendrás " + (edad + 10)); 
 //Dentro de 10 a�os tendr�s 31
sc.close();
}
}

