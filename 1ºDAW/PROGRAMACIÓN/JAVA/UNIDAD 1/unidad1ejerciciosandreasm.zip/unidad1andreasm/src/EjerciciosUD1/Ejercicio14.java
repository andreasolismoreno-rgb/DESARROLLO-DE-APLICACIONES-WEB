
package EjerciciosUD1;

public class Ejercicio14 {
    public static void main (String [] args){
       // Declara un array de 5 enteros, inicialízalo con valores del 1 al 5 y
      //muéstralos con un bucle.
      int[] nums = {1,2,3,4,5};  // creo un array con 5 números
      for(int n: nums){          // recorro cada número con un bucle
      System.out.println(n); // imprimo cada número
}

}
}
