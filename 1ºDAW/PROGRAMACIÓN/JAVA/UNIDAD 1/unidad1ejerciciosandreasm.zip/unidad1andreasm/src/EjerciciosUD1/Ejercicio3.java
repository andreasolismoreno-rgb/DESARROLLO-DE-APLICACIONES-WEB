/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosUD1;

public class Ejercicio3 {
  public static void main (String [] args){
       //Declara una constante final llamada PI con valor 3.1416 y úsala en un cálculo 
       //del área de un círculo.
       
        final double PI = 3.1416; // Nombro una constante llamada PI, 
                                  //y double porque se tarata de un número decimal
        double radio = 2;         // creo una variable radio con valor 2
        double area = PI * radio * radio; // calculo el área con la fórmula PI * r^2
        System.out.println(area); {// muestro el resultado = 12.5664
  }
  }  
}
