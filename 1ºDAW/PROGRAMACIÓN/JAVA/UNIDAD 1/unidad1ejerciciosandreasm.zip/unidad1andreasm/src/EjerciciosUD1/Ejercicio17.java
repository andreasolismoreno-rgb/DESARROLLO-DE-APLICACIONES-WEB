
package EjerciciosUD1;

public class Ejercicio17 {
    public static void main (String [] args){
        //Escribe un programa que compare dos números e indique si son iguales, 
        //distintos, mayor o menor.
        int a = 5, b = 7;
        if(a == b) System.out.println("Son iguales");    // si son iguales
        else if(a > b) System.out.println("a es mayor"); // si a es más grande
        else System.out.println("a es menor");           // si es más pequeño 

    }
}
