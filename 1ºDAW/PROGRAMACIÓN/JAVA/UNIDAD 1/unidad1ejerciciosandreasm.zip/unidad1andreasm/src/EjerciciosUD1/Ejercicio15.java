
package EjerciciosUD1;

public class Ejercicio15 {
    public static void main(String[]args){
         //Crea un array de 3 String usando new y guarda 
         //en él los nombres de tres ciudades.
        String[] ciudades = new String[3]; // creo un array de 3 Strings
        ciudades[0] = "Sevilla";          // guardo la primera ciudad
        ciudades[1] = "Barcelona";           // guardo la segunda ciudad
        ciudades[2] = "Cádiz";          // guardo la tercera ciudad

    }
}
