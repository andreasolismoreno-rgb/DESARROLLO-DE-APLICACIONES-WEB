/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosUD1;
public class Ejercicio5 {
    // Declara una variable contador = 5. Aplica ++contador y contador++ y
   //muestra las diferencias.
    public static void main (String [] args){
        int n = 5; //guardo este numero
        System.out.println(n++); // imprime 5, luego n=6 ( es post-incremento)
                                 //este primero USA el valor actual de n, 
                                 //que es cinco, y luego lo incrementa, que sería seis.
        System.out.println(++n); // primero incrementa a 7, luego imprime7 (es pre-incremento)
                                //este primero INCREMENTA n y luego lo usa,
                                 //n era seis, ahor apasa a ser siete y luego se imprime.

    }
}

