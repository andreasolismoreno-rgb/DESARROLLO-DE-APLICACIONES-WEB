package EjerciciosUD1;

public class Ejercicio12 {
    public static void main(String [] args){
        //Declara una variable char con la letra ñ usando su código Unicode.
        //La letra ñ tiene el código U+00F1 
        char letra = '\u00F1';  // código unicode para ñ
        System.out.println(letra);   // muestra la letra ñ

    }
}
