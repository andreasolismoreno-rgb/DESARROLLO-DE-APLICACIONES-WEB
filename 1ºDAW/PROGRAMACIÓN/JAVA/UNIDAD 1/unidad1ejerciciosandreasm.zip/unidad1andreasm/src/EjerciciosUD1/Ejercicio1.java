/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package EjerciciosUD1;

public class Ejercicio1 {

    public static void main(String[] args) {
        //1. Identificadores válidos e inválidos
        // Válidos
        
        //int edad;             // Empieza con letra
        //int clase1;           // Es igual al caso anterior, empieza con una letra y
                                //puede llevar número pero nunca al inicio
                                
        //int nombreCompleto;   // tiene una variable, un camelCase
        //int PI;               // es una constante en mayúsculas
        //int nombre_Completo;  // tiene un guion bajo
        
        //No Válidos
        
        //int 21edad;        //Empieza con número y jamás se debería empezar así
        //int class; //Es una paalabra reservada en Java
        //double altura-media; Ese guión no está permitido
        //int char; // Es una palabra reservada en Java
        //int MAXVALOR; //Las mayúsculas deben ir separadas con guiones
    }
}
