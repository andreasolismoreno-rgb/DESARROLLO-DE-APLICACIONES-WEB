/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosUD1;

public class Ejercicio10 {
    public static void main (String [] args){
     //Declara un float y un double con valores de temperaturas y calcula la media.
    float t1 = 36.6f;  // uso f al final porque es float
    double t2 = 37.2;      // double no necesita letra al final
    double media = (t1+t2)/2; // sumo y divido entre 2 para sacar la media
    System.out.println(media); // imprimo la media que es 36.89999923706055

    }
}
