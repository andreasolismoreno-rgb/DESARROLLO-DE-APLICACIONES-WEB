
package EjerciciosUD1;

public class Ejercicio20 {
    public static void main (String []args){
        //Evalúa la expresión x + y / 2 * 3 con x=4, 
        //y=6 y explica el orden en que se resuelven las operaciones.
        
         int x = 4, y = 6;
         int res = x + y / 2 * 3; // primero y/2=3, luego 3*3=9, luego 4+9=13
         System.out.println(res); // el resultado final es 13
    }
}
