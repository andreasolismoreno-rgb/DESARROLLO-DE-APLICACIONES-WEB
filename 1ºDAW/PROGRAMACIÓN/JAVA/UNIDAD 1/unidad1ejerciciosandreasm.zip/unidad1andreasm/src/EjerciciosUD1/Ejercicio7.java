
package EjerciciosUD1;

public class Ejercicio7 {
    public static void main (String [] args){
        //Declara una
        //variable x en un bloque externo y otra y en un bloque interno.
        //Intenta acceder a y desde fuera y explica el error.
        
        int x = 5;          // Guardo la variable del bloque externo
         //Aquí pongo la llave abierta  
        int y = 10;       // Guardo la variable del bloque interno
    
         System.out.println(x); // x sí existe
         System.out.println(y); // y también existe
         //Aquí pongo la llave cerrada y ya no se me guarda la variable "y" 
          System.out.println(x); // x sigue existiendo
          System.out.println(y); // y ya no, me da error 
                                  //"cannot find symbol: variable y"
}
}
