
package EjerciciosUD1;

public class Ejercicio18 {
    public static void main (String[]args){
        //Declara dos variables booleanas a=true, b=false. 
        //Muestra el resultado de a && b, a || b y !a.
        boolean a = true, b = false;

        System.out.println(a && b); // true AND false es false
        System.out.println(a || b); // true OR false es  true
        System.out.println(!a);     // NOT true es false
    }
}
