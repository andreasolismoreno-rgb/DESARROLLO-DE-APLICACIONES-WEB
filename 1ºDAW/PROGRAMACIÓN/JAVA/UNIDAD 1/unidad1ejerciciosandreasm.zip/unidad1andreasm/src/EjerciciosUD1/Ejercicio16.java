/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosUD1;

/**
 *
 * @author Usuario
 */
public class Ejercicio16 {
    public static void main (String [] args){
        //Declara un String con tu nombre y 
        //concaténalo con tu apellido usando +.
        String nombre = "Andrea";                 // guardo mi nombre
        String completo = nombre + " Solis";      // concateno con mi apellido
        System.out.println(completo);             // muestro nombre completo

    }
}


