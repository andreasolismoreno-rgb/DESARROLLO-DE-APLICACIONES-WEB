package EjerciciosUD1;
public class Ejercicio8 {
    public static void main(String[] args) {
        // Declara variables de tipo byte, short, int y long 
        //con valores distintos
        
        byte b = 10;   // ocupa 1 byte
        short s = 100; // ocupa 2 bytes
        int i = 1000;  // ocupa 4 bytes
        long l = 10000L; // ocupa 8 bytes

        System.out.println(b + " " + s + " " + i + " " + l); 
         // imprimo todo y sale seguido= 10 100 1000 10000
    }
}
