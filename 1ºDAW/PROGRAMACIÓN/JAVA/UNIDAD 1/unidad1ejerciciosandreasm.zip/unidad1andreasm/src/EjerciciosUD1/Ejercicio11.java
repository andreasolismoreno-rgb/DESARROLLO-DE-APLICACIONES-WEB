package EjerciciosUD1;

public class Ejercicio11 {
    public static void main (String [] args){
        // Declara un boolean
        //que indique si una persona es mayor de edad. Hazlo depender de una
        //variable edad.
        int edad = 21;               // guardo la edad
        boolean mayor = edad >= 18;  // comparo si es mayor de edad
        System.out.println(mayor);   // sale true si tiene 18 o más 

    }
}
