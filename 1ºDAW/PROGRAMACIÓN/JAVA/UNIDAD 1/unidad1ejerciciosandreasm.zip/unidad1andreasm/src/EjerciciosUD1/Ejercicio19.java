
package EjerciciosUD1;

public class Ejercicio19 {
    public static void main (String [] args){
        //Declara dos enteros 12 y 13. Aplica &, |, ^ y ~ 
        //y muestra los resultados
       int a = 12, b = 13;

        System.out.println(a & b); // significa AND, el resultado es 12
        System.out.println(a | b); // significa OR, el resultado es 13
        System.out.println(a ^ b); // significa XOR, el resultado es 1
        System.out.println(~a);    // significa NOT → -13 niega todos los bits de "a"
    }
}
