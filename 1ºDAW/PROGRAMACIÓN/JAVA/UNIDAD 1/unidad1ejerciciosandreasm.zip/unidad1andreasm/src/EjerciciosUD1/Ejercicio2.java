/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosUD1;


public class Ejercicio2 {
   public static void main (String []args){
    //Haz una lista de 10 palabras clave de Java y escribe una línea de código usando
    //cada una correctamente. 
    
    //public class // Tanto como public, como class son palabras claves
    //public static void main (String[]args){ 
    //int x=2 // int es una palabra clave, lee un numero entero
    // if a=2 // if sirve para tomar decisiones
    //final double; // final es para constante y double para numeros decimales
    //System.out.print // escribe sin salto de linea
    //System.out.println // escribe con salto de línea
    //System.out.printf //formato similar a c
}
}