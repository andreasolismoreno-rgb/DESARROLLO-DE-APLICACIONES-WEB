/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosUD1;

public class Ejercicio4 {
    //Crea un programa que sume, reste, multiplique, divida y saque el módulo
      //entre dos números enteros.
  public static void main (String []args){
      int a= 22; //guardo este número
      int b = 10; //guardo este número
      
      System.out.println (a+b); //aqui sumo a y b que sería 32
      System.out.println (a-b); //aqui resto a y b que sería 12
      System.out.println (a*b); //aqui multiplico a y b que sería 220 
      System.out.println (a/b); // aqui divido a y b que como número entero sería 2
      System.out.println (a%b); // aqui saco el módulo de a y b que el resto sería 0
      
  }  
}
