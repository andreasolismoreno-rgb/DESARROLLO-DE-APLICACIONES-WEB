
package EjerciciosUD1;
public class Ejercicio13 {
    public static void main (String [] args){
        //Convierte un double de valor 9.99 a int y observa el resultado.
        double x = 9.99;  // pongo double porque se trata de un número decimal 
        int y = (int)x;   // al convertirlo se pierde la parte decimal
        System.out.println(y); // el resultado es 9


    }
}
