
package EjerciciosUD1;

public class Ejercicio19 {
    public static void main (String [] args){
        //Declara dos enteros 12 y 13. Aplica &, |, ^ y ~ 
        //y muestra los resultados
       int a = 12, b = 13;

        System.out.println(a & b); // AND bit a bit es 12
        System.out.println(a | b); // OR bit a bit es 13
        System.out.println(a ^ b); // XOR bit a bit es 1
        System.out.println(~a);    // NOT → -13 niega todos los bits
    }
}
