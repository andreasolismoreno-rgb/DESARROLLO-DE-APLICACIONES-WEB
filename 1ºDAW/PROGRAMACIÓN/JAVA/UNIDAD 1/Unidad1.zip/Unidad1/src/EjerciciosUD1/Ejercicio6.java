
package EjerciciosUD1;
public class Ejercicio6 {
    //Escribe una expresión que verifique si un número x está entre 10 y 20.
    public static void main (String [] args){
    int x = 77;                          // guardo un número cualquiera
    boolean dentro = (x > 10 && x < 20); // pregunto si está entre 10 y 20
    System.out.println(dentro);         // true si se cumple, false es que no
                           // como el numero que pongo es 13 me dice que es true

    }
}
