package EjerciciosUD1;

public class Ejercicio9 {
    public static void main (String []args){
        //Representa el número decimal 25 en formato decimal, octal y hexadecimal.
        int decimal = 25;  // número normal
        int octal = 031;   // el 0 al inicio indica octal → es 25 en decimal
        int hexadecimal = 0x19;    // 0x indica hexadecimal → es 25 en decimal

    }
}
