package ejercicios; //El paquete al que pertenece esta clase.
import java.util.InputMismatchException; 
import java.util.Scanner;//Scanner para poder leer datos del teclado
public class Ejercicio1 { //Clase principal del programa

    public static void main(String[] args) { // Método principal: punto de entrada del programa.
        Scanner sc = new Scanner(System.in); // Se crea un objeto Scanner para leer datos del teclado
        
            System.out.println ("Introduzca la edad del pensionista");// Pedimos al usuario que introduzca la edad
        try{  // Primer bloque try-catch: manejará errores relacionados con la edad
            
            Integer edad = sc.nextInt(); // Se lee un número entero introducido por el usuario
            if (edad>=130){ // Si la edad es igual o superior a 130, se lanza una excepción
                throw new IllegalArgumentException();// Lanza una excepción de este tipo
                
            }
            System.out.println ("Bienvenido, acaba de cobrar usted su pensión"); 
            // Si no se lanza ninguna excepción, se muestra este mensaje

        }catch (IllegalArgumentException e){ //Este catch captura la excepción IllegalArgumentException lanzada 
                                            //si la edad es mayor o igual que 130
            System.err.println("Más que 130 años? Tú estás loco?");
        }catch (Exception e){// Este catch captura cualquier otra excepción no prevista en el bloque anterior
            System.err.println ("Algo raro ha pasado " +e );
        }
        
        
            System.out.println ("Introduzca la altura");  // Pedimos al usuario que introduzca su altura
        try{ // Segundo bloque try-catch: manejará errores relacionados con la altura
            Double altura = sc.nextDouble(); // Se lee un número decimal introducido por el usuario
            
            if(altura >= 2.5){// Si la altura es mayor o igual a 2.5 metros, se lanza una excepción
                throw new IllegalArgumentException(); // Lanza una excepción de este tipo
            }
            System.out.println("Tienes" + altura + "metros, puede pasar");// Si la altura es válida, muestra este mensaje
        }catch(IllegalArgumentException e){ // Captura la excepción cuando la altura es demasiado alta
                                            
            System.err.println("Lo siento, demasiado alto");//Lanza este mensaje 
        }catch (InputMismatchException e){// Captura la excepción si el usuario introduce un tipo de dato incorrecto 
                                         //(por ejemplo, texto o usa punto en lugar de coma)
            System.err.println("Usa números con comas y  no puntos para los decimales");
            
        }catch (Exception e){ // Captura cualquier otra excepción no contemplada antes
            System.err.println ("Algo raro ha pasado " +e );
        }
                
            System.out.println ("Gracias por usar este programa");// Mensaje final del programa
    }
    
}

