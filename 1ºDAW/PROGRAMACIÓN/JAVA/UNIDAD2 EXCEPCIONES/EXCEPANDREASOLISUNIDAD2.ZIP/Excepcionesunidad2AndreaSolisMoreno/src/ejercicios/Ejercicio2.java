package ejercicios;
import java.util.InputMismatchException;// InputMismatchException para manejar errores de tipo de datos 
import java.util.Scanner;// Scanner permite leer datos del teclado
public class Ejercicio2 { //Clase pirncipal del programa
    public static void main(String[] args) { // Método principal: punto de inicio del programa
        
        Scanner sc = new Scanner(System.in); // Se crea un objeto Scanner para leer datos del teclado

        System.out.println("Introduzca el peso del paciente"); //Pedimos al usuario que introduzca el peso del paciente
        try { // Primer bloque try-catch: manejo de excepciones relacionadas con el peso
            
            Integer peso = sc.nextInt();// Se lee un número entero, es decir, el peso introducido por el usuario.

            if (peso < 50) { // Si el peso es menor de 50 kg, se lanza una excepción manualmente
                throw new IllegalArgumentException();  // Lanza excepción indicando que el peso, 
                                                       //el número entero introducido no es válido.
            }

            System.out.println("Tienes el peso perfecto para participar en la campaña de donación de sangre");
            // Si el peso es mayor de 50 kg, se muestra este mensaje
            
        } catch (IllegalArgumentException e) { // Captura la excepción IllegalArgumentException lanzada si el peso es menor de 50

            System.err.println("¿Menos de 50 kilos? No podemos sacarle sangre, sería peligroso para usted"); //Muestra este mensaje
            
        } catch (Exception e) {// Captura cualquier otra excepción no contemplada antes
            System.err.println("Algo raro ha pasado " + e);
        }

        System.out.println("Introduzca la altura");// Pedimos al usuario que introduzca la altura.

        System.out.println("Introduzca la edad del paciente"); // Pedimos al usuario que introduzca la edad del paciente

        
        try {// Segundo bloque try-catch: manejo de excepciones relacionadas con la edad
            
            Integer edad = sc.nextInt();// Se lee un número entero introducido por el usuario (edad)

            
            if (edad < 18) { // Si la edad es menor a 18, se lanza una excepción
                throw new IllegalArgumentException();  // Lanza excepción por ser menor de edad
            }
            System.out.println("Eres mayor de edad, puedes realizar el procedimiento");// Si la edad es válida, se muestra el mensaje

        } catch (IllegalArgumentException e) {// Captura la excepción si la edad < 18
            System.err.println("Lo siento, eres menor de edad");

        } catch (Exception e) {// Captura cualquier otra excepción
            System.err.println("Algo raro ha pasado " + e);
        }

        try { // Tercer bloque try-catch: manejo de excepciones relacionadas con la altura
            Double altura = sc.nextDouble(); // Se lee un número decimal, la altura.

            if (altura <1.50) { // Si la altura es menor a 1.50 m, se lanza una excepción
                throw new IllegalArgumentException();  // Lanza excepción por no cumplir la altura mínima
            }

            System.out.println("Tienes " + altura + " metros, puede pasar");// Si la altura es válida, se muestra el mensaje

        } catch (IllegalArgumentException e) { // Captura la excepción cuando la altura es demasiado baja
            System.err.println("Lo siento, demasiado bajo, no tienes la altura mínima");

        } catch (InputMismatchException e) {// Captura la excepción si el usuario introduce un tipo de dato incorrecto (por ejemplo, usa punto en vez de coma)
            System.err.println("Usa números con comas y no puntos para los decimales");

        } catch (Exception e) {// Captura cualquier otra excepción no prevista
            System.err.println("Algo raro ha pasado " + e);
        }

        System.out.println("Gracias por usar este programa");// Mensaje final del programa
    }
}
