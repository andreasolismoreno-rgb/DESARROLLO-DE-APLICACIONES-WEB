package fp.feria;

import fp.utiles.Checkers;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class CasetaFeria implements Comparable<CasetaFeria> {

    // Propiedades básicas (Atributos)
    private String nombre;
    private TipoCaseta tipo;
    private Integer modulo;
    private Integer aforo;
    private Set<Producto> menu;
    private String musica;
    private Boolean accesoAdaptado;
    private Double valoracion;

    // Constructor C1
    public CasetaFeria(String nombre, TipoCaseta tipo, Integer modulo, Integer aforo,
            Set<Producto> menu, String musica, Boolean accesoAdaptado, Double valoracion) {

//        // R1: La valoración debe estar comprendida entre 0 y 100
//        if (valoracion < 0 || valoracion > 100) {
//            throw new IllegalArgumentException("La valoración debe estar entre 0 y 100");
//        }
//        // R2: Debe haber al menos un elemento dentro del menú
//        if (menu == null || menu.isEmpty()) {
//            throw new IllegalArgumentException("El menú no puede estar vacío");
//        }

        Checkers.check("La valoración debe estar comprendida entre 0 y 100 debe ser posotivo.", valoracion >=0.0 && valoracion <=100.0 );
        Checkers.check("Debe haber al menos un elemento dentro del menú", menu.size()>0);


        this.nombre = nombre;
        this.tipo = tipo;
        this.modulo = modulo;
        this.aforo = aforo;
        this.menu = new HashSet<>(menu); 
        this.musica = musica;
        this.accesoAdaptado = accesoAdaptado;
        this.valoracion = valoracion;
    }

    // --- MÉTODOS CONSULTABLES (Getters) ---
    public String getNombre() {
        return nombre;
    }

    public TipoCaseta getTipo() {
        return tipo;
    }

    public Integer getModulo() {
        return modulo;
    }

    public Integer getAforo() {
        return aforo;
    }

    public Set<Producto> getMenu() {
        return new HashSet<>(menu);
    }

    public String getMusica() {
        return musica;
    }

    public Boolean getAccesoAdaptado() {
        return accesoAdaptado;
    }

    public Double getValoracion() {
        return valoracion;
    }

    // --- MÉTODOS MODIFICABLES (Setters) ---
    public void setMusica(String musica) {
        this.musica = musica;
    }

    public void setValoracion(Double valoracion) {
        // Volvemos a aplicar la restricción R1
        if (valoracion < 0 || valoracion > 100) {
            throw new IllegalArgumentException("La valoración debe estar entre 0 y 100");
        }
        this.valoracion = valoracion;
    }

    // --- PROPIEDADES CALCULADAS ---
    // Precio medio: media de precios de todos los platos del menú
    public Double getPrecioMedio() {
        //return menu.stream().allMatch(p->p.precio()>0);

        Double res=0.0;
        Double suma = 0.0;
        for (Producto p : menu) {
            suma += p.precio(); // p.precio() porque Producto es un record
        }
        if (menu.size()>0){
            res=suma/menu.size();
        }
        return res;
    }

    // Caseta barata: true si TODOS los productos < 10 euros
    public Boolean getCasetaBarata() {
        //return menu.stream().allMatch(p->p.precio()<10.0);
        Boolean res = true;
        for (Producto p : menu) {
            if (p.precio() >= 10.0) {
                res = false;
                break;
            }
        }
        return res;
    }

    // REPRESENTACIÓN COMO CADENA
    @Override
    public String toString() {
        return "CasetaFeria [nombre=" + nombre + ", tipo=" + tipo + ", modulo=" + modulo + ", aforo=" + aforo
                + ", menú=" + menu.size() + " productos, musica=" + musica + ", accesoAdaptado=" + accesoAdaptado
                + ", valoracion=" + valoracion + "]";
    }

    // CRITERIO DE IGUALDAD (equals y hashCode)
    @Override
    public int hashCode() {
        return Objects.hash(modulo, nombre);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        CasetaFeria other = (CasetaFeria) obj;
        return Objects.equals(modulo, other.modulo) && Objects.equals(nombre, other.nombre);
    }

    // CRITERIO DE ORDENACIÓN (Comparable)
    // Orden por número de módulo y, en caso de igualdad, por nombre
    @Override
    public int compareTo(CasetaFeria o) {
        int res = this.modulo.compareTo(o.modulo);
        if (res == 0) {
            res = this.nombre.compareTo(o.nombre);
        }
        return res;
    }
}
