package fp.feria;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class Feria {

    private Integer anyo;
    private Set<CasetaFeria> casetas;

    // C1: Constructor con conjunto de casetas y año actual
    public Feria(Set<CasetaFeria> casetas) {
        this.anyo = LocalDate.now().getYear();// Año en curso según el enunciado
        this.casetas = new HashSet<>(casetas);
    }

    public Integer getAnyo() {
        return anyo;
    }

    public Set<CasetaFeria> getCasetas() {
        return new HashSet<>(casetas);
    }

    public Integer getNumeroCasetas() {
        return casetas.size();
    }

    public void incorporaCaseta(CasetaFeria c) {
        casetas.add(c);
    }

    public void eliminaCaseta(CasetaFeria c) {
        casetas.remove(c);
    }

    @Override
    public String toString() {
        return anyo + " (" + getNumeroCasetas() + " casetas)";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Feria other = (Feria) obj;
        return Objects.equals(anyo, other.anyo) && Objects.equals(casetas, other.casetas);
    }

    @Override
    public int hashCode() {
        return Objects.hash(anyo, casetas);
    }
}
