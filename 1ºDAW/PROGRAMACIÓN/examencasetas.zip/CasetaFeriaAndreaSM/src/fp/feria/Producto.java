package fp.feria;

import fp.utiles.Checkers;

/**
 * Ejercicio 1: Tipo Producto
 * Implemente en el paquete fp.feria el tipo Producto mediante un record, de acuerdo con la
    siguiente información:
 * Representa un producto gastronómico con su nombre y precio (ambos consultables).
 */
public record Producto(String nombre, Double precio) {
    public Producto {
        Checkers.checkNoNull(nombre, precio);
        Checkers.check("El precio debe ser posotivo.", precio >=0.0);
        
    }

    public String getNombre() {
        return nombre;
    }

    public Double getPrecio() {
        return precio;
    }

   
}