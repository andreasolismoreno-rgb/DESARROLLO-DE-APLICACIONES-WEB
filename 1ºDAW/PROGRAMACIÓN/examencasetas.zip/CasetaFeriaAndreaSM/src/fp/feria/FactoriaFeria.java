package fp.feria;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FactoriaFeria {

    // Lee el fichero y devuelve un conjunto de casetas
    public static Set<CasetaFeria> leerCasetas(String rutaFichero) {
        Set<CasetaFeria> res = new HashSet<>();
        try {
            List<String> lineas = Files.readAllLines(Paths.get(rutaFichero));
            // Saltamos la primera línea si tiene cabecera (opcional)
            for (String linea : lineas) {
                res.add(parseaCaseta(linea));
            }
        } catch (IOException e) {
            System.out.println("No se pudo leer el fichero: " + e.getMessage());
        }
        return res;
    }

    public static CasetaFeria parseaCaseta(String linea) {
        String[] trozos = linea.split(";");
        String nombre = trozos[0].trim();
        TipoCaseta tipo = TipoCaseta.valueOf(trozos[1].trim().toUpperCase());
        Integer modulo = Integer.parseInt(trozos[2].trim());
        Integer aforo = Integer.parseInt(trozos[3].trim());

        Set<Producto> menu = new HashSet<>();
        String[] productos = trozos[4].split(",");
        for (String p : productos) {
            String[] datos = p.split("-");
            menu.add(new Producto(datos[0].trim(), Double.parseDouble(datos[1].trim())));
        }

        String musica = trozos[5].trim();
        Boolean acceso = trozos[6].trim().equalsIgnoreCase("si");
        Double valoracion = Double.parseDouble(trozos[7].trim());

        return new CasetaFeria(nombre, tipo, modulo, aforo, menu, musica, acceso, valoracion);
    }
}
