package fp.feria;

import java.util.*;

public class FeriaGestion extends Feria {

    public FeriaGestion(Set<CasetaFeria> casetas) {
        super(casetas);
    }

    @Override
    public String toString() {
        String cad = super.toString();
        for (CasetaFeria c : getCasetas()) {
            cad += "\n" + c.toString();
        }
        return cad;
    }

//	1.getPrecioMaxProducto: Dado un tipo de caseta (pública o privada), devuelve un Map donde las
//	claves son los nombres de los productos ofertados en casetas de ese tipo, y los valores el precio
//	máximo registrado para ese producto en todas las casetas. Implemente este método con bucles.
//	(1,5 ptos)
    public Map<String, Double> getPrecioMaxProducto(TipoCaseta tipo) {
        Map<String, Double> res = new HashMap<>();
        for (CasetaFeria c : getCasetas()) {
            if (c.getTipo().equals(tipo)) {
                for (Producto p : c.getMenu()) {
                    if (!res.containsKey(p.nombre()) || p.precio() > res.get(p.nombre())) {
                        res.put(p.nombre(), p.precio());
                    }
                }
            }
        }
        return res;
    }

    //	2. getValoracionMediaTipoCasetaAccesible: Dado un tipo de caseta (pública o privada) y un booleano
//	que representa un valor de accesibilidad, devuelve la valoración media de todas las casetas de ese
//	tipo que tengan el acceso adaptado según el valor indicado. Si no hay casetas que cumplan ambas
//	condiciones, el método debe devolver 0.0. (1 pto)
//    public Double getValoracionMediaTipoCasetaAccesible(TipoCaseta tipo, Boolean b) {
//        return getCasetas().stream().filter(c -> c.getTipo().equals(tipo))
//                .filter(c -> c.getAccesoAdaptado().equals(b))
//                .mapToDouble(c -> c.getValoracion())
//                .average()
//                .orElse(0.0);
//    }
    public Double getValoracionMediaTipoCasetaAccesible(TipoCaseta tipo, Boolean esAccesible) {
        Double suma = 0.0;
        Integer res = 0;
        for (CasetaFeria c : getCasetas()) {
            if (c.getTipo().equals(tipo) && c.getAccesoAdaptado().equals(esAccesible)) {
                suma += c.getValoracion();
                res++;
            }
        }

        if (res == 0) {
            return 0.0;
        } else {
            return suma / res;
        }
    }

    //	3. getNombresProductos: Dado un umbral de precio, devuelve un conjunto ordenado alfabéticamente
//	con los nombres de todos los productos cuyo precio sea inferior al umbral indicado. (1 pto)
//
//    public SortedSet<String> getNombresProductos(Double umbral) {
//        return getCasetas().stream()
//                .flatMap(c -> c.getMenu().stream())
//                .filter(p -> p.precio() < umbral)
//                .map(p -> p.nombre())
//                .collect(Collectors.toCollection(TreeSet::new));
//    }
    //private Boolean tienenEseProducto(CasetaFeria c, String np) {
//        return c.getMenu().stream().map(p -> p.nombre()).anyMatch(n -> n.equals(np));
//    }
    public SortedSet<String> getNombresProductos(Double umbral) {
        SortedSet<String> res = new TreeSet<>(); // TreeSet ordena alfabéticamente
        for (CasetaFeria c : getCasetas()) {
            for (Producto p : c.getMenu()) {
                if (p.precio() < umbral) {
                    res.add(p.nombre());
                }
            }
        }
        return res;
    }

    // 4.getTopNCasetasPorMusica: Dado el nombre de un producto y un número entero n, devuelve un Map
//	que asocie a cada tipo de música una lista con los nombres de las n casetas mejor valoradas que
//	incluyan ese producto en su menú. (1,5 ptos)
    public Map<String, List<String>> getTopNCasetasPorMusica(String producto, Integer n) {
        Map<String, List<CasetaFeria>> grupos = new HashMap<>();
        for (CasetaFeria c : getCasetas()) {
            boolean tieneProducto = false;
            for (Producto p : c.getMenu()) {
                if (p.nombre().equalsIgnoreCase(producto)) {
                    tieneProducto = true;
                    break;
                }
            }
            if (tieneProducto) {
                if (!grupos.containsKey(c.getMusica())) {
                    grupos.put(c.getMusica(), new ArrayList<>());
                }
                grupos.get(c.getMusica()).add(c);
            }
        }

        // Ordenamos cada lista por valoración y cogemos las N primeras
        Map<String, List<String>> res = new HashMap<>();
        for (String musica : grupos.keySet()) {
            List<CasetaFeria> lista = grupos.get(musica);
            lista.sort(Comparator.comparing(CasetaFeria::getValoracion).reversed());

            List<String> nombres = new ArrayList<>();
            for (int i = 0; i < Math.min(n, lista.size()); i++) {
                nombres.add(lista.get(i).getNombre());
            }
            res.put(musica, nombres);
        }
        return res;
    }

    // 5. Calle con mayor aforo (Dígito inicial)
    public Character getCalleMasAforo() {
        Map<Character, Integer> aforos = new HashMap<>();
        for (CasetaFeria c : getCasetas()) {
            Character calle = c.getModulo().toString().charAt(0);
            aforos.put(calle, aforos.getOrDefault(calle, 0) + c.getAforo());
        }

        Character maxCalle = null;
        Integer maxAforo = -1;
        for (Map.Entry<Character, Integer> entry : aforos.entrySet()) {
            if (entry.getValue() > maxAforo) {
                maxAforo = entry.getValue();
                maxCalle = entry.getKey();
            }
        }

        if (maxCalle == null) {
            throw new NoSuchElementException("Sin datos");
        }
        return maxCalle;
    }

    /////////////Métodos CLASSROOM///////////////////////
    // 1. ¿Cuántas casetas tienen acceso a minusválidos?
    public Integer getNumCasetasAccesibles() {
        Integer res = 0;
        for (CasetaFeria cf : getCasetas()) {
            if (cf.getAccesoAdaptado()) {
                res++;
            }
        }
        return res;
    }

    //EXTRA.   ¿ y cuántas hay las que no tiene acceso a minusválidos???
    public Integer getNumCasetasNoAccesibles() {
        Integer res = 0;
        for (CasetaFeria cf : getCasetas()) {
            if (!cf.getAccesoAdaptado()) {
                res++;
            }
        }
        return res;
    }

    // 2. ¿Devuelve un listado con los nombres de las casetas de un tipo de música dado?
    public List<String> getNombresCasetasPorMusica(String musica) {
        List<String> res = new ArrayList<>();
        for (CasetaFeria c : getCasetas()) {
            if (c.getMusica().equalsIgnoreCase(musica)) {
                res.add(c.getNombre());
            }
        }
        return res;
    }

    // 3. ¿Cuál es el nombre de la caseta con mayor aforo?
    public String getNombreCasetaMayorAforo() {
        CasetaFeria res = null;
        for (CasetaFeria c : getCasetas()) {
            if (res == null || c.getAforo() > res.getAforo()) {
                res = c;
            }
        }
        return res.getNombre();
    }

    //EXTRA. ¿Cuál es el nombre de la caseta con menor aforo?
    public String getNombreCasetaMenorAforo() {
        CasetaFeria res = null;
        for (CasetaFeria c : getCasetas()) {
            if (res == null || c.getAforo() < res.getAforo()) {
                res = c;
            }
        }
        return res.getNombre();
    }

    // 4. ¿Cuál es el aforo medio de las casetas públicas?
    public Double getAforoMedioPublicas() {
        Double suma = 0.0;
        Integer res = 0;
        for (CasetaFeria c : getCasetas()) {
            if (c.getTipo().equals(TipoCaseta.PUBLICA)) {
                suma += c.getAforo();
                res++;
            }
        }
        return suma / res;
    }

// EXTRA. ¿Cuál es el aforo medio de las casetas privadas?
    public Double getAforoMedioPrivadas() {
        Double suma = 0.0;
        Integer res = 0;
        for (CasetaFeria c : getCasetas()) {
            if (c.getTipo().equals(TipoCaseta.PRIVADA)) {
                suma += c.getAforo();
                res++;
            }
        }
        return suma / res;
    }

    // 5. ¿Cuál es el aforo medio de las casetas que tienen cerveza?
    public Double getAforoMedioConCerveza() {
        Double suma = 0.0;
        Integer res = 0;
        for (CasetaFeria c : getCasetas()) {
            boolean tieneCerveza = false;
            for (Producto p : c.getMenu()) {
                if (p.nombre().equalsIgnoreCase("cerveza")) {
                    suma += c.getAforo();
                    res++;
                    tieneCerveza = true;
                    break;
                }
            }
        }
        return suma / res;
    }

    // EXTRA. ¿Cuál es el aforo medio de las casetas que no tienen cerveza?
    public Double getAforoMedioSinCerveza() {
        Double suma = 0.0;
        Integer res = 0;
        for (CasetaFeria c : getCasetas()) {
            boolean tieneCerveza = false;
            for (Producto p : c.getMenu()) {
                if (!p.nombre().equalsIgnoreCase("cerveza")) {
                    suma += c.getAforo();
                    res++;
                    tieneCerveza = true;
                    break;
                }
            }
        }
        return suma / res;
    }

    //DICCIONARIOS
    //1. Devolver un diccionario con clave el tipo de caseta y valor el número de casetas de ese tipo.
    public Map<TipoCaseta, Integer> getCasetaXTipo() {
        Map<TipoCaseta, Integer> res = new HashMap<>();
        for (CasetaFeria cf : getCasetas()) {
            if (res.containsKey(cf.getTipo())) {
                res.put(cf.getTipo(), res.get(cf.getTipo()) + 1);
            } else {
                res.put(cf.getTipo(), 1);
            }
        }

        return res;
    }

    public Map<TipoCaseta, Integer> getCasetaXTipoOtraManera() {
        Map<TipoCaseta, Integer> res = new HashMap<>();
        for (CasetaFeria cf : getCasetas()) {
            TipoCaseta clave = cf.getTipo();
            if (res.containsKey(clave)) {
                res.put(clave, res.get(clave) + 1);
            } else {
                res.put(clave, 1);
            }
        }
        return res;
    }

    //2. Devolver un diccionario con clave el nombre de cada producto y con valor el número de veces que aparece cada uno.
    public Map<String, Integer> getContarProductos() {
        Map<String, Integer> res = new HashMap<>();
        for (CasetaFeria cf : getCasetas()) {
            for (Producto p : cf.getMenu()) {
                if (res.containsKey(p.nombre())) {
                    res.put(p.nombre(), res.get(p.nombre()) + 1);
                } else {
                    res.put(p.nombre(), 1);
                }
            }
        }
        return res;
    }

    public Map<String, Integer> getContarProductosOtraManera() {
        Map<String, Integer> res = new HashMap<>();
        for (CasetaFeria cf : getCasetas()) {
            for (Producto p : cf.getMenu()) {
                String clave = p.nombre();
                if (res.containsKey(clave)) {
                    res.put(clave, res.get(clave) + 1);
                } else {
                    res.put(clave, 1);
                }
            }
        }
        return res;
    }

    //3.Cuál es el nombre del producto que se oferta en más casetas?
    //Una vez hecho el diccionario busco el máximo
    public String nombreProductomasOfertado() {
        Map<String, Integer> d = new HashMap<>();
        for (CasetaFeria cf : getCasetas()) {
            for (Producto p : cf.getMenu()) {
                String clave = p.nombre();
                if (d.containsKey(clave)) {
                    d.put(clave, d.get(clave) + 1);
                } else {
                    d.put(clave, 1);
                }
            }
        }
        String res = null;
        Integer max = 0;
        for (String clave : d.keySet()) {
            Integer veces = d.get(clave);
            if (veces > max) {
                max = veces;
                res = clave;
            }
        }
        return res;
    }

    //4. Hacer un método que devuelva un diccionario cuya clave es el nombre de la caseta y cuyo valor es 
    //el nombre del producto más caro que se oferta en esa caseta.
    public Map<String, String> getProductoMasCaroXCaseta() {
        Map<String, String> res = new HashMap<>();
        //Creamos el diccionario
        for (CasetaFeria cf : getCasetas()) {
            //recorremos las casetas
            String clave = cf.getNombre();
            String productocaro = null;
            Double caro = 0.0;
            for (Producto p : cf.getMenu()) {
                if (p.precio() > caro) {
                    caro = p.precio();
                    productocaro = p.nombre();
                }
            }
            res.put(clave, productocaro);
        }
        return res;
    }

    //5. Hacer un método que devuelva un diccionario cuya clave es el tipo de música de la caseta 
    //y cuyo valor es el nombre de la caseta con más aforo en las que se da ese tipo de música.
    public Map<String, String> getCasetaMusicaXAforo() {
        Map<String, List<CasetaFeria>> d = new HashMap<>();
        for (CasetaFeria cf : getCasetas()) {
            String clave = cf.getMusica();
            if (d.containsKey(clave)) {
                d.get(clave).add(cf);

            } else {
                List<CasetaFeria> valor = new ArrayList<>();
                valor.add(cf);
                d.put(clave, valor);
            }
        }
        Map<String, String> res = new HashMap<>();
        for (String clave : d.keySet()) {
            res.put(clave, masAforo(d.get(clave)));
        }
        return res;
    }

    public String masAforo(List<CasetaFeria> lis) {
        CasetaFeria max = null;
        for (CasetaFeria cf : lis) {
            if (max == null || max.getAforo() < cf.getAforo()) {
                max = cf;
            }
        }

        return max.getNombre();
    }

}
