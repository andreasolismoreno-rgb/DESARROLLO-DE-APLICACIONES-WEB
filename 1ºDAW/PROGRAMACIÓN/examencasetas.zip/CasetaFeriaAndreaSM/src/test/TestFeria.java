package test;

import fp.feria.*;
import java.util.*;

public class TestFeria {

    public static void main(String[] args) {
        // 1. Cargar datos
        Set<CasetaFeria> casetas = FactoriaFeria.leerCasetas("data/casetas.csv");
        FeriaGestion feria = new FeriaGestion(casetas);

        System.out.println("FACTORÍA =========================================");
        System.out.println("Nº de casetas en la feria: " + feria.getNumeroCasetas());

        // 2. Probar EJ1 al EJ5 
        testPrecioMaximo(feria);
        testValoracionMedia(feria);
        testNombresProductos(feria);
        testTopCasetas(feria);
        testCalleMasAforo(feria);

        // 3. Preguntas de CLASSROOM
        testMetodos(feria);

        //4. Diccionarios
        testDiccionarios(feria);
    }

    private static void testDiccionarios(FeriaGestion feria) {
        System.out.println("\n DICCIONARIOS=======================");
        System.out.println("1. Devolver un diccionario con clave el tipo de caseta y valor el número de casetas de ese tipo." + feria.getCasetaXTipo());
        System.out.println("2. Devolver un diccionario con clave el nombre de cada producto y con valor el número de veces que aparece cada uno.");
        Map<String, Integer> m = feria.getContarProductos();
        for (String n : m.keySet()) {
            System.out.println(n + " " + m.get(n));
        }
        System.out.println("3. Cuál es el nombre del producto que se oferta en más casetas?");
        System.out.println(feria.nombreProductomasOfertado());
        System.out.println("4. Cuál es el nombre del producto más caro que se oferta en esa caseta?");
        System.out.println(feria.getProductoMasCaroXCaseta());
         System.out.println("5. Cuál es el tipo de música de la caseta con más aforo?");
        System.out.println(feria.getCasetaMusicaXAforo());
    }

    private static void testMetodos(FeriaGestion feria) {
        System.out.println("\nMÉTODOS ===============================");
        System.out.println("1. Casetas accesibles: " + feria.getNumCasetasAccesibles());
        System.out.println("1.0. Casetas no accesibles: " + feria.getNumCasetasNoAccesibles());
        System.out.println("2. Casetas con música Sevillanas: " + feria.getNombresCasetasPorMusica("sevillanas"));
        System.out.println("3. Nombre caseta mayor aforo: " + feria.getNombreCasetaMayorAforo());
        System.out.println("3.0. Nombre caseta menor aforo: " + feria.getNombreCasetaMenorAforo());
        System.out.println("4.¿Cuál es el aforo medio de las casetas públicas?: " + feria.getAforoMedioPublicas());
        System.out.println("4.0.¿Cuál es el aforo medio de las casetas privadas?: " + feria.getAforoMedioPrivadas());
        System.out.println("5.¿Cuál es el aforo medio de las casetas que tienen cerveza?: " + feria.getAforoMedioConCerveza());
        System.out.println("5.0.¿Cuál es el aforo medio de las casetas que no tienen cerveza?: " + feria.getAforoMedioSinCerveza());

    }

    private static void testPrecioMaximo(FeriaGestion feria) {
        System.out.println("\nEJ1 =========================================");
        System.out.println("Precio máx PUBLICA: ");
        Map<String, Double> m = feria.getPrecioMaxProducto(TipoCaseta.PUBLICA);
        for (String n : m.keySet()) {
            System.out.println(n + " " + m.get(n));
        }

        System.out.println("");
        System.out.println("");

        System.out.println("Precio máx PRIVADA: ");
        Map<String, Double> k = feria.getPrecioMaxProducto(TipoCaseta.PRIVADA);
        for (String n : k.keySet()) {
            System.out.println(n + " " + k.get(n));
        }

    }

    private static void testValoracionMedia(FeriaGestion feria) {
        System.out.println("\nEJ2 =========================================");
        System.out.println("Media PRIVADA Accesible: "
                + feria.getValoracionMediaTipoCasetaAccesible(TipoCaseta.PRIVADA, true));
        System.out.println("Media PUBLICA No Accesible: "
                + feria.getValoracionMediaTipoCasetaAccesible(TipoCaseta.PUBLICA, false));
    }

    private static void testNombresProductos(FeriaGestion feria) {
        System.out.println("\nEJ3 =========================================");
        System.out.println("Productos < 5€: " + feria.getNombresProductos(5.0));
    }

    private static void testTopCasetas(FeriaGestion feria) {
        System.out.println("\nEJ4 =========================================");
        System.out.println("Top 1 para 'rebujito': ");
        Map<String, List<String>> m = feria.getTopNCasetasPorMusica("rebujito", 1);
        for (String n : m.keySet()) {
            System.out.println(n + " " + m.get(n));
        }
    }

    private static void testCalleMasAforo(FeriaGestion feria) {
        System.out.println("\nEJ5 =========================================");
        try {
            System.out.println("Calle con más aforo: '" + feria.getCalleMasAforo() + "'");
        } catch (NoSuchElementException e) {
            System.out.println("Error: No se pudo calcular la calle.");
        }
    }
}
