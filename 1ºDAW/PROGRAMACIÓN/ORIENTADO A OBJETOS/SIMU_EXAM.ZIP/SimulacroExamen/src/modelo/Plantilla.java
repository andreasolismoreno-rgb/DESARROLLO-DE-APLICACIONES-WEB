package modelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Plantilla { //Esta clase es la "jefa". No es un empleado, es la carpeta donde guardamos a todos.

    private List<Empleado> empleados; //--> Esto es una Colección. En lugar de tener variables sueltas (empleado1, empleado2), 
    //creamos una lista dinámica que puede crecer todo lo que queramos.

    public Plantilla() {
        this.empleados = new ArrayList<>();
    }

    public void contratarEmpleado(Empleado e) {
        empleados.add(e);
    }

    public List<Empleado> getEmpleadosPorNombre(String nombre) {
        //List<Empleado>: Es el tipo de dato que "suelta" el método. 
        //No devuelve un solo empleado, sino una sub-lista con todos los que coincidan.
        //(String nombre): Es la palabra o texto que estamos buscando (el filtro).

        List<Empleado> res = new ArrayList<>();
//List<Empleado> res = new ArrayList<>();
//Aquí creas una lista vacía temporal llamada res (de "resultado"). 
//Es como sacar una carpeta vacía para ir metiendo las fotocopias de los empleados que encontremos.
        for (Empleado empleado : empleados) {
            if (empleado.getNombre().contains(nombre) || empleado.getApellidos().contains(nombre)) {
                res.add(empleado);
            }
        }
        return res;
    }
    //for (Empleado empleado : empleados)
    //Este es un bucle for-each. Se lee así: "Por cada empleado que encuentres dentro de mi lista general de empleados, haz lo siguiente...". Es como ir pasando las páginas del libro una a una.
    //
    //if (empleado.getNombre().contains(nombre) || empleado.getApellidos().contains(nombre))
    //Aquí está el corazón del filtro. Usamos dos herramientas:
    //.contains(): No busca que el nombre sea exacto, sino que el texto esté dentro. Si buscas "Ana", encontrará a "Ana", "Mariana" y "Anabel".
    //||: Significa "O". El empleado entrará en la lista si el texto está en el nombre O si está en los apellidos. Si se cumple cualquiera de las dos, nos sirve.
    //
    //res.add(empleado);
    //Si el if dice que es verdad, metemos a ese empleado en nuestra carpeta de resultados.
    //
    //return res;
    //Al terminar de revisar a todo el mundo, entregamos la carpeta con los elegidos.

    //--> List<Empleado> res = new ArrayList<>();
//"Vale, me han pedido una lista. Primero, saco una carpeta nueva y vacía. Aquí iré metiendo las fotocopias de los empleados que encuentre. De momento, la carpeta está limpia."
//
//for (Empleado empleado : empleados)
//"Bien, ahora voy a mi archivador principal, donde tengo a toda la plantilla. Voy a ir uno por uno, sin saltarme a nadie, desde el primero hasta el último. Cojo el primer expediente..."
//
//if (empleado.getNombre().contains(nombre) || empleado.getApellidos().contains(nombre))
//"A ver, analicemos a este sujeto... Primero miro su Nombre: ¿Contiene el texto que me han dado? (Por ejemplo, 'García'). ¿No? Bueno, no pasa nada, tengo una segunda oportunidad porque hay un || (un 'O'). Miro sus Apellidos: ¿Contiene 'García'? Si alguna de las dos respuestas es 'SÍ', entonces este empleado me sirve."
//
//res.add(empleado);
//"¡Ajá! Coincide. No quiero perder a este empleado, así que lo apunto en mi carpeta nueva (la que llamé res). ¡Siguiente expediente!"
//
//return res;
//"Uf, ya he terminado de revisar toda la montaña de papeles. Aquí tienes la carpeta res con todos los que he encontrado. Si no encontré a ninguno, te devuelvo la carpeta vacía, pero al menos he cumplido mi misión."
//
//¿Qué pasa en la "cabeza" del ordenador si cambias algo?
//Si quitas el new ArrayList<>():
//"Me pides que guarde gente en una carpeta (res.add), ¡pero no me has dado ninguna carpeta! Me rindo, tiro un error (NullPointerException) y me detengo."
//
//Si cambias || por &&:
//"Ahora me he vuelto súper estricto. Solo guardaré al empleado si 'García' está en el nombre Y TAMBIÉN en el apellido. Si se llama 'Juan García', lo descarto porque 'Juan' no contiene 'García'. ¡Casi nadie va a entrar en mi carpeta!"
//
//Si olvidas el return res;:
//"He trabajado un montón buscando gente, pero como no me has dicho que te entregue la carpeta al final, me la quedo yo y no te doy nada. El programa se quejará porque esperaba un resultado."
    
    //Un método que devuelve la categoria media de los empleados
    public Double categoriaMediaDeLosTecnicos() {
        Integer suma = 0;
        Integer numTecnicos = 0;
        for (Empleado empleado : empleados) {
            if (empleado instanceof Tecnico) {
                Tecnico t = (Tecnico) empleado;
                suma += t.getCategoria();
                numTecnicos++;
            }
        }
        return numTecnicos > 0 ? 1.0 * suma / numTecnicos : 0.0;
    }
//Integer suma = 0; y Integer numTecnicos = 0;
//Esto significa:
//"Voy a sacar una libreta para anotar la suma de las categorías y un contador para saber cuántos técnicos voy encontrando. De momento, ambos están a cero
//

    //Integer: Es el tipo de dato. Le dice al ordenador: "Reserva un espacio donde solo quepan números enteros" 
    //(como 1, 2, 3... nada de decimales por ahora).
//suma / numTecnicos: Son los nombres que tú eliges para esas "cajitas" de memoria. Podrías haberles puesto total o contador, 
//pero estos nombres ayudan a entender qué guardan.
//
//= 0: Esto es fundamental. Se llama "inicializar". Si no les pones un 0 al empezar, el ordenador no sabe desde dónde sumar y te daría un error. 
//Es como poner a cero un cronómetro antes de una carrera.
//
//numTecnicos++;Esto significa: "He encontrado a otro técnico, suma uno más a mi cuenta".
//++: Es un atajo. Es exactamente lo mismo que escribir: numTecnicos = numTecnicos + 1;.
//Para qué sirve: Imagina que vas por la oficina con un contador de esos de mano (como los que usan en los aviones para contar pasajeros). 
//        Cada vez que ves a un técnico, haces "clic". Eso es el ++.
//    if (empleado instanceof Tecnico)
//    instanceof: Es una palabra clave que sirve para hacer una pregunta de identidad. 
//    "Oye, este empleado que tengo en la mano, ¿es realmente un Tecnico?".
//    Si es un comercial, Java dice "Falso" y se salta ese empleado. Si es un técnico, 
//    dice "Verdadero" y entra al bloque.
//
//Tecnico t = (Tecnico) empleado;
//Esto es el Casting.
//Por qué se usa: Aunque Java sabe que es un técnico (por el if de arriba), 
//la variable sigue siendo de tipo Empleado. Los "empleados" no tienen el método getCategoria().
//Qué hace: Con (Tecnico), le estamos diciendo a Java:
//    "Confía en mí, sé que este empleado es un técnico, trátalo como tal y guárdalo en la variable t". 
//Ahora, a través de t, ya podemos acceder a la categoría.
//
//suma += t.getCategoria();
//Es un atajo para escribir suma = suma + t.getCategoria();. Vamos acumulando los puntos de categoría.
//return numTecnicos > 0 ? 1.0 * suma / numTecnicos : 0.0;
//Esto es un Operador Ternario. Es un if elegante en una sola línea.
//Se lee así: "¿Es el número de técnicos mayor que cero?
//Si sí (:): Haz la división 1.0 * suma / numTecnicos.
//Si no (0.0): Devuelve 0.0 para evitar errores.
    
    
//--> Si juntamos todo el código:

//"Vale, voy a calcular la media. Primero, pongo mi suma a 0 y mi contador de técnicos a 0".
//
//"Ahora voy a mirar a cada empleado de la lista".
//
//"¿Este es un Técnico? Si lo es:
//
//Miro su categoría (por ejemplo, un 3) y la añado a mi suma total.
//
//Hago 'clic' en mi contador (numTecnicos++)".
//
//"¿Este es un Comercial? No me interesa, paso al siguiente".
//
//"Al terminar, si conté algún técnico, divido la suma entre el número de técnicos y ¡listo!".
    
    
    //Metodo que devuelva el comercial con más ventas
    public Comercial comercialConMasVentas() {
        Comercial res = null;
        for (Empleado empleado : empleados) {
            if (empleado instanceof Comercial) {
                Comercial c = (Comercial) empleado;
                if (res == null || res.getVentas() < c.getVentas()) {
                    res = c;
                }
            }
        }
        return res;
    }
    
    
    //Comercial res = null;
//"Vale, voy a buscar al mejor vendedor. De momento, no conozco a ninguno, así que mi 'ganador provisional' está vacío (null). Tengo el trofeo en la mano esperando a un dueño."
//
//for (Empleado empleado : empleados)
//"Empiezo mi ronda por toda la oficina. Voy a mirar a cada persona que trabaja aquí, una por una."
//
//if (empleado instanceof Comercial)
//"A ver tú... ¿Eres un Comercial? ¿No? Eres un Técnico. Lo siento, tú no participas en este concurso de ventas. Paso al siguiente."

//Comercial c = (Comercial) empleado;
//"¡Ajá! Tú sí eres Comercial. Me pongo mis 'gafas de vendedor' para poder ver cuánto has vendido exactamente, porque como 'empleado' genérico no me lo decías."
//
//if (res == null || res.getVentas() < c.getVentas())
//"Aquí viene el momento de la verdad. Me pregunto dos cosas:
//
//res == null: ¿Es este el primer comercial que me encuentro? Si es el primero, ¡automáticamente es mi ganador provisional!
//O (||)
//res.getVentas() < c.getVentas(): ¿Este nuevo comercial ha vendido más que el que yo tenía apuntado como ganador?
//Si alguna de las dos es cierta, ¡tenemos nuevo líder!"
//
//res = c;
//"¡Cambio de planes! Tú eres el nuevo número uno. Me olvido del anterior y te apunto a ti en mi libreta de 'ganador'."
//
//return res;
//"He terminado de dar la vuelta a la oficina. Aquí tienes al Comercial que más ha vendido. "
//+ "(Y si la oficina estaba vacía o no había comerciales, te devuelvo null, es decir, el trofeo se queda sin dueño)."

    
    
    
    //Metodo que devuelva los comerciales que tengan unas ventas
    //superiores a una dada
    public List<Comercial> comercialVentasMasDe(Double v) {
        List<Comercial> res = new ArrayList<>();
        for (Empleado empleado : empleados) {
            if (empleado instanceof Comercial) {
                Comercial c = (Comercial) empleado;
                if (c.getVentas() > v) {
                    res.add(c);
                }
            }
        }
        return res;
    }
    
    
//public List<Comercial> comercialVentasMasDe(Double v) {
//"Me han dado un número: 5000.0 (la v). Mi misión es devolver una lista llena de vendedores estrella."
//
//List<Comercial> res = new ArrayList<>();
//"Preparo una bolsa vacía. Solo aceptaré objetos de tipo Comercial dentro."
//
//for (Empleado empleado : empleados) {
//"Llamo a la lista general de la empresa. Saco al primer empleado. De momento, Java solo sabe que es un 'Empleado' genérico."
//
//if (empleado instanceof Comercial) {
//"Le pregunto al objeto: '¿Tú quién eres?'. Si me dice que es Técnico, lo ignoro. Si me dice que es Comercial, sigo adelante."
//
//Comercial c = (Comercial) empleado;
//"¡AQUÍ HAY UNA LLAMADA IMPORTANTE! Le digo al ordenador: 'Trata a este empleado como un Comercial'. "
// Esto me permite ver sus métodos secretos, como getVentas()."
//
//if (c.getVentas() > v) {
//*"Aquí mi código llama al método getVentas() de la clase Comercial.
//El Comercial mira su memoria y responde: 'He vendido 7000'.
//Mi método compara: ¿Es 7000 > 5000? ¡SÍ!"*
//
//res.add(c);
//"Llamo a mi bolsa res y le digo: 'Guarda a este vendedor, que es de los buenos'."
//
//return res;
//"He terminado de revisar a todos. Toma tu lista.
    
    
//Imagina que tienes 3 empleados en la lista:
//
//Ana (Técnico)
//Pedro (Comercial, ventas 2000)
//Luis (Comercial, ventas 8000)
//
//Si buscas ventas mayores a 5000:
//Con Ana: instanceof dice que NO. Se salta.
//Con Pedro: instanceof dice que SÍ. Entra al if, pero 2000 > 5000 es Falso. No se guarda.
//Con Luis: instanceof dice que SÍ. Entra al if, 8000 > 5000 es Verdadero. Se guarda en res.
//
//v: Es el umbral. Es el listón que pones para saltar. Si cambias ese número al llamar al método, el filtro se vuelve más fácil o más difícil.
//instanceof vs (Comercial) empleado: Piensa que instanceof es la identificación (mirar el DNI) 
//        y el (Comercial) es el permiso para pedirle cosas de vendedor. 
//        Sin el permiso, no puedes preguntarle por sus ventas.
    
}
