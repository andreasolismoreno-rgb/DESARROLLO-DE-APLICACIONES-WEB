package modelo;

public class Tecnico extends Empleado {

    private Integer categoria;

    public Tecnico(String dni, String nombre, String apellido, Double sueldoBase, Integer categoria) {
        super(dni, nombre, apellido, sueldoBase);
        this.categoria = categoria;
    }

    @Override
    public Double getSueldo() {
        return getSueldoBase() + (categoria * 100);
    }

    public Integer getCategoria() {
        return categoria;
    }

}
