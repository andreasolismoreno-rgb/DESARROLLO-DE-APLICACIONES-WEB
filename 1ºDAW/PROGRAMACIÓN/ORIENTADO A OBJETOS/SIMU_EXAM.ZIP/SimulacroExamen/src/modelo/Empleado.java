package modelo;
public abstract class Empleado {   //--> Esta es la clase madre. 
//  Como es abstract, no sirve para crear empleados directamente, 
//   sino para heredar sus genes a los hijos.
    
    
    //ATRIBUTOS
    private String dni; //--> El private es como poner un candado.Solo la propia clase
//            Empleado puede leer o cambiar el DNI directamente. 
//            Esto se llama Encapsulamiento(proteger losdatos).
    private String nombre;
    private String apellidos;
    private Double sueldoBase;

    
    //CONSTRUCTOR
    public Empleado(String dni, String nombre, String apellidos, Double sueldoBase) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.sueldoBase = sueldoBase;
    }

    
    //GETTERS
    public String getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public Double getSueldoBase() {
        return sueldoBase;
    }

    
    //SETTERS
    public void setSueldoBase(Double sueldoBase) {
        this.sueldoBase = sueldoBase;
    }
    
    
    //PROPIEDAD DERIVADA
    public abstract Double getSueldo();           
    //--> Esta línea es vital. No tiene cuerpo (no hay {}) porque el "padre" no sabe cuánto cobra el empleado. 
    //Solo dice: "Prometo que todo empleado tendrá una forma de cobrar"

    @Override
    public String toString() {
        return "Empleado{" + "dni=" + dni + ", nombre=" + nombre + ", apellidos=" + apellidos + ", sueldoBase=" + sueldoBase + '}';
    }
    
    
    
}
