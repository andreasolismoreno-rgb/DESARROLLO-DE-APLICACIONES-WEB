package modelo;

public class Comercial extends Empleado { //--> Esta palabra es la que crea el vínculo. 
    //Significa que Comercial "es un" Empleado. 
    //Automáticamente tiene DNI, nombre y apellidos sin tener que volver a escribirlos.

    
    //ATRIBUTOS
    private Double ventas;

    
    //CONSTRUCTOR
    public Comercial( String dni, String nombre, String apellido, Double sueldoBase) {
        super(dni, nombre, apellido, sueldoBase);
        //SUPER?? Como el padre es quien sabe guardar el DNI y el nombre, el hijo le pasa esos datos hacia 
        //arriba para que él se encargue. 
        //Es como decir: "Papá, registra tú estos datos básicos, que yo me encargo de lo mío (las ventas)".
       
    }

    
    
    //SETTERS
    public void setVentas(Double ventas) {
        this.ventas = ventas;
    }

    
    //DERIVADA
    @Override
    public Double getSueldo() {
        return getSueldoBase() + (ventas * 0.1);
    }

    
    
    public Double getVentas() {
        return ventas;
    }

    @Override
    public String toString() {
        return "Comercial: " + "ventas=" + ventas + super.toString();
    }
    
    
}
