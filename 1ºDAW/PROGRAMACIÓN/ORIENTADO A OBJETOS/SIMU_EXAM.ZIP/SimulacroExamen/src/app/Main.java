package app;

import java.util.List;
import modelo.*;

public class Main {

    public static void main(String[] args) {
        Plantilla plantilla = new Plantilla();
        // Técnico de categoría 1
        plantilla.contratarEmpleado(new Tecnico("11111111H", "Alejandro", "Fernández", 1000.0, 1));
        // Técnico de categoría 2
        plantilla.contratarEmpleado(new Tecnico("22222222J", "Jerónima", "Jiménez", 1000.0, 2));
        // Comercial
        Comercial comercial1 = new Comercial("33333333P", "Desiderio", "Durán", 800.0);
        comercial1.setVentas(2000.0);
        plantilla.contratarEmpleado(comercial1);
        Comercial comercial2 = new Comercial("22222P", "Tiburcio", "Pérez", 900.0);
        comercial2.setVentas(3000.0);
        plantilla.contratarEmpleado(comercial2);
        for (Empleado e : plantilla.getEmpleadosPorNombre("er")) {
            System.out.println(e.getNombre() + " " + e.getApellidos() + ": " + e.getSueldo());
        }
        System.out.println("La categoría media de los técnicos de la plantilla es "+plantilla.categoriaMediaDeLosTecnicos());
        System.out.println("El comercial con más ventas es "+ plantilla.comercialConMasVentas());
        
        
        
        //
        System.out.println("--- Comerciales con ventas superiores a 2500 ---");

// 1. Llamamos al método y guardamos el resultado en una lista nueva
List<Comercial> mejoresVendedores = plantilla.comercialVentasMasDe(2500.0);

// 2. Recorremos esa lista para ver quiénes son
for (Comercial c : mejoresVendedores) {
    System.out.println("Súper Vendedor: " + c.getNombre() + " - Ventas: " + c.getVentas());
}
    }
}

//
//1. Preparando el escenario
//Plantilla plantilla = new Plantilla();
//
//"¡Atención! Abro una oficina nueva. Llamo al constructor de Plantilla, que me compra una estantería vacía (ArrayList) para meter expedientes."
//
//2. Las contrataciones (Creación de objetos)
//plantilla.contratarEmpleado(new Tecnico("11111111H", "Alejandro", ... , 1));
//
//"Aquí pasan dos cosas a la vez:
//
//Fabrico un Técnico nuevo (Alejandro). Su constructor rellena los datos de DNI, nombre, etc.
//
//Se lo entrego al método contratarEmpleado de la plantilla, que lo mete en la estantería."
//
//Comercial comercial1 = new Comercial(...);
//
//"Fabrico a Desiderio. Pero ojo, él nace con sus ventas vacías."
//
//comercial1.setVentas(2000.0);
//
//"¡LLAMADA CLAVE! Llamo al método setVentas de Desiderio para decirle: 'Oye, guarda este 2000 en tu bolsillo de ventas'."
//
//3. El gran buscador ("er")
//for (Empleado e : plantilla.getEmpleadosPorNombre("er")) { ... }
//
//"Aquí el Main le pide un favor a la Plantilla: 'Búscame a todos los que tengan er en su nombre'."
//
//La Plantilla le devuelve una lista. El for la recorre:
//
//Encuentra a Jerónima. Imprime su nombre y llama a su getSueldo().
//
//Encuentra a Desiderio. Imprime su nombre y llama a su getSueldo().
//
//Encuentra a Tiburcio Pérez (por el apellido). Imprime y llama a su getSueldo().
//
//Fíjate: e.getSueldo() es polimorfismo puro. Para Jerónima usa la fórmula de categoría, para Desiderio la de ventas.
//
//4. Las estadísticas finales
//plantilla.categoriaMediaDeLosTecnicos()
//
//"El Main llama a este método. El método cuenta a Alejandro (cat 1) y a Jerónima (cat 2). "
//+ "Suma 3, divide entre 2 y le grita al Main: '¡La media es 1.5!'."
//
//plantilla.comercialConMasVentas()
//
//"Última misión. Comparamos a Desiderio (2000) contra Tiburcio (3000). "
//+ "Tiburcio gana. El método le devuelve el objeto de Tiburcio al Main para que lo imprima por pantalla."