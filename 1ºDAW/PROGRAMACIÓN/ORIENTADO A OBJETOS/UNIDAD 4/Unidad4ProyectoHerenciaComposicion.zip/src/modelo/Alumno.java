package modelo;

import java.util.ArrayList;
import java.util.List;

public class Alumno extends Persona {
    private String grupo;
    private List<Asignatura> asignaturas;

    public Alumno(String dni, String nombre, String grupo) {
        super(dni, nombre);
        this.grupo = grupo;
        this.asignaturas = new ArrayList<>();
    }

    public void matricular(Asignatura a) {
        if (a == null || estaMatriculado(a.getCodigo())) return;
        asignaturas.add(a);
    }

    public boolean desmatricularPorCodigo(String codigo) {
        return asignaturas.removeIf(a -> a.getCodigo().equals(codigo));
    }

    public boolean estaMatriculado(String codigo) {
        return asignaturas.stream().anyMatch(a -> a.getCodigo().equals(codigo));
    }

    public int horasTotales() {
        return asignaturas.stream().mapToInt(Asignatura::getHoras).sum();
    }

    @Override
    public String toString() {
        return presentarse() + " | Grupo: " + grupo + " | Asignaturas: " + asignaturas;
    }
}