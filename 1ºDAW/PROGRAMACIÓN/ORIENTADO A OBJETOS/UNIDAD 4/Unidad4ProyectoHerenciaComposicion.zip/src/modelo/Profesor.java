package modelo;

public class Profesor extends Persona {
    private String departamento;
    private int horasSemanales;

    public Profesor(String dni, String nombre, String departamento, int horasSemanales) {
        super(dni, nombre);
        if (departamento == null || departamento.isEmpty() || horasSemanales < 0) {
            throw new IllegalArgumentException("Datos incorrectos");
        }
        this.departamento = departamento;
        this.horasSemanales = horasSemanales;
    }

    @Override
    public String presentarse() {
        return super.presentarse() + ", profesor de " + departamento +
               " (" + horasSemanales + "h/semana)";
    }

    @Override
    public String toString() {
        return presentarse();
    }
}