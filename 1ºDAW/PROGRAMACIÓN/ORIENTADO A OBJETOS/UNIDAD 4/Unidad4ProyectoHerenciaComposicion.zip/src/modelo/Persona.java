package modelo;

public class Persona {
    private String dni;
    private String nombre;

    public Persona(String dni, String nombre) {
        if (dni == null || dni.isEmpty() || nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("DNI y nombre no pueden estar vacíos");
        }
        this.dni = dni;
        this.nombre = nombre;
    }

    public String getDni() { return dni; }
    public String getNombre() { return nombre; }

    public String presentarse() {
        return "Soy " + nombre + " con DNI " + dni;
    }

    @Override
    public String toString() {
        return presentarse();
    }
}