package modelo;

public class Asignatura {
    private String codigo;
    private String nombre;
    private int horas;

    public Asignatura(String codigo, String nombre, int horas) {
        if (codigo == null || codigo.isEmpty() || nombre == null || nombre.isEmpty() || horas <= 0) {
            throw new IllegalArgumentException("Datos inválidos");
        }
        this.codigo = codigo;
        this.nombre = nombre;
        this.horas = horas;
    }

    public String getCodigo() { return codigo; }
    public int getHoras() { return horas; }

    @Override
    public String toString() {
        return codigo + " - " + nombre + " (" + horas + "h)";
    }
}