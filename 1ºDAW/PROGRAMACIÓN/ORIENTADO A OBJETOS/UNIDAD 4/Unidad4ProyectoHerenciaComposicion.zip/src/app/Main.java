package app;

import modelo.*;

public class Main {
    public static void main(String[] args) {
        Alumno a1 = new Alumno("111A", "Ana", "1DAW");
        Alumno a2 = new Alumno("222B", "Luis", "2DAW");

        Profesor p1 = new Profesor("333C", "María", "Informática", 20);

        Asignatura prog = new Asignatura("PROG", "Programación", 6);
        Asignatura bbdd = new Asignatura("BBDD", "Bases de Datos", 5);

        a1.matricular(prog);
        a1.matricular(bbdd);

        System.out.println(a1);
        System.out.println("Horas totales: " + a1.horasTotales());
        System.out.println(p1);
    }
}