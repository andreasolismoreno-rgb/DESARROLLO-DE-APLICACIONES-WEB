package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import utiles.PrecioUtils;

public class Pedido {
    private List<LineaPedido> lineas;
    
//    9. Usa java.time.LocalDate para guardar la fecha del pedido. (Constructor de
//Pedido que reciba fecha).
//Criterios: RA2-b, RA2-g.
    private LocalDate fechaPedido;
    
    public Pedido (LocalDate fechaPedido){
        lineas = new ArrayList <>();
        this.fechaPedido = fechaPedido;
        
    }

    public LocalDate getFechaPedido() {
        return fechaPedido;
    }
    
    
   
    public Pedido() {
    
        this.lineas = new ArrayList<>();
    }
    
    public void addLinea(LineaPedido linea) {
    
        this.lineas.add(linea);
    }

    // El getTotal es una Propiedad derivada (NO atributo): total
    public double getTotal() {
    double suma = 0;
    
    for (LineaPedido lp : lineas) {
    suma += lp.getSubtotal();
    }
    return suma;
    }

    @Override
    public String toString() {
        String res = "";
        for (LineaPedido linea : lineas){
            res += linea.getProducto().getNombre() + "-->" + linea.getCantidad() + ":" + linea.getSubtotal() + "\n";
        }
        res += "-----------------------------------\n";
        res += "                         Total: " + PrecioUtils.redondear2(getTotal()) + " euros\n";
        return res;
    }
    
//    En Pedido, añade getNumeroArticulos() como propiedad derivada (suma de
//cantidades).
//Criterios: RA2-d, RA4-c.
    
    public Integer getNumeroArticulos(){
        Integer res=0;
        
        for (LineaPedido lp : lineas) {
            res += lp.getCantidad();
        }
        return res;
    }
    
//    Añade descuento: si el total supera 50 €, aplica 10% de descuento. Implementa
//getTotalConDescuento() como propiedad derivada (no almacenar).
//Criterios: RA2-d, RA4-c.
    
    public Double getTotalConDescuento(){
        return getTotal()> 50.0? 0.9*getTotal() : getTotal();
    }
    
    
//    12. Añade un método removeLineaPorCodigoProducto(String codigo) en
//Pedido.
//Criterios: RA2-d, RA2-f.
    
    public void removeLineaPorCodigoProducto(String codigo){
        for (LineaPedido linea : lineas){
            if (linea.getProducto().getCodigo().equals(codigo)) {
                lineas.remove(linea);
            }
        }
    }
    
    
}