package test;

import modelo.Gato;

public class TestGato {
    public static void main (String [] args){
        
        Gato g1 = new Gato("Vodka",7,7.5);
        System.out.println(g1);
        
        Gato g2 = new Gato("Sissi",3,5.1);
        System.out.println(g2);
        
        Gato g3 = new Gato("Cati",13 ,6.3);
        System.out.println(g3);
        
        Gato g4 = new Gato("Fiona",5 ,5.4);
        System.out.println(g4);
        
    }
}

