package modelo;

public class Gato {
    
    //Atributos o propiedades básicas (son SIEMPRE privados, por tanto no se puede hacer 
    //modificaciones directamente fuera de la clase, para ello neceistamos 
    //un constructor público con un método get)
    private String nombre;
    private int edad;
    private double peso;
    
    
    //métodos son SIEMPRE públicos
    //Estos son constructores:

    
    //Constructor por parámetro
    public Gato (String nombre, int edad, double peso) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
    }
    
   
    
    //Estos son métodos getter, son observadores.
    public String getNombre() {
        return nombre;
    }


    public int getEdad() {
        return edad;
    }

    public double getPeso() {
        return peso ;
    }

    
    
    //Estos son métodos setter, son modificadores
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
    
    

    @Override
    public String toString() { //es un método que nos indica que está 
                                //sobreescribiendo un método que ya existe
        return nombre + " " +
               " | Edad: " + edad +
               " | Peso: " + peso ;
    }
}
