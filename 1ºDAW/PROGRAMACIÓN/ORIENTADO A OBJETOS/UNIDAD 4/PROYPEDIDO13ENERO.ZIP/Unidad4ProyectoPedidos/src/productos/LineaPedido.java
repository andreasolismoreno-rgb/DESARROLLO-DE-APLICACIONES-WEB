package productos;

public class LineaPedido {
    private Producto producto;
    private Integer cantidad;
    private String pedido;
    
    public LineaPedido (Producto producto, Integer cantidad){
        
        this.producto = producto;
        this.cantidad = cantidad;
        this.pedido = pedido;
    }
    
    public Producto getProducto() { return producto; }
    public Integer getCantidad() { return cantidad; }
    public String getNumeroArticulos() { return pedido; }
        

// La descripción larga es una Propiedad DERIVADA (NO atributo): se calcula
        
    public double getDescripcionLarga() {
            
    return producto.getPrecio() * cantidad;
    
    }

    @Override
    public String toString() {
        return producto + "--> Cantidad=" + cantidad + " (subtutotal =" + getDescripcionLarga()+")";
    }
}
