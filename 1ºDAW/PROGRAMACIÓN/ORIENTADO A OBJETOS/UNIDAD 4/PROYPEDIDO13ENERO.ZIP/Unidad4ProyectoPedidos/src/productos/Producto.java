package productos;

public class Producto {
    
    private String codigo;
    private String nombre;
    private Double precio;
    
    public Producto (String codigo, String nombre, Double precio){
        
        if(precio < 0) {
            throw new IllegalArgumentException("El precio no debe ser negativo");
        }
        
        if(precio == null) {
            throw new IllegalArgumentException("El precio no debe ser nulo");
        }
        
        this.precio = precio;
        this.codigo = codigo;
        this.nombre = nombre;

    }
    
    public Producto (String nombre, Double precio){
        
        this ("P = " + nombre.toUpperCase().charAt(0)+ " ...", nombre, precio);
        
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Double getPrecio() {
        return precio;
    }
    
    
    
    

}

