package geometria;

public class TestPunto {
        public static void main(String [] args){
        Punto p1 = new Punto (1.8, 2.2);
        System.out.println(p1.getCuadrantes());
        System.out.println(p1);
        
        System.out.println("El punto está en el " + p1.getCuadrantes());

    }
}
