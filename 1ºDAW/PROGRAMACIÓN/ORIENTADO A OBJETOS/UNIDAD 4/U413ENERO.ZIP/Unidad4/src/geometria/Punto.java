package geometria;

import java.util.ArrayList;
import java.util.List;

public class Punto {
    private Double x;
    private Double y;
    
    //Esto es un constrcutor por defecto
    public Punto() {
        this.x = 0.0;
        this.y = 0.0;
    }
    
    //Esto es un constrcutor por parámetro
    public Punto(Double x, Double y) {
        this.x = x;
        this.y = y;
    }
    
//    Recordemos de la clase anterior que dijimos q tb se puede hacer así y pinta igual    
//    public Punto() {
//        this(0.0, 0.0);
//    }
   
    
//PROPIEDADES BÁSICAS    
//Método get observadores
    public Double getX() {
        return x;
    }

    public Double getY() {
        return y;
    }
    
    //PROPIEDAD DERIVADA
    public List <Cuadrante> getCuadrantes(){
        List <Cuadrante> res = new ArrayList<>();
        if (x==0.0 && y==0.0){
            res.add(Cuadrante.PRIMER_CUADRANTE);
            res.add(Cuadrante.SEGUNDO_CUADRANTE);
            res.add(Cuadrante.TERCER_CUADRANTE);
            res.add(Cuadrante.CUARTO_CUADRANTE);
        }else if (x==0.0 && y>0.0){
            res.add(Cuadrante.PRIMER_CUADRANTE);
            res.add(Cuadrante.SEGUNDO_CUADRANTE);
            
        }else if (x==0.0 && y <0.0){
            res.add(Cuadrante.TERCER_CUADRANTE);
            res.add(Cuadrante.CUARTO_CUADRANTE);
                
        }else if (y==0.0 && x >0.0){
            res.add(Cuadrante.PRIMER_CUADRANTE);
            res.add(Cuadrante.CUARTO_CUADRANTE);
            
        }else if (y==0.0 && x <0.0){
            res.add(Cuadrante.SEGUNDO_CUADRANTE);
            res.add(Cuadrante.TERCER_CUADRANTE);
            
        }else if (x>0.0 && y >0.0){
            res.add(Cuadrante.PRIMER_CUADRANTE);
            
        }else if (x>0.0 && y <0.0){
            res.add(Cuadrante.CUARTO_CUADRANTE);
            
        }else if (x<0.0 && y >0.0){
            res.add(Cuadrante.SEGUNDO_CUADRANTE);
            
        }else if (x<0.0 && y <0.0){
            res.add(Cuadrante.TERCER_CUADRANTE);
        }
        return res;
    }

    
    
    //PROPIEDAD BÁSICA SETTER
    public void setX(Double x) {
        this.x = x;
    }

    public void setY(Double y) {
        this.y = y;
    }

    @Override
    public String toString() {
        return "Punto{" + "x=" + x + ", y=" + y + '}';
    }
    
    

    
}    
