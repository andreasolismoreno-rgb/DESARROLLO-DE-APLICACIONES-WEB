package personas;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;

public class Empleado {

    private static void comprobarDni(Integer dni) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    //Atributos (SIEMPRE PRIVADOS)
    private String nombre; //No puede ser null ni tener menos de tres letras
    private String apellidos; //No puede ser null ni tener menos de tres letras
    private LocalDate fechaNacieminto; //No puede ser null ni tener futura
    private Integer dni;//Puede ser null , pero si no es null debe ser un dni válido
    private Double peso;// No puede ser null ni <=0.0
    //ojo private Integer Edad NO SE PONE
    
   private Double sueldo;

    public Empleado(String nombre, String apellidos, LocalDate fechaNacieminto, Integer dni, Double peso, Double sueldo) {
        if (nombre == null){
            throw new IllegalArgumentException("El nombre no puede ser null");
        }
        if(nombre.length()<3){
            throw new IllegalArgumentException("El nombre no puede tener menos de 3 letras");
        }
        
        
        if (apellidos == null){
            throw new IllegalArgumentException("Los apellidos no puede ser null");
        }
        if(apellidos.length()<3){
            throw new IllegalArgumentException("Los apellidos no puede tener menos de 3 letras");
        }
        
        
        if (fechaNacieminto == null){
            throw new IllegalArgumentException("La fecha de nacimeinto no puede ser null");
        }
        if(fechaNacieminto.compareTo(LocalDate.now()) >0){
            throw new IllegalArgumentException("La fecha de nacimiento no puede ser futura");
        }
        
        //Tb puede ponerse After(despues del dia de hoy)
//        if(fechaNacieminto.isAfter(LocalDate.now())){
//            throw new IllegalArgumentException("La fecha de nacimiento no puede ser futura");
//        }
        

        //DNI: Si es null no pasa nada pero si no es null hay que hacer algo
        
        
        
        if (peso == null){
            throw new IllegalArgumentException("El`peso no puede ser null");
        } if(peso <=0.0 ){
            throw new IllegalArgumentException("El`peso no puede ser negativo, ni cero");
        }       
        comprobarDni(dni);
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNacieminto = fechaNacieminto;
        this.dni = dni;
        this.peso = peso;
        this.sueldo = sueldo;
    }
        
//    Para verificar el NIF de españoles residentes mayores de edad, 
//    el algoritmo de cálculo del dígito de control es el siguiente:
//
//    Se divide el número entre 23 y el resto se sustituye por una letra que 
//    se determina por inspección mediante el siguiente ejemplo.
//    Por ejemplo, si el número del DNI es 12345678, dividido entre 23 da de resto 14, 
//    luego la letra sería la Z: 12345678Z.



//        private void comprobarDni(){
//            if (dni != null){
//                Character letra = dni.charAt(dni.length ()-1);
//                List <Character > letras = List.of( 'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B','N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C','K', 'E');
//                String dniSinLetra = dni.substring(0,dni.length()-1);
//                Integer numero = Integer.parseInt(dniSinLetra);
//                Integer resto = numero % 23;
//                if(!letra.equals (letras.get(resto))){
//                    throw new IllegalArgumentException("La letra del DNI no es correcta");
//                }
//            }               
//        }
//         
        
    
    
    //Estos métodos son OBSERVADORES
    public String getNombre() {
        
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public LocalDate getFechaNacieminto() {
        return fechaNacieminto;
    }

    public Integer getDni() {
        return dni;
    }

    public Double getPeso() {
        return peso;
    }

    public Integer getEdad (){
        return Period.between (fechaNacieminto, LocalDate.now()).getYears();
    }

    public Double getSueldo() {
        return sueldo;
    }
    

    
    
    
    //eSTOS MÉTODOS SON MODIFICADORES
    public void setNombre(String nombre) {
                if (nombre == null){
            throw new IllegalArgumentException("El nombre no puede ser null");
        }
        if(nombre.length()<3){
            throw new IllegalArgumentException("El nombre no puede tener menos de 3 letras");
        }
        this.nombre = nombre;
    }

    public void setApellidos(String apellidos) {
        if (apellidos == null){
            throw new IllegalArgumentException("Los apellidos no puede ser null");
        }
        if(apellidos.length()<3){
            throw new IllegalArgumentException("Los apellidos no puede tener menos de 3 letras");
        }
        this.apellidos = apellidos;
    }

    public void setFechaNacieminto(LocalDate fechaNacieminto) {
        if (fechaNacieminto == null){
            throw new IllegalArgumentException("La fecha de nacimeinto no puede ser null");
        }
        if(fechaNacieminto.compareTo(LocalDate.now()) >0){
            throw new IllegalArgumentException("La fecha de nacimiento no puede ser futura");
        }
        this.fechaNacieminto = fechaNacieminto;
    }

    public void setDni(Integer dni) {
        comprobarDni(dni);
        this.dni = dni;
    }

    public void setPeso(Double peso) {
                if (peso == null){
            throw new IllegalArgumentException("El`peso no puede ser null");
        } if(peso <=0.0 ){
            throw new IllegalArgumentException("El`peso no puede ser negativo, ni cero");
        }
        this.peso = peso;
    }

    public void setSueldo(Double sueldo) {
        this.sueldo = sueldo;
    }

    @Override
    public String toString() {
        return "Empleado{" + "nombre=" + nombre + ", apellidos=" + apellidos + ", fechaNacieminto=" + fechaNacieminto + ", dni=" + dni + ", peso=" + peso + ", sueldo=" + sueldo + '}';
    }
    
    

    
    
    
}
   
    
   