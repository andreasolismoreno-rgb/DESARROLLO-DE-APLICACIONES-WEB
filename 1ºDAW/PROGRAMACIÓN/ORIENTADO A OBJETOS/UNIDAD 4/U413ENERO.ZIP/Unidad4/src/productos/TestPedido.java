package productos;

public class TestPedido {
    public static void main(String[] args) {
        
        Producto prod1 = new Producto("Monitor", 100.0);
        Producto prod2 = new Producto("Ratón", 20.0);
        
        LineaPedido lin1 = new LineaPedido (prod1, 5);
        LineaPedido lin2 = new LineaPedido (prod2, 3);
        
        Pedido p = new Pedido();
        p.addLinea(lin1);
        p.addLinea(lin2);
        System.out.println(p);
        
        
    }
}
