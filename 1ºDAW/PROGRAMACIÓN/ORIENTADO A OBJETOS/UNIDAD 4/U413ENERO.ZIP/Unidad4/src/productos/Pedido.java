package productos;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private List<LineaPedido> lineas;
   
    public Pedido() {
    
        this.lineas = new ArrayList<>();
    }
    
    public void addLinea(LineaPedido linea) {
    
        this.lineas.add(linea);
    }

    // El getTotal es una Propiedad derivada (NO atributo): total
    public double getTotal() {
    double suma = 0;
    
    for (LineaPedido lp : lineas) {
    suma += lp.getSubtotal();
    }
    return suma;
    }

    @Override
    public String toString() {
        String res = "";
        for (LineaPedido linea : lineas){
            res += linea.getProducto().getNombre() + "-->" + linea.getCantidad() + ":" + linea.getSubtotal() + "\n";
        }
        res += "-----------------------------------\n";
        res += "                         Total: " + getTotal() + " euros\n";
        return res;
    }
    
   
}
