package productos;

public class TestProducto {
    public static void main (String [] args){
        Producto p1 = new Producto ("Fuente de alimentación", 25.0);
        System.out.println("El precio es " +p1.getPrecio());
        Producto p2 = new Producto ("Monitor 27 pulgadas", 340.0);
        System.out.println("El precio es " + p2.getPrecio());
        System.out.println("El precio es " +p1.getNombre());
        System.out.println("El precio es " +p2.getNombre());
        System.out.println(p1);
    }
}
