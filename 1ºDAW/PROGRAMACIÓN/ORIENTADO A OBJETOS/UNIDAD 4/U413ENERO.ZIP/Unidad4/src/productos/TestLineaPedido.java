package productos;

public class TestLineaPedido {
    public static void main(String[] args) {
        LineaPedido lp1 = new LineaPedido (new Producto ("Monitor", 100.0), 5);
        System.out.println(lp1);
        
    }
}
