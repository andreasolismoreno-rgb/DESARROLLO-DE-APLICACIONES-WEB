package productos;

public class LineaPedido {
    
    private Producto producto;
    private Integer cantidad;
    
    public LineaPedido (Producto producto, Integer cantidad){
        
        this.producto = producto;
        this.cantidad = cantidad;
    }
    
    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
        

// El subtotal es una Propiedad DERIVADA (NO atributo): se calcula
        
    public double getSubtotal() {
            
    return producto.getPrecio() * cantidad;
    
    }

    @Override
    public String toString() {
        return producto + "--> Cantidad=" + cantidad + " (subtutotal =" + getSubtotal ()+")";
    }

  

}
