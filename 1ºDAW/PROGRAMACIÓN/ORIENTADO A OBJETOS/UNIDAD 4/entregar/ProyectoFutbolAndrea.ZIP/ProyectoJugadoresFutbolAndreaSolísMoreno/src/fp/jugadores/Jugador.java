package fp.jugadores;

import fp.utiles.Checkers;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Objects;

public class Jugador implements Comparable<Jugador> {
//    Consultables= Getters
//    Modificables=Setters
//Propiedades:
//• Nombre, de tipo String, consultable

    private String nombre;

//• Fecha de nacimiento, de tipo LocalDate, consultable.
    private LocalDate fechaNacimiento;

//• Posición, de tipo Posicion, consultable. Puede tomar los valores PORTERO, DEFENSOR,
//CENTROCAMPISTA, DELANTERO.
    private Posicion posicion;

//• Goles, de tipo Integer, consultable.
    private Integer goles;

//• Asistencias, de tipo Integer, consultable.
    private Integer asistencias;

//• Equipo, de tipo Equipo, consultable.
    private Equipo equipo;

//Lesiones, de tipo List<String>, consultable. Tenga en cuenta que puede estar vacía.
    private List<String> lesiones;

    //Constructores:
    //• C1: recibe un parámetro por cada propiedad básica del tipo.
    public Jugador(String nombre, LocalDate fechaNacimiento, Posicion posicion, Integer goles, Integer asistencias, Equipo equipo, List<String> lesiones) {
        // R1: Fecha de nacimiento no anterior a 1970-01-01
        Checkers.check("La fecha de nacimiento no puede ser anterior a 1970", !fechaNacimiento.isBefore(LocalDate.of(1970, 1, 1)));

        // R2: Goles y asistencias >= 0
        Checkers.check("Los goles deben ser >= 0", goles >= 0);
        Checkers.check("Las asistencias deben ser >= 0", asistencias >= 0);

        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.posicion = posicion;
        this.goles = goles;
        this.asistencias = asistencias;
        this.equipo = equipo;
        this.lesiones = lesiones;
    }

    // 3. PROPIEDADES CONSULTABLES (Getters)
    public String getNombre() {
        return nombre;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public Posicion getPosicion() {
        return posicion;
    }

    public Integer getGoles() {
        return goles;
    }

    public Integer getAsistencias() {
        return asistencias;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public List<String> getLesiones() {
        return lesiones;
    }

    // 4. PROPIEDADES DERIVADAS (No se guardan, se calculan)
//propiedades derivadas, no se pone con las básicas
    //como sé que es una prop derivada? se puede saber la edad sacando la feha d enac? si, entonces la edad no es una prop básica
    // Edad: Calculamos la diferencia entre nacimiento y hoy
    public Integer getEdad() {
        return Period.between(fechaNacimiento, LocalDate.now()).getYears();
    }

//• Campeon, de tipo Boolean, consultable. Indica si el jugador pertenece al equipo campeón de la
//temporada.
    public Boolean getCampeon() {
        return equipo.clasificacion() == 1;
    }

    //• MismaLesionConsecutiva, de tipo Boolean. Indica si el jugador ha sufrido dos veces la misma lesión de
//forma consecutiva, teniendo en cuenta que la lista de lesiones ya está ordenada cronológicamente.
    public Boolean mismaLesionConsecutiva() {
        for (Integer i = 0; i < lesiones.size() - 1; i++) {
            if (lesiones.get(i).equalsIgnoreCase(lesiones.get(i + 1))) {
                return true;
            }
        }
        return false;
    }

    // 5. REPRESENTACIÓN COMO CADENA
    @Override
    public String toString() {
        return "Jugador [nombre=" + nombre + ", fechaNacimiento=" + fechaNacimiento
                + ", edad=" + getEdad() + ", posicion=" + posicion + ", goles=" + goles
                + ", asistencias=" + asistencias + ", equipo=" + equipo.nombre()
                + ", campeón=" + getCampeon() + "]";
    }

    // 6. CRITERIO DE IGUALDAD (equals y hashCode)
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Jugador other = (Jugador) obj;
        return Objects.equals(fechaNacimiento, other.fechaNacimiento)
                && Objects.equals(nombre, other.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, fechaNacimiento);
    }

    // 7. CRITERIO DE ORDENACIÓN (Comparable)
    @Override
    public int compareTo(Jugador o) {
        // Primero comparamos por fecha
        int res = this.fechaNacimiento.compareTo(o.getFechaNacimiento());
        // Si la fecha es la misma (res == 0), comparamos por nombre
        if (res == 0) {
            res = this.nombre.compareTo(o.getNombre());
        }
        return res;
    }
}
