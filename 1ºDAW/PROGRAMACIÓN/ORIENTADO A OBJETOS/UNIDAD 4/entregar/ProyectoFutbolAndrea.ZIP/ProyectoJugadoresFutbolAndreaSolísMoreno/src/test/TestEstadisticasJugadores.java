package test;

import fp.jugadores.EstadisticasJugadores;
import fp.jugadores.FactoriaJugadores;
import java.util.List;

public class TestEstadisticasJugadores {

    /*Escriba una clase TestEstadisticasJugadores en el paquete fp.jugadores.test. En la clase se leerán los datos del
    fichero y se probarán todos los tratamientos secuenciales, definiendo un método de test por cada
    tratamiento secuencial a probar.*/
    
    public static void main(String[] args) {
        // 1. Cargamos los datos usando la factoría El método que lee el csv se llama leerJugadores
        String ruta = "data/jugadores.csv";
        List<fp.jugadores.Jugador> listaJugadores = FactoriaJugadores.leerJugadores(ruta);

        // si la lista está vacía, es que no ha leído el archivo
        if (listaJugadores.isEmpty()) {
            System.out.println("ERROR: No se han podido cargar jugadores. Revisa la ruta del CSV.");
            return;
        }

        // Creamos el objeto de estadísticas
        EstadisticasJugadores stats = new EstadisticasJugadores(listaJugadores.stream());
        // 2. Ejecutamos los tests
        testNumeroLesionesDistintas(stats);
        testNJugadoresMasJovenes(stats);
        testEquipoMasGoleadorMedia(stats);
        testTodosEquiposLesionados(stats);
        testMejorJugadorPorEquipo(stats);
    }

    private static void testNumeroLesionesDistintas(EstadisticasJugadores stats) {
        System.out.println("EJERCICIO 4.1===================================================================");
        System.out.println("El número de lesiones distintas de los 6 primeros equipos es:");
        System.out.println(stats.getNumeroLesionesDistintas(7));

        System.out.println("El número de lesiones distintas de los 2 primeros equipos es:");
        System.out.println(stats.getNumeroLesionesDistintas(3));
    }

    private static void testNJugadoresMasJovenes(EstadisticasJugadores stats) {
        System.out.println("EJERCICIO 4.2===================================================================");
        System.out.println("Los 3 jugadores más jovenes sin lesión de la posicion DELANTERO son:");

        System.out.println(stats.getNJugadoresMasJovenesPosicionSinLesion(fp.jugadores.Posicion.DELANTERO, 3));

        System.out.println("Los 3 jugadores más jovenes sin lesión de la posicion CENTROCAMPISTA son:");

        System.out.println(stats.getNJugadoresMasJovenesPosicionSinLesion(fp.jugadores.Posicion.CENTROCAMPISTA, 3));
    }

    private static void testEquipoMasGoleadorMedia(EstadisticasJugadores stats) {
        System.out.println("EJERCICIO 4.3===================================================================");
        System.out.println("El equipo con mayor número de jugadores con goles por encima de la media es:");
        System.out.println(stats.getEquipoMasJugadoresConGolesSuperiorMedia());
    }

    private static void testTodosEquiposLesionados(EstadisticasJugadores stats) {
        System.out.println("EJERCICIO 4.4===================================================================");
        System.out.println("¿Todos los equipos tienen al menos un jugador que ha sufrido una lesion?:");
        System.out.println(stats.todosEquiposTienenJugadorLesionado());
    }

    private static void testMejorJugadorPorEquipo(EstadisticasJugadores stats) {
        System.out.println("EJERCICIO 4.5===================================================================");
        System.out.println("Los nombres de jugadores con mayor ratio goles/asistencias por equipo son:");

        stats.getNombreJugadorConMayorSumaGAPorEquipo().forEach((equipo, nombre) -> {
            System.out.println(equipo + "=" + nombre);
        });
    }
}
