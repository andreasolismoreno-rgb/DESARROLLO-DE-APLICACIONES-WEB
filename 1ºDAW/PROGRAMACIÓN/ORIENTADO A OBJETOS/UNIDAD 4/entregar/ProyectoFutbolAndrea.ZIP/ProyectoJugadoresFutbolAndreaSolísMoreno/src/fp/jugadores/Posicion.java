package fp.jugadores;

public enum Posicion {
    PORTERO, DEFENSOR, CENTROCAMPISTA, DELANTERO
}
