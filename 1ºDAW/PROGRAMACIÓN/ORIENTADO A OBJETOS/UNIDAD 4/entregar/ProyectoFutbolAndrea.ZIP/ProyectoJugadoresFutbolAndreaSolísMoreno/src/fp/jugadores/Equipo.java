package fp.jugadores;

import fp.utiles.Checkers;

public record Equipo(String nombre, Integer clasificacion, String estadio) {

    public Equipo   {
        //• R1: La posición en la clasificación debe estar comprendida entre 1 y 20.
        //• R2: La propiedad estadio debe comenzar por la cadena “Estadio”.
//        Checkers.check("La posición en la clasificación debe estar comprendida entre 1 y 20.", clasificacion<=1 && clasificacion>=20);
        if (clasificacion < 1 || clasificacion > 20) {
            throw new IllegalArgumentException("La posición en la clasificación debe estar comprendida entre 1 y 20.");
        }
        // Usamos startsWith para ver si el texto arranca así
//        Checkers.check("El estadio debe empezar por 'Estadio.'", estadio.startsWith("Estadio."));
    
        if (!estadio.startsWith("Estadio")) {
            throw new IllegalArgumentException("La propiedad estadio debe comenzar por la cadena “Estadio”.");
        }
    }
}
