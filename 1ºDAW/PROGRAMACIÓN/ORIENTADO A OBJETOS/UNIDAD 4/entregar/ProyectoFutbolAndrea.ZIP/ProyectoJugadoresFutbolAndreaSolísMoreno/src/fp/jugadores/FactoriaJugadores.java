package fp.jugadores;

import fp.utiles.Checkers;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FactoriaJugadores {
    
    //En el archivo csv el orden es:
    //nombre, fecha_nacimiento, posicion,goles, asistencias, lesiones (con los corchetes []),club,posicion_clasificacion,estadio
    public static Jugador parsearJugador(String lineaCSV) {
        // R1: Verificamos que la línea no sea nula
        Checkers.check("La línea no puede ser nula", lineaCSV != null);
        
        // Cortamos por el separador oficial del archivo: punto y coma
        String[] trozos = lineaCSV.split(";");
        
        // Verificamos que tengamos todas las columnas (debería haber 9)
        Checkers.check("Formato de línea incorrecto", trozos.length == 9);

        // 1. Datos básicos del Jugador
        String nombre = trozos[0].trim();
        LocalDate fechaNacimiento = LocalDate.parse(trozos[1].trim());
        // Pasamos a mayúsculas para que coincida con el Enum (DELANTERO, PORTERO...)
        Posicion posicion = Posicion.valueOf(trozos[2].trim().toUpperCase());
        Integer goles = Integer.valueOf(trozos[3].trim());
        Integer asistencias = Integer.valueOf(trozos[4].trim());

        // 2. Procesar la lista de lesiones "LESIÓN A, LESIÓN B"
        List<String> lesiones = parsearLesiones(trozos[5].trim());

        // 3. Crear el objeto equipo (Datos del club)
        String nombreEquipo = trozos[6].trim();
        Integer clasificacion = Integer.valueOf(trozos[7].trim());
        String estadio = trozos[8].trim();
        Equipo equipo = new Equipo(nombreEquipo, clasificacion, estadio);

        // 4. Devolvemos el jugador completo
        return new Jugador(nombre, fechaNacimiento, posicion, goles, asistencias, equipo, lesiones);
    }

    // Método auxiliar 
    private static List<String> parsearLesiones(String cadenaLesiones) {
        List<String> res = new ArrayList<>();
        // Quitamos los corchetes [ y ]
        String limpia = cadenaLesiones.substring(1, cadenaLesiones.length() - 1).trim();
        
        if (!limpia.isEmpty()) {
            String[] trozosLesion = limpia.split(",");
            for (String s : trozosLesion) {
                res.add(s.trim());
            }
        }
        return res;
    }

    
     // ESTO Lee todo el fichero CSV y devuelve una lista de objetos Jugador.
     
    public static List<Jugador> leerJugadores(String rutaFichero) {
        List<Jugador> res = new ArrayList<>();
        try {
            res = Files.lines(Paths.get(rutaFichero))
                       .skip(1) // Saltamos la primera línea (la cabecera: nombre;fecha...)
                       .map(linea -> parsearJugador(linea)) // Convertimos cada línea en un jugador
                       .collect(Collectors.toList());
        } catch (IOException e) {
            System.out.println("No se pudo leer el fichero: " + rutaFichero);
            e.printStackTrace();
        }
        return res;
    }
}
