package fp.jugadores;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EstadisticasJugadores {  // la clase con todos los métodos
    //Implemente el tipo EstadisticasJugadores en el paquete fp.jugadores y añada también los siguientes
    //tratamientos secuenciales al tipo EstadisticasJugadores:

    // propiedades
    private Set<Jugador> jugadores;

    // constructor C1 recibe un parámetro de tipo Stream<Jugador>. ---
    public EstadisticasJugadores(Stream<Jugador> streamJugadores) {
        if (streamJugadores == null) {
            throw new IllegalArgumentException("El stream de jugadores no puede ser nulo");
        }
        // Convertimos el Stream a un Set (conjunto)
        this.jugadores = streamJugadores.collect(Collectors.toSet());
    }

    //métodos consultables
    public Set<Jugador> getJugadores() {
        return new HashSet<>(this.jugadores); // Devolvemos copia para proteger la encapsulación
    }

    public Integer getNumJugadores() {
        return this.jugadores.size();
    }

    // representación como cadena
    //una cadena con todos los jugadores, separados por saltos de línea. "\n"
    @Override
    public String toString() {
        return jugadores.stream().map(Jugador::toString).collect(Collectors.joining("\n"));
    }

    // criterio de igualdad
    //dos objetos de tipo EstadisticasJugadores son iguales si lo son sus jugadores.
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EstadisticasJugadores that = (EstadisticasJugadores) o;
        return Objects.equals(jugadores, that.jugadores);
    }

    @Override
    public int hashCode() {
        return Objects.hash(jugadores);
    }

    // tratamientos secuenciales
    
    /* 1. dado un valor umbralClasificacion de tipo
    Integer, devuelve el número de lesiones distintas que han sufrido los jugadores de los equipos cuya
    clasificación sea menor que ese umbral. (1 pto)*/
    public Long getNumeroLesionesDistintas(Integer umbralClasificacion) {
        return jugadores.stream()
                .filter(j -> j.getEquipo().clasificacion() < umbralClasificacion)
                .flatMap(j -> j.getLesiones().stream()) // "Aplanamos" las listas de lesiones
                .distinct() // Evitamos contar dos veces la misma lesión
                .count();
    }

    /*2. Dado un número entero n,
    devuelve una lista con los nombres de los n jugadores más jóvenes que cumplen estas dos condiciones:
    su posición es igual a la posición p dada como parámetro y no han sufrido ninguna lesión en la
    temporada. (1 pto)*/
    public List<String> getNJugadoresMasJovenesPosicionSinLesion(Posicion p, Integer n) {
        return jugadores.stream()
                .filter(j -> j.getPosicion().equals(p))
                .filter(j -> j.getLesiones().isEmpty())
                // Ordenamos por fecha de nacimiento descendente (el que nació más tarde es más joven)
                .sorted(Comparator.comparing(Jugador::getFechaNacimiento).reversed())
                .limit(n)
                .map(Jugador::getNombre)
                .collect(Collectors.toList());
    }

    /*3. Devuelve el equipo con mayor número de
    jugadores cuyo número de goles sea superior a la media de goles de todos los jugadores. Si no se puede
    calcular, se eleva NoSuchElementException. (1,5 ptos)*/
    public Equipo getEquipoMasJugadoresConGolesSuperiorMedia() {
        // Calculamos la media de goles de todos los jugadores
        Double mediaGoles = jugadores.stream()
                .mapToDouble(Jugador::getGoles)
                .average()
                .orElseThrow(() -> new NoSuchElementException("No hay jugadores para calcular la media"));

        // Filtramos los que superan la media, agrupamos por equipo y contamos
        return jugadores.stream()
                .filter(j -> j.getGoles() > mediaGoles)
                .collect(Collectors.groupingBy(Jugador::getEquipo, Collectors.counting()))
                .entrySet().stream()
                .max(Map.Entry.comparingByValue()) // Buscamos el equipo con el contador más alto
                .map(Map.Entry::getKey)
                .orElseThrow(() -> new NoSuchElementException("No se pudo determinar el equipo"));
    }

    //4. Determina si todos los equipos cumplen la condición de que han tenido al menos un jugador con lesiones. (1,75 ptos)
    public Boolean todosEquiposTienenJugadorLesionado() {
        // Agrupamos jugadores por su equipo
        Map<Equipo, List<Jugador>> porEquipo = jugadores.stream()
                .collect(Collectors.groupingBy(Jugador::getEquipo));

        // Verificamos que todas las listas de jugadores (de cada equipo) tengan algún lesionado
        return porEquipo.values().stream()
                .allMatch(lista -> lista.stream().anyMatch(j -> !j.getLesiones().isEmpty()));
    }

    /*5. obtiene un SortedMap en el que a cada Equipo le hace corresponder el nombre del jugador con mayor suma de goles y asistencias.
    El SortedMap debe estar ordenado según la clasificación del equipo (de peor a mejor clasificado).
    Implemente este método con bucles. (1,75 ptos) (Se puede simplificar pidiendo el jugador completo en
    vez del nombre, si lo veis conveniente.)*/
    public SortedMap<Equipo, String> getNombreJugadorConMayorSumaGAPorEquipo() {
        // TreeMap ordenado por clasificación del equipo de forma descendente (peor puesto a mejor puesto)
        SortedMap<Equipo, String> resultado = new TreeMap<>(
                Comparator.comparing(Equipo::clasificacion).reversed()
        );

        // Mapa auxiliar para identificar al mejor jugador (máxima suma) de cada equipo
        Map<Equipo, Jugador> mejorJugadorDeCadaEquipo = new HashMap<>();

        for (Jugador j : jugadores) {
            Equipo eq = j.getEquipo();
            int sumaActual = j.getGoles() + j.getAsistencias();

            if (!mejorJugadorDeCadaEquipo.containsKey(eq)) {
                mejorJugadorDeCadaEquipo.put(eq, j);
            } else {
                Jugador maxActual = mejorJugadorDeCadaEquipo.get(eq);
                int sumaMax = maxActual.getGoles() + maxActual.getAsistencias();
                if (sumaActual > sumaMax) {
                    mejorJugadorDeCadaEquipo.put(eq, j);
                }
            }
        }

        // Una vez tenemos los mejores, los pasamos al SortedMap final guardando solo el nombre
        for (Map.Entry<Equipo, Jugador> entrada : mejorJugadorDeCadaEquipo.entrySet()) {
            resultado.put(entrada.getKey(), entrada.getValue().getNombre());
        }

        return resultado;
    }
}
