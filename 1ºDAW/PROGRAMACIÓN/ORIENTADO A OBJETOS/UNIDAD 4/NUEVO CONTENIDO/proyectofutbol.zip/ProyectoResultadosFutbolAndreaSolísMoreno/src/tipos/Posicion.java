package tipos;

public enum Posicion {
    PORTERO, DEFENSOR, CENTROCAMPISTA, DELANTERO
}
