package tipos;

import fp.utiles.Checkers;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

public class Jugador {
//    Consultables= Getters
//    Modificables=Setters
//Propiedades:
//• Nombre, de tipo String, consultable

    private String nombre;

//• Fecha de nacimiento, de tipo LocalDate, consultable.
    private LocalDate fechaNacimeinto;

//• Posición, de tipo Posicion, consultable. Puede tomar los valores PORTERO, DEFENSOR,
//CENTROCAMPISTA, DELANTERO.
    private Posicion posicion;

//• Goles, de tipo Integer, consultable.
    private Integer goles;

//• Asistencias, de tipo Integer, consultable.
    private Integer asistencias;

//• Equipo, de tipo Equipo, consultable.
    private Equipo equipo;

//Lesiones, de tipo List<String>, consultable. Tenga en cuenta que puede estar vacía.
    private List<String> lesiones;

    //propiedades derivadas, no se pone con las básicas
    //como sé que es una prop derivada? se puede saber la edad sacando la feha d enac? si, entonces la edad no es una prop básica
    //• Edad, de tipo Integer, consultable.
    //• MismaLesionConsecutiva, de tipo Boolean. Indica si el jugador ha sufrido dos veces la misma lesión de
//forma consecutiva, teniendo en cuenta que la lista de lesiones ya está ordenada cronológicamente.
    public Boolean mismaLesionConsecutiva() {
        for (Integer i = 0; i < lesiones.size() - 1; i++) {
            if (lesiones.get(i).equalsIgnoreCase(lesiones.get(i + 1))) {
                return true;
            }
        }
        return false;
    }
//• Campeon, de tipo Boolean, consultable. Indica si el jugador pertenece al equipo campeón de la
//temporada.

    public Boolean getCampeon() {
        return equipo.clasificacion() == 1;
    }

    //Constructores:
    //• C1: recibe un parámetro por cada propiedad básica del tipo.
    public Jugador(String nombre, LocalDate fechaNacimeinto, Posicion posicion, Integer goles, Integer asistencias, Equipo equipo, List<String> lesiones) {
        this.nombre = nombre;
        this.fechaNacimeinto = fechaNacimeinto;
        this.posicion = posicion;
        this.goles = goles;
        this.asistencias = asistencias;
        this.equipo = equipo;
        this.lesiones = lesiones;
    }

    public String getNombre() {
        return nombre;
    }

    public Posicion getPosicion() {
        return posicion;
    }

    public Integer getGoles() {
        return goles;
    }

    public Integer getAsistencias() {
        return asistencias;
    }

    public LocalDate getFechaNacimeinto() {
        return fechaNacimeinto;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public List<String> getLesiones() {
        return lesiones;
    }

    @Override
    public String toString() {
        return "Jugador{" + "nombre=" + nombre + ", fechaNacimeinto=" + fechaNacimeinto 
                + ", posicion=" + posicion + ", goles=" + goles + ", asistencias=" + asistencias 
                + ", equipo=" + equipo + ", lesiones=" + lesiones + '}';
    }
    
    
    
    

}
