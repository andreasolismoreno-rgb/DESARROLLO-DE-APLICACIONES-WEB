package modelo;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Avistamiento {
    //datetime,city,state,country,shape,duration (seconds),duration (hours/min),comments,date posted,latitude,longitude

    private LocalDateTime datetime;
    private String city;
    private String state;
    private String country;
    private String shape;   
    private Double duration; //Seconds, hours, minutes
    private String comments;
    
    private LocalDate dateposted;
    private Coordenada coordenada;

    public Avistamiento(LocalDateTime datetime, String city, String state, String country, String shape, Double duration, String comments, LocalDate dateposted, Coordenada coordenada) {
        this.datetime = datetime;
        this.city = city;
        this.state = state;
        this.country = country;
        this.shape = shape;
        this.duration = duration;
        this.comments = comments;
        this.dateposted = dateposted;
        this.coordenada = coordenada;
    }
    
    
    
}
