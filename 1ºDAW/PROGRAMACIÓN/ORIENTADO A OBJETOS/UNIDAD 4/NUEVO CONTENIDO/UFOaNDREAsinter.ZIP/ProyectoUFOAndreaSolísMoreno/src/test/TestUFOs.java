/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import java.util.List;
import modelo.Avistamiento;
import modelo.FactoriaAvistamientos;

/**
 *
 * @author DAW1-M
 */
public class TestUFOs {

    public static void main(String[] args) {
        List<Avistamiento> lista = FactoriaAvistamientos.leerAvistamientos("./data/complete.csv");
        System.out.println(lista.size());
    }
}