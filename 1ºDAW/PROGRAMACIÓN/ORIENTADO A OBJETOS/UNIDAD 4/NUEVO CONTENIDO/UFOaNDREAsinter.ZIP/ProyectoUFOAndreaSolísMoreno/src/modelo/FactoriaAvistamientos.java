package modelo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class FactoriaAvistamientos {

    public static List<Avistamiento> leerAvistamientos(String nombreFichero) {
        List<Avistamiento> res = new ArrayList<>();
        try {
            List<String> lineas = Files.readAllLines(Paths.get(nombreFichero));
            lineas.remove(0);
            for (String linea : lineas) {
                res.add(parsearAvistamiento(linea));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return res;
    }
    private LocalDateTime datetime; //la fecha y hora
    private String city; 
    private String state;
    private String country;
    private String shape;
    private Double duration; //Seconds, hours, minutes
    private String comments;
    private LocalDate dateposted; //la fecha de publicacion
    private Coordenada coordenada;

    private static Avistamiento parsearAvistamiento(String linea) {
        String[] trozos = linea.split(",");
        //System.out.println(++cont +" ----->   "+linea);
        //Checkers.check("Formato de linea incorrecto", trozos.length == 6);
        LocalDateTime datetime = LocalDateTime.parse(trozos[0].trim(), DateTimeFormatter.ofPattern("M/d/yyyy HH:mm"));
        String city = trozos[1].trim();
        String state = trozos[2].trim();
        String country = trozos[3].trim();
        String shape = trozos[4].trim();
        Double duration = Double.parseDouble(trozos[5].trim());
        String comments = trozos[7].trim();
        LocalDate dateposted = LocalDate.parse(trozos[8].trim(), DateTimeFormatter.ofPattern("M/d/yyyy"));
         Coordenada coordenada = new Coordenada(Double.parseDouble(trozos[9].trim()), Double.parseDouble(trozos[10].trim()));
        Avistamiento a = new Avistamiento(datetime, city, state, country, shape, duration, comments, dateposted, coordenada);
        return a;
    }
}
