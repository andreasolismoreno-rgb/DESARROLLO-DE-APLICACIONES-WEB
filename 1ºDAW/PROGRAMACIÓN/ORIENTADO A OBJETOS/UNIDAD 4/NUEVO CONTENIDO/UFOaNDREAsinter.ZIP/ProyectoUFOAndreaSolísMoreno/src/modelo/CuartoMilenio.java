package modelo;

import java.util.List;


public class CuartoMilenio { //es donde vamos a hcer los métodos
    private List <Avistamiento> avistamientos;
    
    //
}
