package fp.jugadores;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EstadisticasJugadores {

    // --- PROPIEDADES ---
    private Set<Jugador> jugadores;

    // --- CONSTRUCTOR C1 ---
    public EstadisticasJugadores(Stream<Jugador> streamJugadores) {
        if (streamJugadores == null) {
            throw new IllegalArgumentException("El stream de jugadores no puede ser nulo");
        }
        // Convertimos el Stream a un Set (conjunto)
        this.jugadores = streamJugadores.collect(Collectors.toSet());
    }

    // --- MÉTODOS CONSULTABLES ---
    public Set<Jugador> getJugadores() {
        return new HashSet<>(this.jugadores); // Devolvemos copia para proteger la encapsulación
    }

    public Integer getNumJugadores() {
        return this.jugadores.size();
    }

    // --- REPRESENTACIÓN COMO CADENA ---
    @Override
    public String toString() {
        return jugadores.stream().map(Jugador::toString).collect(Collectors.joining("\n"));
    }

    // --- CRITERIO DE IGUALDAD ---
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EstadisticasJugadores that = (EstadisticasJugadores) o;
        return Objects.equals(jugadores, that.jugadores);
    }

    @Override
    public int hashCode() {
        return Objects.hash(jugadores);
    }

    // --- TRATAMIENTOS SECUENCIALES ---

    /**
     * 1. Número de lesiones distintas de jugadores en equipos por debajo de un umbral de clasificación.
     */
    public Long getNumeroLesionesDistintas(Integer umbralClasificacion) {
        return jugadores.stream()
                .filter(j -> j.getEquipo().clasificacion() < umbralClasificacion)
                .flatMap(j -> j.getLesiones().stream()) // "Aplanamos" las listas de lesiones
                .distinct() // Evitamos contar dos veces la misma lesión
                .count();
    }

    /**
     * 2. N nombres de los jugadores más jóvenes de una posición dada que NO tengan lesiones.
     */
    public List<String> getNJugadoresMasJovenesPosicionSinLesion(Posicion p, Integer n) {
        return jugadores.stream()
                .filter(j -> j.getPosicion().equals(p))
                .filter(j -> j.getLesiones().isEmpty())
                // Ordenamos por fecha de nacimiento descendente (el que nació más tarde es más joven)
                .sorted(Comparator.comparing(Jugador::getFechaNacimiento).reversed())
                .limit(n)
                .map(Jugador::getNombre)
                .collect(Collectors.toList());
    }

    /**
     * 3. Equipo con mayor número de jugadores cuyos goles superan la media global de goles.
     */
    public Equipo getEquipoMasJugadoresConGolesSuperiorMedia() {
        // Calculamos la media de goles de todos los jugadores
        Double mediaGoles = jugadores.stream()
                .mapToDouble(Jugador::getGoles)
                .average()
                .orElseThrow(() -> new NoSuchElementException("No hay jugadores para calcular la media"));

        // Filtramos los que superan la media, agrupamos por equipo y contamos
        return jugadores.stream()
                .filter(j -> j.getGoles() > mediaGoles)
                .collect(Collectors.groupingBy(Jugador::getEquipo, Collectors.counting()))
                .entrySet().stream()
                .max(Map.Entry.comparingByValue()) // Buscamos el equipo con el contador más alto
                .map(Map.Entry::getKey)
                .orElseThrow(() -> new NoSuchElementException("No se pudo determinar el equipo"));
    }

    /**
     * 4. Determina si todos los equipos tienen al menos un jugador que haya tenido lesiones.
     */
    public Boolean todosEquiposTienenJugadorLesionado() {
        // Agrupamos jugadores por su equipo
        Map<Equipo, List<Jugador>> porEquipo = jugadores.stream()
                .collect(Collectors.groupingBy(Jugador::getEquipo));

        // Verificamos que todas las listas de jugadores (de cada equipo) tengan algún lesionado
        return porEquipo.values().stream()
                .allMatch(lista -> lista.stream().anyMatch(j -> !j.getLesiones().isEmpty()));
    }

    /**
     * 5. Nombre del jugador con mayor suma de Goles + Asistencias por equipo.
     * Implementado obligatoriamente con BUCLES.
     * Ordenado por clasificación del equipo (de peor a mejor: 20 -> 1).
     */
    public SortedMap<Equipo, String> getNombreJugadorConMayorSumaGAPorEquipo() {
        // TreeMap ordenado por clasificación del equipo de forma descendente (peor puesto a mejor puesto)
        SortedMap<Equipo, String> resultado = new TreeMap<>(
                Comparator.comparing(Equipo::clasificacion).reversed()
        );

        // Mapa auxiliar para identificar al mejor jugador (máxima suma) de cada equipo
        Map<Equipo, Jugador> mejorJugadorDeCadaEquipo = new HashMap<>();

        for (Jugador j : jugadores) {
            Equipo eq = j.getEquipo();
            int sumaActual = j.getGoles() + j.getAsistencias();

            if (!mejorJugadorDeCadaEquipo.containsKey(eq)) {
                mejorJugadorDeCadaEquipo.put(eq, j);
            } else {
                Jugador maxActual = mejorJugadorDeCadaEquipo.get(eq);
                int sumaMax = maxActual.getGoles() + maxActual.getAsistencias();
                if (sumaActual > sumaMax) {
                    mejorJugadorDeCadaEquipo.put(eq, j);
                }
            }
        }

        // Una vez tenemos los mejores, los pasamos al SortedMap final guardando solo el nombre
        for (Map.Entry<Equipo, Jugador> entrada : mejorJugadorDeCadaEquipo.entrySet()) {
            resultado.put(entrada.getKey(), entrada.getValue().getNombre());
        }

        return resultado;
    }
}