package test;

import java.time.Month;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import modelo.*;

public class TestUFOs {

    public static void main(String[] args) {
        // 1. CARGA DE DATOS
        System.out.println("=== PROYECTO OVNIS: CUARTO MILENIO ===");
        System.out.println("Cargando datos desde el CSV...");
        
        List<Avistamiento> listaCSV = FactoriaAvistamientos.leerAvistamientos("./data/complete.csv");
        
        if (listaCSV.isEmpty()) {
            System.out.println("Error: No se han podido cargar los datos. Revisa la carpeta /data/");
            return;
        }

        // 2. INICIALIZACIÓN DEL CONTENEDOR
        CuartoMilenio iker = new CuartoMilenio(listaCSV);
        System.out.println("Registros cargados con éxito: " + listaCSV.size());
        System.out.println("-------------------------------------------------");

        // 3. PRUEBAS
        System.out.println("1. ¿Existe un avistamiento circular en US?: " + iker.existeAvistamiento("us", "circle"));
        
        System.out.println("2. País con el avistamiento más reciente: " + iker.getPaisConAvistamientoMasReciente());

        System.out.println("3. Conteo de formas (top 5):");
        iker.getConteoPorForma().entrySet().stream()
                .limit(5)
                .forEach(e -> System.out.println("   - " + e.getKey() + ": " + e.getValue()));

        System.out.println("4. Duración media en el año 2000: " + iker.mediaDuracionPorAnio(2000) + " seg.");

        System.out.println("5. Ciudades con avistamientos en Diciembre (primeras 5):");
        Set<String> ciudadesDic = iker.getCiudadesPorMes(Month.DECEMBER);
        ciudadesDic.stream().limit(5).forEach(c -> System.out.println("   - " + c));

        // 6. PRUEBA DE COORDENADAS (Cerca de Sevilla por ejemplo)
        Coordenada miCasa = new Coordenada(37.38, -5.98);
        System.out.println("6. Los 3 OVNIs más cercanos a mi posición:");
        iker.getMasCercanosA(miCasa, 3).forEach(a -> 
            System.out.println("   - " + a.getCity() + " (" + a.getCountry() + ") a " + a.getDuration() + " seg de duración"));
            
        System.out.println("-------------------------------------------------");
        System.out.println("Fin del programa. La verdad está ahí fuera.");
    }
}