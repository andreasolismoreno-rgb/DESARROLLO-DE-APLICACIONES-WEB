package modelo;

import java.time.Month;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class CuartoMilenio { 
    private List<Avistamiento> avistamientos;

    // CONSTRUCTOR CORREGIDO: Ahora guarda la lista de verdad
    public CuartoMilenio(List<Avistamiento> lista) {
        this.avistamientos = new ArrayList<>(lista);
    }

    // --- 1. MÉTODOS DE FILTRADO Y BÚSQUEDA ---

    public Boolean existeAvistamiento(String pais, String forma) {
        return avistamientos.stream()
                .anyMatch(a -> a.getCountry().equalsIgnoreCase(pais) 
                          && a.getShape().equalsIgnoreCase(forma));
    }

    public List<Avistamiento> getAvistamientosLargos(Double segundos) {
        return avistamientos.stream()
                .filter(a -> a.getDuration() > segundos)
                .collect(Collectors.toList());
    }

    // --- 2. MÉTODOS DE ESTADÍSTICA ---

    public Map<String, List<Avistamiento>> getAvistamientosPorPais() {
        return avistamientos.stream()
                .collect(Collectors.groupingBy(Avistamiento::getCountry));
    }

    public Map<String, Long> getConteoPorForma() {
        return avistamientos.stream()
                .collect(Collectors.groupingBy(Avistamiento::getShape, Collectors.counting()));
    }

    public String getPaisConAvistamientoMasReciente() {
        return avistamientos.stream()
                .max(Comparator.comparing(Avistamiento::getDatetime))
                .map(Avistamiento::getCountry)
                .orElse("No hay datos");
    }

    // --- 3. MÉTODOS CON BUCLES ---

    public Map<String, Avistamiento> getMasLargoPorPaisBucle() {
        Map<String, Avistamiento> res = new HashMap<>();
        for (Avistamiento a : avistamientos) {
            String pais = a.getCountry();
            if (!res.containsKey(pais)) {
                res.put(pais, a);
            } else {
                if (a.getDuration() > res.get(pais).getDuration()) {
                    res.put(pais, a);
                }
            }
        }
        return res;
    }

    // --- 4. PROPIEDADES DERIVADAS ---

    public Double mediaDuracionPorAnio(Integer anio) {
        return avistamientos.stream()
                .filter(a -> a.getDatetime().getYear() == anio)
                .mapToDouble(Avistamiento::getDuration)
                .average()
                .orElse(0.0);
    }

    public Set<String> getCiudadesPorMes(Month mes) {
        return avistamientos.stream()
                .filter(a -> a.getDatetime().getMonth() == mes)
                .map(Avistamiento::getCity)
                .collect(Collectors.toSet());
    }

    // --- 5. ORDENACIÓN Y COORDENADAS ---

    public List<Avistamiento> getMasCercanosA(Coordenada c, Integer n) {
        return avistamientos.stream()
                .sorted(Comparator.comparing(a -> a.getCoordenada().distanciaA(c)))
                .limit(n)
                .collect(Collectors.toList());
    }
}