package modelo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class FactoriaAvistamientos {

public static List<Avistamiento> leerAvistamientos(String nombreFichero) {
        List<Avistamiento> res = new ArrayList<>();
        try {
            List<String> lineas = Files.readAllLines(Paths.get(nombreFichero));
            lineas.remove(0); // Quitamos la cabecera del CSV
            for (String linea : lineas) {
                res.add(parsearAvistamiento(linea));
            }
        } catch (IOException e) {
            System.out.println("Error al leer el fichero: " + e.getMessage());
        }
        return res;
    }

    private static Avistamiento parsearAvistamiento(String linea) {
        String[] trozos = linea.split(",");
        
        // Formatos de fecha del CSV (ajustar según el CSV real)
        DateTimeFormatter fmtFechaHora = DateTimeFormatter.ofPattern("M/d/yyyy HH:mm");
        DateTimeFormatter fmtFecha = DateTimeFormatter.ofPattern("M/d/yyyy");

        LocalDateTime datetime = LocalDateTime.parse(trozos[0].trim(), fmtFechaHora);
        String city = trozos[1].trim();
        String state = trozos[2].trim();
        String country = trozos[3].trim();
        String shape = trozos[4].trim();
        Double duration = Double.parseDouble(trozos[5].trim());
        String comments = trozos[7].trim();
        LocalDate dateposted = LocalDate.parse(trozos[8].trim(), fmtFecha);
        Coordenada coordenada = new Coordenada(Double.parseDouble(trozos[9].trim()), Double.parseDouble(trozos[10].trim()));

        return new Avistamiento(datetime, city, state, country, shape, duration, comments, dateposted, coordenada);
    }
}
