package productos;


public class Producto {
    
    //Atributos (SIEMPRE PRIVADOS)
    private String nombre; //DEBE NO SER NULL Y TENER AL MENOS TRES LETRAS
    private Double precio; //DEBE NO SER NULL Y SER >=0.0
    private Integer identificacion; 


    //Constructores por parámetro (SIEMPRE PÚBLICOS)
    public Producto (String nombre, Integer identificacion, Double precio){
        if (nombre == null){
            throw new IllegalArgumentException("El`nombre no puede ser null");
        }
        if(nombre.length()<3){
            throw new IllegalArgumentException("El`nombre no puede tener menos de 3 letras");
        }
        if (precio == null){
            throw new IllegalArgumentException("El`precio no puede ser null");
        } if(precio <0 ){
            throw new IllegalArgumentException("El`precio no puede ser negativo");
        }
        this.nombre = nombre;
        this.precio = precio;
        this.identificacion = identificacion;
    }
    
    
    
    //Métodos Getter (SON OBSERVADORES)
    public String getNombre(){
        return nombre;
    }

    public Integer getIentificacion(){
        return identificacion;
    }

    public Double getPrecio(){
        return precio;
    }


    public void setNombre ( String nombre){
        if (nombre == null){
            throw new IllegalArgumentException("El`nombre no puede ser null");
        }
        if(nombre.length()<3){
            throw new IllegalArgumentException("El`nombre no puede tener menos de 3 letras");
        }
        this.nombre = nombre;
    }
    
    
    
    public void setPrecio (Double precio){
        if (precio == null){
            throw new IllegalArgumentException("El`precio no puede ser null");
        } if(precio <0 ){
            throw new IllegalArgumentException("El`precio no puede ser negativo");
        }
        this.precio = precio;
    }
    
    
    //Otro método
    public void subirPrecio(double incremento) {
        this.precio += incremento;
    }
    
    
    
    
}
