package test;

import modelo.Biblioteca;
import modelo.Libro;

public class BibliotecaTest {

    public static void main(String[] args) {
        
        
        Libro lib1 = new Libro ("123", "El Quijote", "Cervantes", 1605, 20.0);
        Libro lib2 = new Libro ("456", "Correspondencia", "Albert Camus", 1944, 15.0);
        Libro lib3 = new Libro ("789", "Cien años de soledad", "García Márquez", 1967, 25.0);
        Libro lib4 = new Libro ("321", "Poesía Completa", "Rafael de León", 1941, 12.0);
        Libro lib5 = new Libro ("654", "Emma", "Jane Austen", 1815, 18.0);
       
        
        
        Biblioteca biblio = new Biblioteca("Biblioteca de Sevilla");
        biblio.addLibro(lib1);
        biblio.addLibro(lib2);
        biblio.addLibro(lib3);
        biblio.addLibro(lib4);
        biblio.addLibro(lib5);
        
               
        System.out.println(biblio.getLibroMasCaro());
        System.out.println(biblio.getValorReposicionTotal());

        // 2. Probar removePorIsbn 
        // Caso inexistente
        System.out.println("¿Eliminado ISBN '999' (no existe)?: " + biblio.removePorIsbn("999")); 
        // Caso existente
        System.out.println("¿Eliminado ISBN '456' (Albert Camus)?: " + biblio.removePorIsbn("456"));
        System.out.println(biblio.toString());

        Libro mascaro = biblio.getLibroMasCaro();
        if (mascaro != null) {
            System.out.println("El libro más caro es: " + mascaro.getTitulo() + " (" + mascaro.getPrecioReposicion() + "€)");
        }

        System.out.println("Valor total : " + biblio.getValorReposicionTotal() + "€");
        System.out.println("Precio medio por libro: " + biblio.getPrecioMedioReposicion() + "€");
        
        
    }
     
}
