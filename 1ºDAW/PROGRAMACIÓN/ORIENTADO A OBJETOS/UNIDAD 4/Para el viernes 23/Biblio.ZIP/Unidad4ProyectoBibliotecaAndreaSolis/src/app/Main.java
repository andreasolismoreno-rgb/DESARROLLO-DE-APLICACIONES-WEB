package app;

import modelo.Libro;

public class Main {
     public static void main(String[] args) {
        Libro lib1 = new Libro ("123", "El Quijote", "Cervantes", 1605, 20.0);
        Libro lib2 = new Libro ("456", "Correspondencia", "Albert Camus", 1944, 15.0);
        Libro lib3 = new Libro ("789", "Cien años de soledad", "García Márquez", 1967, 25.0);
        Libro lib4 = new Libro ("321", "Poesía Completa", "Rafael de León", 1941, 12.0);
        Libro lib5 = new Libro ("654", "Emma", "Jane Austen", 1815, 18.0);
        
        System.out.println( lib1 );
        System.out.println( lib2 );
        System.out.println( lib3 );
        System.out.println( lib4 );
        System.out.println( lib5 );
        
        
    }
    
}
