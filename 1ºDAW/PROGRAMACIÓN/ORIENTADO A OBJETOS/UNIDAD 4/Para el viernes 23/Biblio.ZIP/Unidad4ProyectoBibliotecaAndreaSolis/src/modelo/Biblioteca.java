package modelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Biblioteca {

    //3.1 Atributos
    private String nombre;
    private List<Libro> libros;

    //3.2 Constructor
    public Biblioteca(String nombre) {
        if (nombre == null || nombre.equals("")) {
            throw new IllegalArgumentException("El nombre de la biblioteca no puede ser null ni estar vacio");
        }
        this.nombre = nombre;
        this.libros = new ArrayList<>();
    }

    //Métodos
    //Gestión básica
    public void addLibro(Libro libro) {
        if (libro == null) {
            throw new IllegalArgumentException("No se permite nulos");
        }
        if (existeIsbn(libro.getIsbn())) {
            throw new IllegalArgumentException("ISBN está repetido");
        }
        libros.add(libro);
    }

    public boolean existeIsbn(String isbn) {
        for (Libro lib : libros) {
            if (lib.getIsbn().equals(isbn)) {
                return true;
            }
        }
        return false;
    }

    public boolean removePorIsbn(String isbn) {
        Libro lib = buscarPorIsbn(isbn);
        if (lib != null) {
            return libros.remove(lib);
        }
        return false;
    }

    public Libro buscarPorIsbn(String isbn) {
        for (Libro lib : libros) {
            if (lib.getIsbn().equals(isbn)) {
                return lib;
            }
        }
        return null;
    }

    //CORREGIDO
//    public Libro buscarPorIsbn(String isbn){  
//        Boolean result = false;
//        Libro libro2 = null;
//        for(Libro libro :libros){
//            if(libro.getIsbn().equals(isbn)){
//                libro2 = libro;
//                break;
//            }
//        }
//        return result;
//    }
//CORREGIDO 
//
//    public Libro buscarPorIsbn(String isbn) {
//        for (Libro lib : libros) {
//            if (lib.getIsbn().equals(isbn)) {
//                return lib; 
//            }
//        }
//        return null; 
//    }
    //corregido.
//    
//    public boolean existeIsbn(String isbn){
//        return buscarPorIsbn(isbn)! = null;
//    }
    //CORREGIDO
//        public Boolean existeIsbn(String isbn){ 
//        Boolean result = false;
//        for(Libro libro :libros){
//            if (libro.getIsbn().equals(isbn)){
//                result = true;
//                break;
//            }
//        }
//        return result;
//        }
    //Métodos de búsqueda y filtrado
    //ASÍ
    public List<Libro> buscarPorAutor(String autor) {
        List<Libro> res = new ArrayList();
        for (Libro libro : libros) {
            if (libro.getAutor().equalsIgnoreCase(autor)) {
                res.add(libro);
            }
        }
        return res;
    }

    public List<Libro> listarClasicos() {
        List<Libro> clasicos = new ArrayList<>();
        for (Libro lib : libros) {
            // Llamamos al método de la clase Libro
            if (lib.isClasico()) {
                clasicos.add(lib);
            }
        }
        return clasicos;
    }

    public List<Libro> listarPorAnio(int anio) {
        List<Libro> res = new ArrayList<>();
        for (Libro lib : libros) {
            if (lib.getAnioPublicacion().equals(anio)) {
                res.add(lib); // Añadimos a la sublista
            }
        }
        return res;
    }

    public List<Libro> buscarPorTituloContiene(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            throw new IllegalArgumentException("El texto de búsqueda no puede estar vacío");
        }
        List<Libro> res = new ArrayList<>();
        for (Libro lib : libros) {
            if (lib.getTitulo().toLowerCase().contains(texto.toLowerCase())) {
                res.add(lib); //
            }
        }
        return res;
    }

    //Cálculos (propiedades derivadas: NO almacenar)
    public Libro getLibroMasCaro() {
        if (libros.isEmpty()) {
            return null;
        }
        Libro masCaro = libros.get(0);
        for (Libro lib : libros) {
            if (lib.getPrecioReposicion() > masCaro.getPrecioReposicion()) {
                masCaro = lib;
            }
        }
        return masCaro;
    }

    public Double getPrecioMedioReposicion() {
        if (libros.isEmpty()) {
            return 0.0;
        }
        return getValorReposicionTotal() / libros.size();
    }

    public Double getValorReposicionTotal() {
        Double total = 0.0;
        for (Libro lib : libros) {
            total += lib.getPrecioReposicion();
        }
        return total;
    }

    public int getTotalLibros() {
        return libros.size();
    }

//D) Ordenación
    
    public List<Libro> getLibrosOrdenadosPorTitulo(){
        List<Libro> res = getLibros();
        Collections.sort(res, Comparator.comparing(Libro::getTitulo));
        return res;
    }
    
    public List<Libro> getLibrosOrdenadosPorAnioDesc(){
        
        Comparator<Libro> c = Comparator.comparing(Libro::getAnioPublicacion);
        List<Libro> res = getLibros();
        Collections.sort(res, c.reversed());
        return res;
    }

    //Encapsulación:
    public List<Libro> getLibros() {
        return new ArrayList<>(libros);
    }

    @Override
    public String toString() {

        return "Biblioteca: " + nombre + "Total libros: " + libros.size() + '}';
    }

}
