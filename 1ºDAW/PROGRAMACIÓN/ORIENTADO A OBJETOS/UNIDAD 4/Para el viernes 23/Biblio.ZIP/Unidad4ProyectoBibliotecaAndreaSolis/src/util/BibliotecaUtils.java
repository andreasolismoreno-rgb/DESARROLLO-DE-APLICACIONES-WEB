package util;

import modelo.Biblioteca;
import modelo.Libro;

public class BibliotecaUtils {

    public static String normalizarTexto(String s) {
    if (s == null) return null;
    return s.trim().replaceAll("\\s+", " ");
    }
    
    public static double redondear2(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
    
    public static int contarLibrosDeAutor(Biblioteca b, String autor) {
        int cont = 0;
        for (Libro lib : b.getLibros()) { 
            if (lib.getAutor().equalsIgnoreCase(autor)) {
                cont++;
            }
        }
        return cont;
    }
    
}
