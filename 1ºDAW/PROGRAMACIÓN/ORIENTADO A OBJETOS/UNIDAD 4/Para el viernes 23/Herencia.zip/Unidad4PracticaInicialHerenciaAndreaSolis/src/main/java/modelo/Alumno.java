package modelo;

public class Alumno extends Persona {

    private String grupo;

    public Alumno(String dni, String nombre, String grupo) {
        super(dni, nombre); // llamada al constructor padre
        this.grupo = grupo;
    }

    public String getGrupo() {
        return grupo;
    }

    @Override
    public String presentarse() {
        return super.presentarse() + " y soy del grupo " + grupo;
    }

    @Override
    public String toString() {
        return "Alumno [DNI=" + getDni() + ", Nombre=" + getNombre() + ", Grupo=" + grupo + "]";
    }

}
