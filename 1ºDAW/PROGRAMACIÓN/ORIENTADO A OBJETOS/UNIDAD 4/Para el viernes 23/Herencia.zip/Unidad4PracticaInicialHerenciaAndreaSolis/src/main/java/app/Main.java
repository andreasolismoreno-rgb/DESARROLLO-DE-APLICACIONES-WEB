package app;

import modelo.Alumno;
import modelo.Persona;

public class Main {

    public static void main(String[] args) {
        Persona p = new Persona("111A", "Ana");

        Alumno a = new Alumno("222B", "Luis", "1DAW");

        System.out.println(p.presentarse());
        System.out.println(a.presentarse());
    }
}
