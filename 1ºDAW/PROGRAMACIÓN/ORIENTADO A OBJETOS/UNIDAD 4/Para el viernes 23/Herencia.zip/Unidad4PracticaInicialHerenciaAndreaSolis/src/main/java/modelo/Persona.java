package modelo;

public class Persona {

    //ATRIBUTOS (2)
    private String dni;
    private String nombre;

    //CONSTRUCTOR
    public Persona(String dni, String nombre) {
        this.dni = dni;
        this.nombre = nombre;
    }

    //GETTERS
    public String getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public String presentarse() {
        return "Soy " + nombre + " (DNI: " + dni + ")";
    }

    @Override
    public String toString() {
        return "Persona [DNI=" + dni + ", Nombre=" + nombre + "]";
    }
}
