package app;

import java.time.LocalDate;
import modelo.LineaPedido;
import modelo.Pedido;
import modelo.Producto;

public class Main {
   public static void main(String[] args) {

        Producto p1 = new Producto("Teclado", 19.99);
        Producto p2 = new Producto("Ratón", 9.50);

        LineaPedido l1 = new LineaPedido(p1, 2);
        LineaPedido l2 = new LineaPedido(p2, 3);

        Pedido pedido = new Pedido(LocalDate.now()); 

        pedido.addLinea(l1);
        pedido.addLinea(l2);

        System.out.println(pedido);
        
        
        Pedido pedidoDemo = DatosEjemplo.crearPedidoDemo();        
        System.out.println("Total: " + pedidoDemo.getTotal() + " €");
        System.out.println("Total con descuento aplicado: " + pedidoDemo.getTotalConDescuento() + " €");
        System.out.println("Número de articulos : " + pedidoDemo.getNumeroArticulos());
    }
}
