package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import utiles.PrecioUtils;

public class Pedido {

    private List<LineaPedido> lineas;

//    9. Usa java.time.LocalDate para guardar la fecha del pedido. (Constructor de
//Pedido que reciba fecha).
//Criterios: RA2-b, RA2-g.
    private LocalDate fechaPedido;

    public Pedido(LocalDate fechaPedido) {
        lineas = new ArrayList<>();
        this.fechaPedido = fechaPedido;

    }

    public LocalDate getFechaPedido() {
        return fechaPedido;
    }

    public Pedido() {

        //o también this(LocalDate.now());
        this.lineas = new ArrayList<>();
    }

    public void addLinea(LineaPedido linea) {

        if (linea != null) {
            lineas.add(linea);
        }
    }

    // El getTotal es una Propiedad derivada (NO atributo): total
    public double getTotal() {
        double suma = 0.0;

        for (LineaPedido lp : lineas) {
            suma += lp.getSubtotal();
        }
        return suma;
    }

//    En Pedido, añade getNumeroArticulos() como propiedad derivada (suma de
//cantidades).
//Criterios: RA2-d, RA4-c.
    public Integer getNumeroArticulos() {
        Integer res = 0;

        for (LineaPedido lp : lineas) {
            res += lp.getCantidad();
        }
        return res;
    }

//    public Integer getNumeroArticulos() {
//        int totalArticulos = 0;
//        for (LineaPedido lp : lineas) {
//            totalArticulos += lp.getCantidad();
//        }
//        return totalArticulos;
//    }
//    Añade descuento: si el total supera 50 €, aplica 10% de descuento. Implementa
//getTotalConDescuento() como propiedad derivada (no almacenar).
//Criterios: RA2-d, RA4-c.
    public Double getTotalConDescuento() {
        return getTotal() > 50.0 ? 0.9 * getTotal() : getTotal();
    }

    //NO SE HA HECHO EN CLASE. 11. Haz que lineas en Pedido sea inmodificable desde fuera:
//● getLineas() devuelve una copia o una vista no modificable.
//Criterios: RA4-f.
// Devuelve una vista NO modificable
    public List<LineaPedido> getLineas() {
        return Collections.unmodifiableList(lineas);
    }

//    12. Añade un método removeLineaPorCodigoProducto(String codigo) en
//Pedido.
//Criterios: RA2-d, RA2-f.
    public void removeLineaPorCodigoProducto(String codigo) {
        for (LineaPedido linea : lineas) {
            if (linea.getProducto().getCodigo().equals(codigo)) {
                lineas.remove(linea);
            }
        }
    }

    @Override
    public String toString() {
        String res = "Pedido: " + fechaPedido + "\n";
        for (LineaPedido lp : lineas) {
            res += lp.getDescripcionLarga() + "\n";
        }

        res += "Total (" + getNumeroArticulos() + " articulos): " + getTotalConDescuento() + "€";

        return res;
    }

}
