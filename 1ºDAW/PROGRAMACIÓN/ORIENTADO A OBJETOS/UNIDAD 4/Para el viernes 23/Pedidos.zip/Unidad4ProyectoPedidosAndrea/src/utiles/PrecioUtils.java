package utiles;

public class PrecioUtils {
    public static double redondear2(double valor){
        return Math.round( valor * 100.0) / 100.0;
    }
}
