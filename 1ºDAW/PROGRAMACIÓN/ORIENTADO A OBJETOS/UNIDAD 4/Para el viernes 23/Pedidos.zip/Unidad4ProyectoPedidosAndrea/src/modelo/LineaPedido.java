package modelo;

public class LineaPedido {
    private Producto producto;
    private Integer cantidad;
    
    public LineaPedido (Producto producto, Integer cantidad){
        
        this.producto = producto;
        this.cantidad = cantidad;
    }
    
    public Producto getProducto() { return producto; }
    public Integer getCantidad() { return cantidad; }
    
// El subtotal es una Propiedad DERIVADA (NO atributo): se calcula
        
    public double getSubtotal() {
            
    return producto.getPrecio() * cantidad;
    
    }
        

    @Override
    public String toString() {
        return producto + "--> Cantidad=" + cantidad + " (subtutotal =" + getSubtotal()+")";
    }
    
    //"2 x Teclado (19.99 €) = 39.98 €"
    public String getDescripcionLarga(){
        //Al principio te dice error cuando pones return cantidad, pq es un Integer y tu has puesto String
        //pero le pones + "" y ya queda normal
        
        
        //es parecido a un toString()
        return cantidad + " x " + producto.getNombre() + 
                " ("+producto.getPrecio()+" €) = " + getSubtotal()+" €";
    }
    
    
}
