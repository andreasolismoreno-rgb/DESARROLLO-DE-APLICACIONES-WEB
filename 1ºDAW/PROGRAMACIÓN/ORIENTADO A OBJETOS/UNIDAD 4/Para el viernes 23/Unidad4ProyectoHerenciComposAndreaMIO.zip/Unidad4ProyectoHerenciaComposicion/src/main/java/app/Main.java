package app;

import modelo.Alumno;
import modelo.Asignatura;
import modelo.Profesor;

public class Main {

    public static void main(String[] args) {

        // 1. Asignaturas
        Asignatura asig1 = new Asignatura("PROG", "Programación", 8);
        Asignatura asig2 = new Asignatura("BBDD", "Bases de Datos", 6);
        Asignatura asig3 = new Asignatura("LM", "Lenguajes de Marcas", 4);
        Asignatura asig4 = new Asignatura("ED", "Entornos de Desarrollo", 3);
        Asignatura asig5 = new Asignatura("SIS", "Sistemas Informáticos", 6);

        // 2. 2 alumnos y 1 profesor
        Alumno al1 = new Alumno("123A", "Tonino", "1DAW");
        Alumno al2 = new Alumno("456B", "Marta", "2DAW");
        Profesor prof = new Profesor("789P", "Carlos", "Informática", 18);

        // 3. Matriculamos asignaturas al primer alumno
        al1.matricular(asig1);
        al1.matricular(asig2);
        al1.matricular(asig3);

        // 4. Matriculamos asignaturas al segundo alumno
        al2.matricular(asig5);
        al2.matricular(asig4);

        // 5. Probamos a desmatricular (quitamos PROGRAMACIÓN del alumno 1 (Tonino)
        al1.desmatricularPorCodigo("PROG");

        // 6. Mostramos los resultados por consola
        System.out.println("Profesor: ");
        System.out.println(prof.toString());
        System.out.println(prof.presentarse());

        System.out.println("Alumno1: ");
        System.out.println(al1.toString());
        System.out.println("Horas totales de matrícula: " + al1.horasTotales() + "h");

        System.out.println("Alumno 2:");
        System.out.println(al2.toString());
        System.out.println("Horas totales de matrícula: " + al2.horasTotales() + "h");
    }
}
