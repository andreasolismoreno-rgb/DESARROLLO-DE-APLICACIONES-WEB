package test;

import modelo.Alumno;
import modelo.Persona;
import modelo.Profesor;

public class TestHerencia {

    public static void main(String[] args) {

        Persona p1 = new Persona("111A", "Rodrigo ");
        Persona p2 = new Persona("222B", "Alonso ");
        System.out.println(p1.presentarse());
        System.out.println(p2.presentarse());

        Alumno a1 = new Alumno("333C", "Tonino ", "1DAW");
        Alumno a2 = new Alumno("444D", "Marta ", "2DAW");

        System.out.println(a1.presentarse());
        System.out.println(a2.toString());

        Profesor prof1 = new Profesor("555E", "Carlos", "Informática", 18);
        Profesor prof2 = new Profesor("666F", "Julia ", "Matemáticas", 20);

        System.out.println(prof1.presentarse());
        System.out.println(prof2.toString());
    }
}
