package test;


import modelo.Persona;
import modelo.Profesor;

public class Test {
    public static void main(String[] args) {
     
        Persona p1 = new Persona("222F", "Ana");
        System.out.println(p1.presentarse());
        
        Profesor pr = new Profesor ("11111S","Pepe","Matemáticas",20);
        System.out.println(pr.presentarse());

    }
}
