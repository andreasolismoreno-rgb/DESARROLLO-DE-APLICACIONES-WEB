package app;

import modelo.Alumno;
import modelo.Persona;
import modelo.Profesor;

public class Main {
    public static void main(String[] args) {
        Persona p = new Persona("111A", "Ana");
        Alumno a = new Alumno( "222B", "Luis", "1DAW");
        Profesor pr = new Profesor ("144C", "Rodrigo", "Matematicas", 9 );
        System.out.println(p.presentarse());
        System.out.println(a.presentarse());
        System.out.println(a.getNombre());
        System.out.println(pr.presentarse());
    }
}