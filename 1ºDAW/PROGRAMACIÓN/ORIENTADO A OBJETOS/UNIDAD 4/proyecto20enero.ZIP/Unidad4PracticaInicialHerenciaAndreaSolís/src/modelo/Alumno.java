package modelo;

public class Alumno extends Persona {
    private String grupo;
    
    
    //Tiene 3 atributos.
    public Alumno(String dni, String nombre, String grupo) {
        
        
    //Constructor padre
    super(dni, nombre); // Al poner esto public class Alumno extends Persona {
                        //te da error , por ello hay que crear si o si un constructor padre
                        
    this.grupo = grupo;
    
    }

    
    public String getNombre(){
        return "Don " + super.getNombre();
    }
    public String getGrupo() { 
        return grupo; 
    }
    
    @Override
    public String presentarse() {
    return super.presentarse() + " y soy del grupo " + grupo;
    
    }
}