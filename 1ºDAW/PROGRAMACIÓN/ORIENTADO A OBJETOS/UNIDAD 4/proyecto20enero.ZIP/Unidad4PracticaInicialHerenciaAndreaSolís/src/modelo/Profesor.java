package modelo;

public class Profesor extends Persona {

    private String departamento;
    private Integer horasSemanales;

    public Profesor(String dni, String nombre, String departamento, Integer horasSemanales) {
        super(dni, nombre);
        this.departamento = departamento;
        this.horasSemanales = horasSemanales;
    }

    @Override
    public String presentarse() {
        return super.presentarse() + " pertenezco al departamento " + departamento + " y hago " + horasSemanales + " horas semanales";
    }

}
