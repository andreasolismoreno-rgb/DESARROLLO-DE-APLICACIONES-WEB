package utilidadcollections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class EjercicioutilidadcollectionS {
        
    public static void main(String[] args) {

        ejemploMax();
        ejemploMin();
        ejemploSort();
        ejemploShuffle();
        ejemploReverse();
    }

    // 1. Collections.max() - Devuelve el mayor elemento de la lista
    public static void ejemploMax() {
        List<Integer> lista = Arrays.asList(1, 8, 22, 3);
        int mayor = Collections.max(lista);
        System.out.println("Ejemplo max(): " + mayor);
    }

    // 2. Collections.min() - Devuelve el menor elemento de la lista
    public static void ejemploMin() {
        List<Integer> lista = Arrays.asList(1, 8, 22, 3);
        int menor = Collections.min(lista);
        System.out.println("Ejemplo min(): " + menor);
    }

    // 3. Collections.sort() - Ordena la lista de menor a mayor
    public static void ejemploSort() {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 8, 22, 3));
        Collections.sort(lista);
        System.out.println("Ejemplo sort(): " + lista);
    }

    // 4. Collections.shuffle() - Mezcla los elementos de la lista aleatoriamente
    public static void ejemploShuffle() {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 8, 22, 3));
        Collections.shuffle(lista);
        System.out.println("Ejemplo shuffle(): " + lista);
    }

    // 5. Collections.reverse() - Invierte el orden de la lista
    public static void ejemploReverse() {
        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 8, 22, 3));
        Collections.reverse(lista);
        System.out.println("Ejemplo reverse(): " + lista);
    }

     public static void metodosejemplo (String [] args){
        int[] arr = {1, 8, 24, 3, 2, 2, 4};

        ejemploMax(arr);
        ejemploMin(arr);
        ejemploSort(arr);
        ejemploReverse(arr);
        
    }

    // 1. Max
    public static void ejemploMax(int[] arr) {
        int max = arr[0];
        for (int n : arr) if (n > max) max = n;
        System.out.println("Max array: " + max);
    }

    // 2. Min
    public static void ejemploMin(int[] arr) {
        int min = arr[0];
        for (int n : arr) if (n < min) min = n;
        System.out.println("Min array: " + min);
    }

    // 3. Sort (burbuja simple)
    public static void ejemploSort(int[] arr) {
        int[] copy = Arrays.copyOf(arr, arr.length);
        for (int i = 0; i < copy.length - 1; i++) {
            for (int j = 0; j < copy.length - i - 1; j++) {
                if (copy[j] > copy[j + 1]) {
                    int temp = copy[j];
                    copy[j] = copy[j + 1];
                    copy[j + 1] = temp;
                }
            }
        }
        System.out.println("Sort array: " + Arrays.toString(copy));
    }


    // 4. Reverse
    public static void ejemploReverse(int[] arr) {
        int[] copy = Arrays.copyOf(arr, arr.length);
        for (int i = 0; i < copy.length / 2; i++) {
            int temp = copy[i];
            copy[i] = copy[copy.length - 1 - i];
            copy[copy.length - 1 - i] = temp;
        }
        System.out.println("Reverse array: " + Arrays.toString(copy));
    }

}


