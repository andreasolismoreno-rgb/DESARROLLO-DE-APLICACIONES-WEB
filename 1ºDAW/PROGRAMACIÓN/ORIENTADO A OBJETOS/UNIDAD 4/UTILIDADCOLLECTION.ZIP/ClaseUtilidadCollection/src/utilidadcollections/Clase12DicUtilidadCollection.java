package utilidadcollections;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;



public class Clase12DicUtilidadCollection {
    public static void main (String [] args){
        List <Integer>lis = new ArrayList<>();
        lis.add(4);lis.add(54);lis.add(14);lis.add(-6);lis.add(4);
        System.out.println(lis); //me imprime la lista anterior
        System.out.println("El máximo es : " +Collections.max(lis));
        System.out.println("El mínimo es : " +Collections.min(lis));
        Collections.shuffle(lis);       
        System.out.println(lis);
        Collections.sort(lis);        
        System.out.println("La lista ordenada es : "+lis);
        Collections.reverse(lis);
        System.out.println("La lista al revés es : "+lis);

        
        Cliente c1 = new Cliente ("Pepe", 20, LocalDate.of(2005, 03, 28));
        Cliente c2 = new Cliente ("Bertram", 22, LocalDate.of(2003, 02, 10));
        Cliente c3 = new Cliente ("Alonso", 17, LocalDate.of(2008, 01, 22));
        Cliente c4 = new Cliente ("Rodrigo", 25, LocalDate.of(2000, 11, 04));
        Cliente c5 = new Cliente ("Cristina", 17, LocalDate.of(2008, 03, 28));

        
        
        List<Cliente> liscli = new ArrayList<>();
        liscli.add(c1);
        liscli.add(c2);
        liscli.add(c3);
        liscli.add(c4);
        liscli.add(c5);
        
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
        System.out.println(c4);
        System.out.println(c5);
        System.out.println("");
        for(Cliente e : liscli){
            System.out.println(e);
        }
        System.out.println("");
        
        Collections.reverse(liscli);
        System.out.println(liscli);
        System.out.println("");

        Collections.sort(liscli, Comparator.comparing(c->c.getEdad()));
        System.out.println(liscli);//quiero que me lo ordene por la edad, y muestro la lista
        
        
        Collections.sort(liscli, Comparator.comparing(c->c.getNombre()));
        System.out.println(liscli);//quiero que me lo ordene por nombre, y muestro la lista
        
        
        Collections.sort(liscli, Comparator.comparing(c->c.getFecha()));
        System.out.println(liscli);//quiero que me lo ordene por fecha de nacimiento, y muestro la lista
        
        System.out.println(Collections.max(liscli, Comparator.comparing(c->c.getEdad())));
        System.out.println(Collections.max(liscli, Comparator.comparing(c->c.getNombre())));
         System.out.println(Collections.min(liscli, Comparator.comparing(c->c.getNombre())));
        
        System.out.println("");
          
        Collections.shuffle(liscli); 
        System.out.println(liscli);
        System.out.println("");
    }
}