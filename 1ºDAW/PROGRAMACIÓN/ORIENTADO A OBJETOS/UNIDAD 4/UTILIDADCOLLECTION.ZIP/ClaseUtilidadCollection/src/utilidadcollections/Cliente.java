package utilidadcollections;

import java.time.LocalDate;

public class Cliente {
    public static void main (String [] args){
    
}

    private String nombre;
    private Integer edad;
    private LocalDate fecha;

    Cliente(String nombre, Integer edad, LocalDate fecha) {
        this.nombre = nombre;
        this.edad = edad;
        this.fecha = fecha;
    }


    public String getNombre() {
        
        return nombre;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
    
    

    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", edad=" + edad + ", fecha=" + fecha +'}';
    }
    
    
}
