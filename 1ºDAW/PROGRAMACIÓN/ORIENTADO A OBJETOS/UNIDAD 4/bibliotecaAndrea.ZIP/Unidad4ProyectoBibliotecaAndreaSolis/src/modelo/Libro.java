package modelo;

import java.time.LocalDate;

public class Libro {
    
    //Atributos. Siempre privados
    
    private String isbn;
    private String titulo;
    private String autor;
    private Integer anioPublicacion;
    private Double precioReposicion;

    
    //Constructor público
    public Libro(String isbn, String titulo, String autor, Integer anioPublicacion, Double precioReposicion) {
        if (isbn == null) {
            throw new IllegalArgumentException("El isbn no puede ser null");
        }
        if (titulo == null) {
            throw new IllegalArgumentException("El titulo no puede ser null");
        }   
        if (autor == null && autor.equals(" ")) {
            throw new IllegalArgumentException("El autor no puede ser null");
        }
        
        if (anioPublicacion <=1450 && anioPublicacion>= 2100  ) {
            throw new IllegalArgumentException("El año no puede ser antes o después de 1450 y 2100");
        }
        
        if (precioReposicion < 0.0) {
            throw new IllegalArgumentException("El`precio no puede ser negativo");
        }
        
        
        
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
        this.precioReposicion = precioReposicion;
    }

    public Libro() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    
    
    

    
    //Métodos de acceso y modificacdión
    
    //Métodos Getters
    public String getIsbn() {
        return isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public Integer getAnioPublicacion() {
        return anioPublicacion;
    }

    public Double getPrecioReposicion() {
        return precioReposicion;
    }

    
    //Métodos Setters
    public void setIsbn(String isbn) {
        if (isbn == null) {
            throw new IllegalArgumentException("El isbn no puede ser null");
        }
        this.isbn = isbn;
    }

    public void setTitulo(String titulo) {
        if (titulo == null) {
            throw new IllegalArgumentException("El titulo no puede ser null");
        } 
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
        if (autor == null) {
            throw new IllegalArgumentException("El autor no puede ser null");
        }
    }

    public void setAnioPublicacion(Integer anioPublicacion) {
        if (anioPublicacion <=1450 && anioPublicacion>= 2100 ) {
            throw new IllegalArgumentException("El año no puede ser antes o después de 1450 y 2100");
        }
        this.anioPublicacion = anioPublicacion;
    }

    public void setPrecioReposicion(Double precioReposicion) {
        if (precioReposicion < 0.0) {
            throw new IllegalArgumentException("El`precio no puede ser negativo");
        }
        this.precioReposicion = precioReposicion;
    }
    
    
    
    //Propiedades derivadas (no atributos)
    public boolean isClasico() { 
        
        return true; }
    
    
    public String getFichaCorta() { 
        return "titulo — autor"; }

    @Override
    public String toString() {
        
        return "Libro{" + "isbn=" + isbn + ", titulo=" + titulo + ", autor=" + autor + ", anioPublicacion=" + anioPublicacion + ", precioReposicion=" + precioReposicion + isClasico()+'}';
    }
    

       
    
    
}
