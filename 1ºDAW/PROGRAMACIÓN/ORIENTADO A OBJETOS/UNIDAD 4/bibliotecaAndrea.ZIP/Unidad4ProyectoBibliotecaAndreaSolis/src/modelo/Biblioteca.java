package modelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Biblioteca {
    
    
    //Atributos
    private String nombre;
    private List<Libro> libros;
    
    //Constructor

    public Biblioteca(String nombre) {
        if (nombre == null) {
            throw new IllegalArgumentException("El`nombre no puede ser null");
        }
        
        libros = new ArrayList <>();
        this.nombre = nombre;
    }
    
    
    
    //Métodos
    
    //Gestión básica
    public void addLibro(Libro libro, Object isbn) {
        if (libro == null) {
            throw new IllegalArgumentException("El libro no puede ser null");
        }
        

//        if (isbn ) {
//            throw new IllegalArgumentException("El isbn no puede ser igual");
//        }
        
        this.libros.add(libro);
    }
    

    public boolean removePorIsbn(String isbn){
        
        
        this.libros.remove(buscarPorIsbn(isbn));
        return false;
    }
    
    public Libro buscarPorIsbn(String isbn){
        
        for (Libro e : libros) {
        if (!libros.buscarPorIsbn().buscarPorIsbn().equals(isbn)) {
            } else {
            libros.remove(libros);
            }
        return null;
        
    }
    
    public boolean existeIsbn(String isbn){
        boolean contains = this.libros.contains(isbn);
        return true;
        
    }
    
    
    //Métodos de búsqueda y filtrado
    
    List<Libro> buscarPorAutor(String autor){
        this.libros.equals(autor);
        return null;
    }
    
    
    List<Libro> buscarPorTituloContiene(String texto){
        if (texto == null) {
            throw new IllegalArgumentException("El texto no puede ser null");
        }
        this.libros.contains(texto);
        return null;
        
    }
    
    List<Libro> listarClasicos(){
        this.libros.contains(listarClasicos());
        return null;
        
    }
    
    List<Libro> listarPorAnio(int anio){
        this.libros.contains(anio);
        return null;
        
    }
    
    
    

    //Cálculos (propiedades derivadas: NO almacenar)
    public int getTotal() {
    int suma = 0;
    
    for (Libro l : libros) {
    suma += libros.getTotal();
    }
    return suma;
    }
        
    public int getTotalLibros(){
        return (int) (getTotal() : getTotalLibros());
    }

    
    public double getValorReposicionTotal() {
    double suma = 0;
    
    for (Libro precioReposicion : libros) {
    suma += precioReposicion.getTotalLibros();
    }
    return suma;
    }
    
    
    public Libro getLibroMasCaro(){

        return null;

    }
    
    public double getPrecioMedioReposicion(){
        
        return 0;
        
    }
    
    
    //Ordenación
    public List<Libro> getLibrosOrdenadosPorTitulo(){
        
        return Collections.unmodifiableList(libros);
        
    }
    
    
    public List<Libro> getLibrosOrdenadosPorAnioDesc(){
        
        return getLibrosOrdenadosPorAnioDesc ();
        
    }
    
    
    //Encapsulación:
    public List<Libro> getLibros(){
        return Collections.unmodifiableList(libros);
    }

    @Override
    public String toString() {
        return "Biblioteca{" + "nombre=" + nombre + ", libros=" + libros + getTotalLibros() + '}';
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
