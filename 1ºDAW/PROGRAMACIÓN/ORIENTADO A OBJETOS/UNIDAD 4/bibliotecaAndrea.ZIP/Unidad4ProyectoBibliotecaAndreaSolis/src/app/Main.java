package app;

import modelo.Libro;

public class Main {
    
    Libro l1 = new Libro ();
    Libro l2 = new Libro ();
    
   
    
}
