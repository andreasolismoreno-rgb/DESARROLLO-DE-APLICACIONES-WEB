package test;

import modelo.Libro;

public class BibliotecaTest {
    public static void main (String [] args){
        Libro l1 = new Libro();
        System.out.println(l1);
        Libro l2 = new Libro();
        System.out.println(l2);
        Libro l3 = new Libro();
        System.out.println(l3);
        Libro l4 = new Libro();
        System.out.println(l4);
        Libro l5 = new Libro();
        System.out.println(l5);
    }
}
