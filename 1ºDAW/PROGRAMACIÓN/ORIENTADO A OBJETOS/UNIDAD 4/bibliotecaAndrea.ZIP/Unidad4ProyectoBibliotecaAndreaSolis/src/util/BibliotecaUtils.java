package util;

import modelo.Biblioteca;

public class BibliotecaUtils {
    public static String normalizarTexto(String s){
        
        return null;
        
    }
    
    public static double redondear2(double valor){
         return Math.round( valor * 100.0) / 100.0; 
    }
    
    public static int contarLibrosDeAutor(Biblioteca b, String autor){
        
        return 0;
        
    }
    
    
}
