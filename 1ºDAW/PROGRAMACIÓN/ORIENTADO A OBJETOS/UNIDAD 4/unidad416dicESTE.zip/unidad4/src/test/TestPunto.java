package test;

import modelo.Punto;

public class TestPunto {
    public static void main(String [] args){
        Punto p1 = new Punto (1.8, 2.2);
        Punto p2 = new Punto ( 2.0, 4.6);
        Punto p3 = new Punto ();
        //hemos instanciado (usado) 3 objetos
        
        System.out.println(p1.getX());
        p1.setX(4.4);
        System.out.println(p1.getX());
        
        System.out.println(p1);
        System.out.println(p1.toString());
        System.out.println(p1.getCuadrante());
        
        Punto p34= new Punto (-2.0, -5.0);
        System.out.println("El punto " +p34+ " está en el " +p34.getCuadrante());

    }
}
