package modelo;

public class Punto {
    
    //Atributos o propiedades básicas (son SIEMPRE privados)
    private Double x;
    private Double y;

    
    //métodos son SIEMPRE públicos
    //Estos son constructores (hay muchos)
    
    
    //constrcutor por defecto
    public Punto() {
        this.x = 0.0;
        this.y = 0.0;
    }
    
//    tb se puede hacer así y pinta igual    
//    public Punto() {
//        this(0.0, 0.0);
//    }
    
    
    
    
    //constrcutor por parámetro
    public Punto(Double x, Double y) {
        this.x = x;
        this.y = y;
    }

    
    //Métodos getter (observadores)
    public Double getX() {
        return x;
        
        //tb puede poner return this.x; y devuelve igual.
    }

    public Double getY() {
        return y;
    }
    
    
    
    //Métodos setter (modificadores)

    public void setX(Double x) {
        this.x = x;
    }

    public void setY(Double y) {
        this.y = y;
    }

    @Override  //es un método que nos indica que está sobreescribiendo un método que ya existe
    public String toString() {
        return "Punto { " + "x=" + x + ", y=" + y + '}';
        
        
        //run: Punto { x=4.4, y=2.2}
            // Punto { x=4.4, y=2.2}
    }
    
    public Cuadrante getCuadrante(){
        Cuadrante res = Cuadrante.CUARTO_CUADRANTE;
        if (x>0.0 && y>0.0){
            res = Cuadrante.PRIMER_CUADRANTE;
            
        }else if (x<0.0 && y>0.0){
            res = Cuadrante.SEGUNDO_CUADRANTE;
            
        }else if (x<0.0 && y<0.0){
            res = Cuadrante.TERCER_CUADRANTE;
        }
        return res;
    }

    
    
    
}
