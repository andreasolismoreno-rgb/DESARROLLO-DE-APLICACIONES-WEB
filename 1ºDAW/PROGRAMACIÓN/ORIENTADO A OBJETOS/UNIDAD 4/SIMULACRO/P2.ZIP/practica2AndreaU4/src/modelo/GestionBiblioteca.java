package modelo;

import java.util.*;

public class GestionBiblioteca {

    private List<Recurso> lista;

    public GestionBiblioteca() {
        this.lista = new ArrayList<>();
    }

    // AÑADIR (Añadir un recurso)
    public void agregarRecurso(Recurso r) {
        if (r != null) {
            lista.add(r);
        }
    }

    // BORRAR (Estructura Iterator que te gusta)
    public void eliminarPorCodigo(String codigoABorrar) {
        Iterator<Recurso> it = lista.iterator();
        while (it.hasNext()) {
            Recurso r = it.next();
            if (r.getCodigo().equalsIgnoreCase(codigoABorrar)) {
                it.remove();
            }
        }
    }

    // BUSCAR (Retorna un objeto)
    public Recurso buscarPorTitulo(String tituloBuscado) {
        for (Recurso r : lista) {
            if (r.getTitulo().contains(tituloBuscado)) {
                return r;
            }
        }
        return null;
    }

    // FILTRAR (Retorna una lista nueva)
    public List<Libro> obtenerSoloLibrosGrandes(Integer paginasMinimas) {
        List<Libro> librosGrandes = new ArrayList<>();
        for (Recurso r : lista) {
            if (r instanceof Libro) {
                Libro l = (Libro) r; // Casting (Gafas de libro)
                if (l.getNumPaginas() > paginasMinimas) {
                    librosGrandes.add(l);
                }
            }
        }
        return librosGrandes;
    }

    // MEDIA (Estilo Profesor)
    public Double getMediaPrecios() {
        Double suma = 0.0;
        for (Recurso r : lista) {
            suma += r.getPrecioBase();
        }
        return suma / lista.size();
    }

    // ¿EXISTE? (Booleano)
    public boolean existeRevistaEdicion(Integer edicion) {
        for (Recurso r : lista) {
            if (r instanceof Revista && ((Revista) r).getNumeroEdicion().equals(edicion)) {
                return true;
            }
        }
        return false;
    }
}