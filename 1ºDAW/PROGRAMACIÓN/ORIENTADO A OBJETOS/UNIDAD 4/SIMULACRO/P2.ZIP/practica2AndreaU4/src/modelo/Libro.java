package modelo;

public class Libro extends Recurso {
    private Integer numPaginas;

    public Libro(Integer numPaginas, String titulo, String codigo, Double precioBase) {
        super(titulo, codigo, precioBase);
        this.numPaginas = numPaginas;
    }

    public Integer getNumPaginas() {
        return numPaginas;
    }
    

    @Override
    public Double calcularCostoAlquiler() {
        return getPrecioBase() + 2.0; // Los libros tienen un plus de 2€
    }
}