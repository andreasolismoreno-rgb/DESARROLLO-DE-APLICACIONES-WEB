package app;

import java.util.List;
import modelo.GestionBiblioteca;
import modelo.Libro;
import modelo.Revista;

public class Main {
    public static void main(String[] args) {
        GestionBiblioteca biblio = new GestionBiblioteca();

        // Creamos recursos
        Libro l1 = new Libro(500, "Don Quijote", "L001", 10.0);
        Revista r1 = new Revista(12, "National Geographic", "R99", 5.0);
        Libro l2 = new Libro(100, "Java para Principiantes", "L002", 20.0);

        // Los añadimos
        biblio.agregarRecurso(l1);
        biblio.agregarRecurso(r1);
        biblio.agregarRecurso(l2);

        // Probamos la media
        System.out.println("Media de precios base: " + biblio.getMediaPrecios());

        // Probamos filtrar (Libros de más de 300 páginas)
        List<Libro> grandes = biblio.obtenerSoloLibrosGrandes(300);
        System.out.println("Libros grandes encontrados: " + grandes.size());

        // Probamos el borrado
        System.out.println("Borrando la revista R99...");
        biblio.eliminarPorCodigo("R99");
    }
}
