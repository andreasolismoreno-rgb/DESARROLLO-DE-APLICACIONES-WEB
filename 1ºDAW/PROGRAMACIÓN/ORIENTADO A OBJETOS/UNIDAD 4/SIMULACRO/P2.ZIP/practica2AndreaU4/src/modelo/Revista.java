package modelo;

public class Revista extends Recurso {
    private Integer numeroEdicion;

    public Revista(Integer numeroEdicion, String titulo, String codigo, Double precioBase) {
        super(titulo, codigo, precioBase);
        this.numeroEdicion = numeroEdicion;
    }

    public Integer getNumeroEdicion() {
        return numeroEdicion;
    }
    
    

    @Override
    public Double calcularCostoAlquiler() {
        return getPrecioBase() * 0.5; // Las revistas cuestan la mitad
    }
}