package modelo;

public abstract class Recurso {

    private String titulo;
    private String codigo;
    private Double precioBase;

    public Recurso(String titulo, String codigo, Double precioBase) {
        this.titulo = titulo;
        this.codigo = codigo;
        this.precioBase = precioBase;
    }

    public abstract Double calcularCostoAlquiler(); // Método abstracto

    // Getters
    public String getTitulo() {
        return titulo;
    }

    public String getCodigo() {
        return codigo;
    }

    public Double getPrecioBase() {
        return precioBase;
    }
}
