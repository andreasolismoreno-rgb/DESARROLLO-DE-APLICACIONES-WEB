package modelo;

public class Comercial extends Empleado {

    private Double ventasMensuales;

    public Comercial(Double ventasMensuales, String nombre, String dni, Double sueldoBase) {
        super(nombre, dni, sueldoBase);
        this.ventasMensuales = ventasMensuales;
    }

    public Double getVentasMensuales() {
        return ventasMensuales;
    }

    @Override
    public Double calcularSueldoFinal() {
        return getSueldoBase() + (ventasMensuales * 0.1);
    }
}
