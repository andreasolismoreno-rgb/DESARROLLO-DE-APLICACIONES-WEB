package modelo;

public class Tecnico extends Empleado {

    private String especialidad;

    public Tecnico(String especialidad, String nombre, String dni, Double sueldoBase) {
        super(nombre, dni, sueldoBase);
        this.especialidad = especialidad;
    }

    
    @Override
    public Double calcularSueldoFinal() {
        return getSueldoBase() + 200;
    }

    public String getEspecialidad() {
        return especialidad;
    }

}
