package app;

import modelo.*;

public class Main {

    public static void main(String[] args) {

// 1. CREAMOS EL OBJETO GESTOR (Donde vive la lista)
        GestionEmpleados miEmpresa = new GestionEmpleados();

        // 2. CREAMOS Y CONTRATAMOS TÉCNICOS
        // Directamente en el método contratar
        miEmpresa.contratarEmpleado(new Tecnico("Programador", "Rodrigo", "11111111B", 1500.0));

        // 3. CREAMOS Y CONTRATAMOS COMERCIALES
        // Creamos la variable primero para poder asignarle ventas antes de contratarlo
        Comercial c1 = new Comercial(500.0, "María", "22222222X", 2000.0);
        miEmpresa.contratarEmpleado(c1);

        Comercial c2 = new Comercial(0.0, "Roberto", "33333333G", 1080.0);
        miEmpresa.contratarEmpleado(c2);

        // 4. PROBAMOS LOS MÉTODOS DE LA CLASE GESTIÓN
        System.out.println("--- Informe de Empresa ---");
        System.out.println("Empleados totales: " + miEmpresa.totalEmpleados());
        System.out.println("Coste total de nóminas: " + miEmpresa.calcularCosteTotalNominas() + "€");

        // 5. PROBAMOS EL MÉTODO ESTRELLA (El que más cobra)
        Empleado estrella = miEmpresa.obtenerEmpleadoEstrella();
        System.out.println("El empleado que más cobra es: " + estrella.getNombre()
                + " con " + estrella.calcularSueldoFinal() + "€");

        // 6. LIMPIEZA CON ITERATOR (Despedir a los de 0 ventas)
        System.out.println("\n--- Ejecutando despido de comerciales sin ventas ---");
        miEmpresa.despedirComercialesSinVentas();

        System.out.println("Empleados tras la purga: " + miEmpresa.totalEmpleados());

        // 7. MOSTRAR LOS QUE QUEDAN (Como en tu ejemplo)
        System.out.println("\n--- Lista final de empleados ---");
        // Nota: Tendrías que tener un getter en GestionEmpleados que devuelva la lista
        // o simplemente imprimir los resultados de tus métodos.
        for (Empleado e : miEmpresa.getEmpleados()) { // Asumiendo que tienes un getter de la lista
            System.out.println(e); // Esto usará el toString() que escribiste
        }

        System.out.println("Media de ventas: " + miEmpresa.mediaVentasTotales() + "€");
        System.out.println("Media de sueldo general: " + miEmpresa.mediaSueldoTotal() + "€");
        System.out.println("Media de sueldo comerciales: " + miEmpresa.mediaSueldoComerciales() + "€");
        System.out.println("Porcentaje de técnicos: " + miEmpresa.porcentajeTecnicos() + "%");
    }

}
