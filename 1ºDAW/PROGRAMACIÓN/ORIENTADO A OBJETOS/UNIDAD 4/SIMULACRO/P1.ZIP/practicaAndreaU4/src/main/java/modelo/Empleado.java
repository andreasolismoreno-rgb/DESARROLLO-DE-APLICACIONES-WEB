package modelo;

//Clase Abstracta
public abstract class Empleado {

    //Atributos privados 
    private String nombre;
    private String dni;
    private Double sueldoBase;

    //Constructor público
    public Empleado(String nombre, String dni, Double sueldoBase) {

        // Validación del DNI
        if (dni == null || dni.length() < 9) {
            throw new IllegalArgumentException("El DNI debe tener al menos 9 caracteres.");
        }

        // Validación del Sueldo Base
        if (sueldoBase < 1000) {
            throw new IllegalArgumentException("El sueldo base no puede ser inferior a 1000€.");
        }
        this.nombre = nombre;
        this.dni = dni;
        this.sueldoBase = sueldoBase;
    }

    //Getters
    public String getNombre() {
        return nombre;
    }

    public String getDni() {

        // Validación del DNI
        if (dni == null || dni.length() < 9) {
            throw new IllegalArgumentException("El DNI debe tener al menos 9 caracteres.");
        }
        return dni;
    }

    public Double getSueldoBase() {
        return sueldoBase;
    }

    //Setters
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public void setSueldoBase(Double sueldoBase) {
        // Validación del Sueldo Base
        if (sueldoBase < 1000) {
            throw new IllegalArgumentException("El sueldo base no puede ser inferior a 1000€.");
        }
        this.sueldoBase = sueldoBase;
    }

    //Método abstracto 
    public abstract Double calcularSueldoFinal();

    //toString
    @Override
    public String toString() {
        return "Empleado{" + "nombre=" + nombre + ", dni=" + dni + ", sueldoBase=" + sueldoBase + '}';
    }

}
