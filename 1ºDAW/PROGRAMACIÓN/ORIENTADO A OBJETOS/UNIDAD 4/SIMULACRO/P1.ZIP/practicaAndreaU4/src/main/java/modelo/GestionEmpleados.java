package modelo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GestionEmpleados { //Preparo la carpeta

    private List<Empleado> empleados; //Creo una lista vacía 

    public GestionEmpleados() {
        this.empleados = new ArrayList<>();
    }

    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public void contratarEmpleado(Empleado e) {
        empleados.add(e);

        //Mete este papel en la carpeta".Simplemente usa el método .add(). 
        //Como la lista es de tipo Empleado, acepta tanto a Técnicos como a Comerciales (esto es el polimorfismo)
    }

    // 2. Devuelve cuántas personas trabajan
    public int totalEmpleados() {
        return empleados.size();

    }

    //Suma de todos los sueldos finales
    public double calcularCosteTotalNominas() {
        double total = 0;
        for (Empleado e : empleados) {
            total += e.calcularSueldoFinal();
        }
        return total;

        //El bucle for-each va uno por uno.
    }

    // 4. Iterator: Eliminar comerciales con ventas = 0
    public void despedirComercialesSinVentas() {
        Iterator<Empleado> it = empleados.iterator();
        while (it.hasNext()) {
            Empleado e = it.next();
            // Comprobamos si es un Comercial usando 'instanceof'
            if (e instanceof Comercial) {
                // Hacemos un "casting" para poder acceder a .getVentas()
                if (((Comercial) e).getVentasMensuales() == 0) {
                    it.remove();
                }
            }
        }

//        Coge un puntero (Iterator) y recorre la lista. Si ves a un comercial que no ha vendido nada, 
//                sácalo de la oficina inmediatamente".
//
//Por qué es así: * instanceof Comercial: Es como preguntar "¿Tú eres del departamento de ventas?".
//
//((Comercial) e): Como lo tienes guardado como un empleado normal, Java no te deja ver sus ventas. 
//El "casting" es como ponerte unas gafas especiales para ver los atributos específicos del Comercial.
//
//it.remove(): Es la forma segura de borrar. Es como si el Iterator dijera: 
//"He anotado a este para borrarlo sin que la lista se desordene mientras sigo caminando".
    }

    // 5. Empleado con el sueldo más alto
    public Empleado obtenerEmpleadoEstrella() {
        if (empleados.isEmpty()) {
            return null;
        }

        Empleado estrella = empleados.get(0);
        for (Empleado e : empleados) {
            if (e.calcularSueldoFinal() > estrella.calcularSueldoFinal()) {
                estrella = e;
            }
        }
        return estrella;

//        1.De momento, el primero de la lista es mi favorito (estrella)". 2. Vas comparando con los demás. "
//        + "3. Si encuentras a alguien que cobre más, "
//        + "lo sustituyes en tu mano. Al final del bucle, te quedas con el mejor.
    }

    // 1. Media total de VENTAS (Solo de los comerciales)
    public double mediaVentasTotales() {
        double sumaVentas = 0;
        int contadorComerciales = 0;

        for (Empleado e : empleados) {
            if (e instanceof Comercial) {
                sumaVentas += ((Comercial) e).getVentasMensuales();
                contadorComerciales++;
            }
        }
        // Si no hay comerciales, devolvemos 0 para evitar error
        return (contadorComerciales == 0) ? 0 : sumaVentas / contadorComerciales;
    }

// 2. Media de SUELDO TOTAL (De toda la plantilla)
    public double mediaSueldoTotal() {
        if (empleados.isEmpty()) {
            return 0;
        }
        return calcularCosteTotalNominas() / empleados.size();
    }

// 3. Media de sueldo SOLO de los COMERCIALES
    public double mediaSueldoComerciales() {
        double suma = 0;
        int cuantos = 0;
        for (Empleado e : empleados) {
            if (e instanceof Comercial) {
                suma += e.calcularSueldoFinal();
                cuantos++;
            }
        }
        return (cuantos == 0) ? 0 : suma / cuantos;
    }

// 4. EL REBUSCADO: ¿Qué porcentaje de la plantilla son Técnicos?
    public double porcentajeTecnicos() {
        if (empleados.isEmpty()) {
            return 0;
        }
        int contadorTecnicos = 0;
        for (Empleado e : empleados) {
            if (e instanceof Tecnico) {
                contadorTecnicos++;
            }
        }
        return (double) contadorTecnicos / empleados.size() * 100;
    }
}
