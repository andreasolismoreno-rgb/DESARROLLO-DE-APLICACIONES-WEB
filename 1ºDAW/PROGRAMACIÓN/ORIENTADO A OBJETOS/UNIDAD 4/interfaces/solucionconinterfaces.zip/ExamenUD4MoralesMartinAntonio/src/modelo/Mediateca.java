package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Mediateca implements InterfazMediateca {

    private List<Grabacion> grabaciones;

    public Mediateca() {
        grabaciones = new ArrayList<>();
    }

    @Override
    public void addGrabacion(Grabacion g) {
        if (g == null) {
            throw new IllegalArgumentException("La grabacion no puede ser nula");
        }
        grabaciones.add(g);
    }

    @Override
    public Boolean removeGrabacion(Grabacion g) {
        return grabaciones.remove(g);
    }

    @Override
    public Integer numGrabaciones() {
        return grabaciones.size();
    }

    @Override
    public List<Grabacion> getGrabaciones() {
        return new ArrayList<>(grabaciones);
    }

    
    /*Metodos sin instanceof*/
    @Override
    public List<Grabacion> getGrabacionesPorNombre(String texto) {
        List<Grabacion> res = new ArrayList<>();

        for (Grabacion grabacion : grabaciones) {
            if (grabacion.getNombre().toLowerCase().contains(texto.toLowerCase())) {
                res.add(grabacion);
            }
        }
        return res;
    }

    @Override
    public Integer duracionTotalMinutos() {
        Integer res = 0;
        for (Grabacion g : grabaciones) {
            res += g.getDuracionMinutos();
        }
        return res;
    }

    @Override
    public Grabacion grabacionMasLarga() {
        Grabacion res = null;

        for (Grabacion grabacion : grabaciones) {
            if (res == null || res.getDuracionMinutos() < grabacion.getDuracionMinutos()) {
                res = grabacion;
            }
        }

        return res;
    }

    @Override
    public List<Grabacion> getGrabacionesEntreFechas(LocalDate desde, LocalDate hasta) {
        if (desde.isAfter(hasta)) {
            throw new IllegalArgumentException("Desde no puede ser posterior a hasta");
        }
        List<Grabacion> res = new ArrayList<>();

        for (Grabacion grabacion : grabaciones) {
            if (desde.compareTo(grabacion.getFecha()) <= 0 && hasta.compareTo(grabacion.getFecha()) >= 0) {
                res.add(grabacion);
            }
        }
        return res;
    }
    
    /*Instanceof*/
    
    @Override
    public Pelicula peliculaMejorValorada(){
        Pelicula res = null;
        
        for (Grabacion grabacion : grabaciones) {
            if (grabacion instanceof Pelicula) {
                Pelicula peli = (Pelicula) grabacion;
                if (res == null || peli.getValoracion() > res.getValoracion()) {
                    res = peli;
                }
            }
        }
        
        return res;
    }
    
    @Override
    public Double valoracionMediaPeliculas() {
        Double res = 0.0;
        Integer cont = 0;
        for (Grabacion grabacion : grabaciones) {
            if (grabacion instanceof Pelicula) {
                Pelicula peli = (Pelicula) grabacion;
                res += peli.getValoracion();
                cont++;
            }
        }
        if (cont>0) {
            res = res / cont;
        }
        return res;
    }
    
    @Override
    public Cancion cancionConMasEstrellas(){
        Cancion res = null;
        
        for (Grabacion grabacion : grabaciones) {
            if (grabacion instanceof Cancion) {
                Cancion tema = (Cancion) grabacion;
                
                if (res == null || tema.getEstrellas() > res.getEstrellas()) {
                    res = tema;
                }
            }
        }
        return res;
    }
    
    @Override
    public List<Cancion> cancionesConEstrallasMasDe(Integer min){
        List<Cancion> res = new ArrayList<>();
        
        for (Grabacion grabacion : grabaciones) {
            if (grabacion instanceof Cancion) {
                Cancion tema = (Cancion) grabacion;
                
                if (tema.getEstrellas() > min) {
                    res.add(tema);
                }
            }
        }
        return res;
    }

    @Override
    public List<Pelicula> peliculasDeUnDirector(String director){
        List<Pelicula> res = new ArrayList<>();
        for (Grabacion grabacion : grabaciones) {
            if (grabacion instanceof Pelicula) {
                Pelicula peli = (Pelicula) grabacion;
                if (peli.getDirector().toLowerCase().contains(director.toLowerCase())) {
                    res.add(peli);
                }
            }
        }
        return res;
    }
    
    @Override
    public List<Pelicula> peliculasConActor(String actor){
        List<Pelicula> res = new ArrayList<>();
        for (Grabacion grabacion : grabaciones) {
            if (grabacion instanceof Pelicula) {
                Pelicula peli = (Pelicula) grabacion;
                if (peli.getActores().contains(actor)) {
                    res.add(peli);
                }
            }
        }
        return res;
    }
    
    
    @Override
    public String toString() {
        String res = "";

        for (Grabacion grabacion : grabaciones) {
            res += grabacion.toString() + '\n';
        }

        return res;
    }
}
