/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modelo;

import java.util.List;

/**
 *
 * @author pgarcia
 */
public interface InterfazPelicula extends InterfazGrabacion{

    void addActor(String actor);

    Boolean contieneActor(String texto);

    List<String> getActores();

    String getDirector();

    Metraje getMetraje();

    Double getValoracion();

    Boolean removeActor(String actor);

    void setDirector(String director);

    void setMetraje(Metraje metraje);

    void setValoracion(Double valoracion);
    
}
