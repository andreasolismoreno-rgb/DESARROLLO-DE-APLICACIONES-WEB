/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modelo;

/**
 *
 * @author pgarcia
 */
public interface IntefazCancion extends InterfazGrabacion{

    Integer getEstrellas();

    String getGenero();

    void setEstrellas(Integer estrellas);

    void setGenero(String genero);
    
}
