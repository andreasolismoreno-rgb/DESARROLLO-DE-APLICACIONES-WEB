/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modelo;

import java.time.LocalDate;

/**
 *
 * @author pgarcia
 */
public interface InterfazGrabacion {

    Integer getDuracionMinutos();

    LocalDate getFecha();

    String getNombre();

    void setDuracionMinutos(Integer duracionMinutos);

    void setFecha(LocalDate fecha);

    void setNombre(String nombre);
    
}
