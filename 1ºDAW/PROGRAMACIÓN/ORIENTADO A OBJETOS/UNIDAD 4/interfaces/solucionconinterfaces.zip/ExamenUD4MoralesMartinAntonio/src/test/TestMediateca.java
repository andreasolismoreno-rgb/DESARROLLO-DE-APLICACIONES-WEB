package test;

import java.time.LocalDate;
import modelo.*;

public class TestMediateca {

    public static void main(String[] args) {

        Pelicula p1 = new Pelicula(Metraje.MEDIO, "Paco Leon", 9.0, "AIDA", LocalDate.of(2026, 1, 31), 90);
        Pelicula p2 = new Pelicula(Metraje.MEDIO, "Makoto Shinkai", 9.0, "Your Name", LocalDate.of(2020, 2, 25), 95);

        p1.addActor("Paco Leon");

        Cancion c1 = new Cancion("Pop-Rock", 5, "Mi nena", LocalDate.of(2025, 05, 20), 3);
        Cancion c2 = new Cancion("Pop", 4, "Mi suerte", LocalDate.of(2021, 06, 15), 3);

        Mediateca m1 = new Mediateca();
        m1.addGrabacion(c2);
        m1.addGrabacion(c1);
        m1.addGrabacion(p1);
        m1.addGrabacion(p2);

        /*Todas las grabaciones: */
        System.out.println("----Grabaciones de Mediateca: ----");
        System.out.println("Hay: " + m1.numGrabaciones() + " grabaciones: " + '\n');
        System.out.println(m1);

        /*Busqueda por nombre: */
        System.out.println('\n' + "----Busqueda por nombre: ----");
        System.out.println(m1.getGrabacionesPorNombre("your name"));

        /*Duración total y grabación más larga*/
        System.out.println('\n' + "----Duracion total: ----");
        System.out.println(m1.duracionTotalMinutos());

        System.out.println('\n' + "----Grabacion mas larga: ----");
        System.out.println(m1.grabacionMasLarga());

        /*Mejor película y media de valoración*/
        System.out.println('\n' + "----Mejor pelicula: ----");
        System.out.println(m1.peliculaMejorValorada());
        System.out.println('\n' + "----Media de valoraciones: ----");
        System.out.println(m1.valoracionMediaPeliculas());

        /*Cancion top y canciones con estrellas > a 4*/
        System.out.println('\n' + "----Cancion top: ----");
        System.out.println(m1.cancionConMasEstrellas());
        System.out.println('\n' + "----Cancion con estrellas mayor a 4----");
        System.out.println(m1.cancionesConEstrallasMasDe(4));

        System.out.println('\n' + "---Prueba Fecha: ----");
        System.out.println(m1.getGrabacionesEntreFechas(LocalDate.of(2024, 01, 02), LocalDate.of(2026, 02, 06)));

        System.out.println('\n' + "---------Extra: ---------");

        System.out.println("----Pelis de un director: ----");
        System.out.println(m1.peliculasDeUnDirector("Makoto shinkai"));

        System.out.println('\n' + "----Pelis de un actor----");
        System.out.println(m1.peliculasConActor("Paco Leon"));
    }

}
