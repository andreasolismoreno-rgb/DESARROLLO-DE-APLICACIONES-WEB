package modelo;

import java.time.LocalDate;

public class Cancion extends Grabacion implements IntefazCancion {

    private String genero;
    private Integer estrellas;

    public Cancion(String genero, Integer estrellas, String nombre, LocalDate fecha, Integer duracionMinutos) {
        super(nombre, fecha, duracionMinutos);

        if (estrellas == null || estrellas < 1 || estrellas > 5) {
            throw new IllegalArgumentException("Las estrellas no pueden ser nulas, menor a 1 o superior a 5");
        }
        this.genero = genero;
        this.estrellas = estrellas;
    }

    @Override
    public String getGenero() {
        return genero;
    }

    @Override
    public void setGenero(String genero) {
        this.genero = genero;
    }

    @Override
    public Integer getEstrellas() {
        return estrellas;
    }

    @Override
    public void setEstrellas(Integer estrellas) {
        if (estrellas == null || estrellas < 1 || estrellas > 5) {
            throw new IllegalArgumentException("Las estrellas no pueden ser nulas, menor a 1 o superior a 5");
        }
        this.estrellas = estrellas;
    }

    @Override
    public String toString() {
        return super.toString()
                +"Genero: "+genero+'\n'
                +"Estrellas: "+estrellas+'\n'; 
    }

    
    
}
