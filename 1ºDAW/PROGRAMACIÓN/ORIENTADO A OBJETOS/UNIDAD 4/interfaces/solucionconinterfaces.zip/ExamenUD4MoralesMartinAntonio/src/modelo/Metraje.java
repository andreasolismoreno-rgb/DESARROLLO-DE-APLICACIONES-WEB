package modelo;
public enum Metraje {
    CORTO, MEDIO, LARGOMETRAJE
}
