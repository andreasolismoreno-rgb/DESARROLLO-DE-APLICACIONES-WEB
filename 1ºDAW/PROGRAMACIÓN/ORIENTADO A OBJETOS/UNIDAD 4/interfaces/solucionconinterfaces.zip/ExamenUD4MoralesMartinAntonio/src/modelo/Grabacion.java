package modelo;

import java.time.LocalDate;

public class Grabacion implements InterfazGrabacion {

    private String nombre;
    private LocalDate fecha;
    private Integer duracionMinutos;

    public Grabacion(String nombre, LocalDate fecha, Integer duracionMinutos) {
        if (duracionMinutos == null || duracionMinutos <= 0) {
            throw new IllegalArgumentException("La duracion de minutos no puede ser nula o ser menor o igual a 0");
        }

        this.nombre = nombre;
        this.fecha = fecha;
        this.duracionMinutos = duracionMinutos;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public LocalDate getFecha() {
        return fecha;
    }

    @Override
    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    @Override
    public Integer getDuracionMinutos() {
        return duracionMinutos;
    }

    @Override
    public void setDuracionMinutos(Integer duracionMinutos) {

        if (duracionMinutos == null || duracionMinutos <= 0) {
            throw new IllegalArgumentException("La duracion de minutos no puede ser nula o ser menor o igual a 0");
        }

        this.duracionMinutos = duracionMinutos;
    }

    @Override
    public String toString() {
        return "Nombre: "+nombre+'\n'
                +"Fecha: "+fecha+'\n'
                +"Duracion en minutos: "+duracionMinutos+'\n';
    }

    
    
}
