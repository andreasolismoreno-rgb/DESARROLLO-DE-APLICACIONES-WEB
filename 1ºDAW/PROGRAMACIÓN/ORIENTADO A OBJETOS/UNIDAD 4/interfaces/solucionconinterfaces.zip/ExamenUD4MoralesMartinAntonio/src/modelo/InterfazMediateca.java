/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modelo;

import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author pgarcia
 */
public interface InterfazMediateca {

    void addGrabacion(Grabacion g);

    Cancion cancionConMasEstrellas();

    List<Cancion> cancionesConEstrallasMasDe(Integer min);

    Integer duracionTotalMinutos();

    List<Grabacion> getGrabaciones();

    List<Grabacion> getGrabacionesEntreFechas(LocalDate desde, LocalDate hasta);

    /*Metodos sin instanceof*/
    List<Grabacion> getGrabacionesPorNombre(String texto);

    Grabacion grabacionMasLarga();

    Integer numGrabaciones();

    /*Instanceof*/
    Pelicula peliculaMejorValorada();

    List<Pelicula> peliculasConActor(String actor);

    List<Pelicula> peliculasDeUnDirector(String director);

    Boolean removeGrabacion(Grabacion g);

    Double valoracionMediaPeliculas();
    
}
