package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Pelicula extends Grabacion implements InterfazPelicula {

    private Metraje metraje;
    private String director;
    private List<String> actores;
    private Double valoracion;

    
    public Pelicula(Metraje metraje, String director, Double valoracion, String nombre, LocalDate fecha, Integer duracionMinutos) {
        super(nombre, fecha, duracionMinutos);

        if (valoracion < 0 || valoracion > 10 || valoracion == null) {
            throw new IllegalArgumentException("La valoracion no puede ser nula, debe ser positiva y menor o igual a 10");
        }
        this.metraje = metraje;
        this.director = director;
        this.actores = new ArrayList<>();
        this.valoracion = valoracion;
    }

    @Override
    public Metraje getMetraje() {
        return metraje;
    }

    @Override
    public void setMetraje(Metraje metraje) {
        this.metraje = metraje;
    }

    @Override
    public String getDirector() {
        return director;
    }

    @Override
    public void setDirector(String director) {
        this.director = director;
    }

    @Override
    public List<String> getActores() {
        return new ArrayList<>(actores);
    }

    @Override
    public Double getValoracion() {
        return valoracion;
    }

    @Override
    public void setValoracion(Double valoracion) {
        if (valoracion < 0 || valoracion > 10 || valoracion == null) {
            throw new IllegalArgumentException("La valoracion no puede ser nula, debe ser positiva y menor o igual a 10");
        }
        this.valoracion = valoracion;
    }

    @Override
    public void addActor(String actor) {
        if (actor == null || actor.isBlank()) {
            throw new IllegalArgumentException("El actor no puede ser nulo ni estar vacio");
        }
        actores.add(actor);
    }

    @Override
    public Boolean removeActor(String actor) {
        return actores.remove(actor);
    }

    @Override
    public Boolean contieneActor(String texto) {
        return actores.contains(texto);
    }

    @Override
    public String toString() {
        return super.toString()
                +"Metraje: "+metraje+'\n'
                +"Director: "+director+'\n'
                +"Actores: "+actores+'\n'
                +"Valoracion: "+valoracion+'\n';
    }
    
    

}
