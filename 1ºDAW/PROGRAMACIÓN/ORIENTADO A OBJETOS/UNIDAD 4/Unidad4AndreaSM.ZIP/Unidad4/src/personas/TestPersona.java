package personas;

import java.time.LocalDate;

public class TestPersona {
    public static void main (String [] args){
        Persona p1 = new Persona ("Pepe", "Gallardo", LocalDate.of(2004, 1, 23), "29656052J", 80.0);
        System.out.println(p1);
        
        
        System.out.println(p1.getEdad());
        System.out.println(p1.getNombre());

    }
}
