
package test;

import modelo.*;

public class BibliotecaTest {
    public static void main(String[] args) {
        Biblioteca b = new Biblioteca("Central");

        b.addLibro(new Libro("1","Libro A","Autor1",1970,10.5));
        b.addLibro(new Libro("2","Libro B","Autor2",1990,12.0));
        b.addLibro(new Libro("3","Libro C","Autor1",2000,8.0));
        b.addLibro(new Libro("4","Libro D","Autor3",1985,15.0));
        b.addLibro(new Libro("5","Libro E","Autor4",2010,20.0));

        System.out.println(b);
        System.out.println("Libro más caro: " + b.getLibroMasCaro());
        System.out.println("Total reposición: " + b.getValorReposicionTotal());
        System.out.println("Precio medio: " + b.getPrecioMedioReposicion());
    }
}
