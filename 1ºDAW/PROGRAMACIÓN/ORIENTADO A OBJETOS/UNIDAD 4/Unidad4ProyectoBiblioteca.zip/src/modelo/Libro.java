
package modelo;

public class Libro {
    private String isbn;
    private String titulo;
    private String autor;
    private Integer anioPublicacion;
    private Double precioReposicion;

    public Libro(String isbn, String titulo, String autor, Integer anioPublicacion, Double precioReposicion) {
        if (isbn == null || isbn.trim().isEmpty())
            throw new IllegalArgumentException("ISBN inválido");
        if (titulo == null || titulo.trim().isEmpty())
            throw new IllegalArgumentException("Título inválido");
        if (autor == null || autor.trim().isEmpty())
            throw new IllegalArgumentException("Autor inválido");
        if (anioPublicacion < 1450 || anioPublicacion > 2100)
            throw new IllegalArgumentException("Año inválido");
        if (precioReposicion < 0)
            throw new IllegalArgumentException("Precio negativo");

        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
        this.precioReposicion = precioReposicion;
    }

    public String getIsbn() { return isbn; }
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public Integer getAnioPublicacion() { return anioPublicacion; }
    public Double getPrecioReposicion() { return precioReposicion; }

    public boolean isClasico() {
        return anioPublicacion < 1980;
    }

    public String getFichaCorta() {
        return titulo + " — " + autor;
    }

    @Override
    public String toString() {
        return isbn + " | " + titulo + " | " + autor + " | " + anioPublicacion +
               " | " + precioReposicion + " € | Clásico: " + isClasico();
    }
}
