
package modelo;

import java.util.*;

public class Biblioteca {
    private String nombre;
    private List<Libro> libros;

    public Biblioteca(String nombre) {
        if (nombre == null || nombre.trim().isEmpty())
            throw new IllegalArgumentException("Nombre inválido");
        this.nombre = nombre;
        this.libros = new ArrayList<>();
    }

    public void addLibro(Libro libro) {
        if (libro == null) throw new IllegalArgumentException("Libro nulo");
        if (existeIsbn(libro.getIsbn()))
            throw new IllegalArgumentException("ISBN duplicado");
        libros.add(libro);
    }

    public boolean removePorIsbn(String isbn) {
        return libros.removeIf(l -> l.getIsbn().equals(isbn));
    }

    public Libro buscarPorIsbn(String isbn) {
        for (Libro l : libros)
            if (l.getIsbn().equals(isbn)) return l;
        return null;
    }

    public boolean existeIsbn(String isbn) {
        return buscarPorIsbn(isbn) != null;
    }

    public List<Libro> buscarPorAutor(String autor) {
        List<Libro> res = new ArrayList<>();
        for (Libro l : libros)
            if (l.getAutor().equalsIgnoreCase(autor)) res.add(l);
        return res;
    }

    public List<Libro> buscarPorTituloContiene(String texto) {
        if (texto == null || texto.trim().isEmpty())
            throw new IllegalArgumentException("Texto inválido");
        List<Libro> res = new ArrayList<>();
        for (Libro l : libros)
            if (l.getTitulo().toLowerCase().contains(texto.toLowerCase()))
                res.add(l);
        return res;
    }

    public List<Libro> listarClasicos() {
        List<Libro> res = new ArrayList<>();
        for (Libro l : libros)
            if (l.isClasico()) res.add(l);
        return res;
    }

    public List<Libro> listarPorAnio(int anio) {
        List<Libro> res = new ArrayList<>();
        for (Libro l : libros)
            if (l.getAnioPublicacion() == anio) res.add(l);
        return res;
    }

    public int getTotalLibros() {
        return libros.size();
    }

    public double getValorReposicionTotal() {
        double suma = 0;
        for (Libro l : libros) suma += l.getPrecioReposicion();
        return suma;
    }

    public Libro getLibroMasCaro() {
        if (libros.isEmpty()) return null;
        Libro max = libros.get(0);
        for (Libro l : libros)
            if (l.getPrecioReposicion() > max.getPrecioReposicion()) max = l;
        return max;
    }

    public double getPrecioMedioReposicion() {
        if (libros.isEmpty()) return 0;
        return getValorReposicionTotal() / libros.size();
    }

    public List<Libro> getLibrosOrdenadosPorTitulo() {
        List<Libro> copia = new ArrayList<>(libros);
        copia.sort(Comparator.comparing(Libro::getTitulo));
        return copia;
    }

    public List<Libro> getLibrosOrdenadosPorAnioDesc() {
        List<Libro> copia = new ArrayList<>(libros);
        copia.sort((a, b) -> b.getAnioPublicacion() - a.getAnioPublicacion());
        return copia;
    }

    public List<Libro> getLibros() {
        return List.copyOf(libros);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Biblioteca: " + nombre + "\n");
        sb.append("Total libros: ").append(getTotalLibros()).append("\n");
        for (Libro l : libros)
            sb.append(l.getFichaCorta()).append("\n");
        return sb.toString();
    }
}
