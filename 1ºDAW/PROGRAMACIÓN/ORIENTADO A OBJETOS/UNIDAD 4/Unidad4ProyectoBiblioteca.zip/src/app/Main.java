
package app;

import modelo.*;

public class Main {
    public static void main(String[] args) {
        Biblioteca b = new Biblioteca("Municipal");

        b.addLibro(new Libro("10","Java Básico","Ana",2001,25));
        b.addLibro(new Libro("11","POO","Luis",1995,30));
        b.addLibro(new Libro("12","Historia","Ana",1975,18));

        System.out.println(b.buscarPorAutor("Ana"));
        System.out.println(b.listarClasicos());
        System.out.println(b.getLibrosOrdenadosPorTitulo());
        System.out.println(b.getLibrosOrdenadosPorAnioDesc());
        System.out.println(b.getValorReposicionTotal());
        System.out.println(b.getPrecioMedioReposicion());
    }
}
