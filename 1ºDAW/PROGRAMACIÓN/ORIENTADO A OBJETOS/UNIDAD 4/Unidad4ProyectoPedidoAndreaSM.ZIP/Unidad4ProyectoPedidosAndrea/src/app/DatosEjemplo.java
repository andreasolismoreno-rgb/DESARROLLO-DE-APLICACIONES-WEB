//package app;
//
//import java.time.LocalDate;
//import modelo.LineaPedido;
//import modelo.Pedido;
//import modelo.Producto;
//
//public class DatosEjemplo {
//    public static Pedido crearPedidoDemo() {
//
//        Producto p1 = new Producto("P1", "Teclado", 20.0);
//        Producto p2 = new Producto("P2", "Ratón", 10.0);
//        Producto p3 = new Producto("P3", "Pantalla", 120.0);
//        Producto p4 = new Producto("P4", "USB", 5.0);
//        Producto p5 = new Producto("P5", "Alfombrilla", 8.0);
//
//        Pedido pedido = new Pedido(LocalDate.now());
//
//        pedido.addLinea(new LineaPedido(p1, 1));
//        pedido.addLinea(new LineaPedido(p2, 2));
//        pedido.addLinea(new LineaPedido(p3, 1));
//        pedido.addLinea(new LineaPedido(p4, 3));
//        pedido.addLinea(new LineaPedido(p5, 2));
//
//        return pedido;
//    }
//}
