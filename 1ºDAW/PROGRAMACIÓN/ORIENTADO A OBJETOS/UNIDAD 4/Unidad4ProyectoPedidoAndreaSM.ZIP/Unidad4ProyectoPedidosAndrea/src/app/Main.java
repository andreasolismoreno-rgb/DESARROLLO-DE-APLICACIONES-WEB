package app;

import java.time.LocalDate;
import modelo.LineaPedido;
import modelo.Pedido;
import modelo.Producto;

public class Main {
   public static void main(String[] args) {

        Producto p1 = new Producto("Teclado", 19.99);
        Producto p2 = new Producto("Ratón", 9.50);

        LineaPedido l1 = new LineaPedido(p1, 2);
        LineaPedido l2 = new LineaPedido(p2, 3);

        Pedido pedido = new Pedido(LocalDate.now()); 

        pedido.addLinea(l1);
        pedido.addLinea(l2);

        System.out.println(pedido);
        
        
//        Pedido pedido = DatosEjemplo.crearPedidoDemo();
//
//        System.out.println("TOTAL: " + pedido.getTotal() + " €");
//        System.out.println("TOTAL CON DESCUENTO: " + pedido.getTotalConDescuento() + " €");
//        System.out.println("NÚMERO DE ARTÍCULOS: " + pedido.getNumeroArticulos());
    }
}
