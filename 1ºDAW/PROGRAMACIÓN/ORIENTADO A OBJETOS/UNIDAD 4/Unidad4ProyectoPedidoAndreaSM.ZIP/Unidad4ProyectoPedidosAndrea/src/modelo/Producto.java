package modelo;

public class Producto {
    
    //1)Atrbutos(estado)
    private String codigo;
    private String nombre;
    private Double precio;
    
    
    public Producto (String codigo, String nombre, Double precio){
        
        if(precio < 0.0) {
            throw new IllegalArgumentException("El precio no debe ser negativo");
        }
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        
        if(precio == null) {
            throw new IllegalArgumentException("El precio no debe ser nulo");
        }
        


    }
    
    public Producto (String nombre, Double precio){
        
        this ("P = " + nombre.toUpperCase().charAt(0)+ " ...", nombre, precio);
        
    }
    //Normalmente losGetter se ponen siempre, pero los Setter no pq son modificables.
    //Un usuario final no debe modificar algunas cosas.

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(Double precio) {
        if(precio < 0.0) {
            throw new IllegalArgumentException("El precio no debe ser negativo");
        }
        this.precio = precio;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Double getPrecio() {
        return precio;
    }
}

