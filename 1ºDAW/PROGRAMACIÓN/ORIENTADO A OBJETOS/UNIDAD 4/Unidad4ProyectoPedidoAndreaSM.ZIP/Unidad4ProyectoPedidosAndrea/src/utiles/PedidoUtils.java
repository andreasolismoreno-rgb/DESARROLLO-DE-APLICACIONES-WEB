package utiles;

import modelo.Pedido;

public class PedidoUtils {
//    8. Crea PedidoUtils con un método estático que reciba un Pedido y devuelva el
//IVA (21%) del total.
//Criterios: RA2-e, RA2-f, RA4-d.
    
    public static Double calculaIva( Pedido p){
        return p.getTotal()*0.21;
    }
    
}
