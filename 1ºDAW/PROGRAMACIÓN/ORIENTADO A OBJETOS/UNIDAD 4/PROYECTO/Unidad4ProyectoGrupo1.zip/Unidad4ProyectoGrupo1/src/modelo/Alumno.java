package modelo;

import java.time.LocalDate;

public class Alumno extends Persona {
    private String curso;
    private Double notaMedia;
    private Boolean repetidor;

    public Alumno(String curso, Double notaMedia, Boolean repetidor, String dni, String nombre, LocalDate fechaNacimiento) {
        super(dni, nombre, fechaNacimiento);
       
        if (curso==null || curso.equals("")) {
            throw new IllegalArgumentException("El curso no puede estar vecio");
        }
        
        if (notaMedia<0 || notaMedia>10) {
            throw new IllegalArgumentException("La nota media debe estar entre 0 y 10");
        }
        this.curso = curso;
        this.notaMedia = notaMedia;
        this.repetidor = repetidor;
    }

    //----------------------------Getter--------------------------------
    
    public String getCurso() {
        return curso;
    }

    public Double getNotaMedia() {
        return notaMedia;
    }

    public Boolean getRepetidor() {
        return repetidor;
    }

    //---------------------------Setter----------------------------------
    
    public void setCurso(String curso) {
        if (curso==null || curso.equals("")) {
            throw new IllegalArgumentException("El curso no puede estar vecio");
        }
        this.curso = curso;
    }
    
    public void setNotaMedia(Double notaMedia) {
        if (notaMedia<0 || notaMedia>10) {
            throw new IllegalArgumentException("La nota media debe estar entre 0 y 10");
        }
        this.notaMedia = notaMedia;
    }

    public void setRepetidor(Boolean repetidor) {
        this.repetidor = repetidor;
    }
    
    public Boolean esAprobado (){
        return notaMedia>=5;
    }

    //--------------------------ToString----------------------------------

    @Override
    public String toString() {
        return super.toString()+ "Alumno{" + "curso=" + curso + ", notaMedia=" + notaMedia + ", repetidor=" + repetidor + '}';
    }
}
