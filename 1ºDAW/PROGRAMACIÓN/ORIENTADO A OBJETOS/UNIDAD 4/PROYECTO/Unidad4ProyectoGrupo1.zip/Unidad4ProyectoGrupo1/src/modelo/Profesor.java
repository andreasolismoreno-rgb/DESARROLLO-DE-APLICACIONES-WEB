package modelo;

import java.time.LocalDate;

public class Profesor extends Persona {

    //Atributos propios. Siempre privados.
    private String especialidad; // (ej: Programación, Sistemas, FOL…)
    private Double salario;
    private Boolean tutor;

    //Constructor. 

    public Profesor(String especialidad, Double salario, Boolean tutor, String dni, String nombre, LocalDate fechaNacimiento) {
        super(dni, nombre, fechaNacimiento);
        if (especialidad == null || especialidad.trim().equals("")) {
            throw new IllegalArgumentException("Especialidad inválida");
        }
        if (salario <= 0) {
            throw new IllegalArgumentException("Salario inválido");
        }
        this.especialidad = especialidad;
        this.salario = salario;
        this.tutor = tutor;
    }
    

    //Getters
    public String getEspecialidad() {
        return especialidad;
    }

    public Double getSalario() {
        return salario;
    }

    public Boolean getTutor() {
        return tutor;
    }

    //Setters
    public void setEspecialidad(String especialidad) {
        if (especialidad == null || especialidad.trim().equals("")) {
            throw new IllegalArgumentException("Especialidad inválida");
        }
        this.especialidad = especialidad;
    }

    public void setSalario(Double salario) {
        if (salario <= 0) {
            throw new IllegalArgumentException("Salario inválido");
        }
        this.salario = salario;
    }

    public void setTutor(Boolean tutor) {
        this.tutor = tutor;
    }

    //Propiedades derivadas (NO atributos)
    public boolean isSenior() {
        return salario >= 2500;
    }

    //toString
    @Override
    public String toString() {
        return super.toString()
                + ", Especialidad: " + especialidad
                + ", Salario: " + salario
                + ", Tutor: " + tutor;
    }

}
