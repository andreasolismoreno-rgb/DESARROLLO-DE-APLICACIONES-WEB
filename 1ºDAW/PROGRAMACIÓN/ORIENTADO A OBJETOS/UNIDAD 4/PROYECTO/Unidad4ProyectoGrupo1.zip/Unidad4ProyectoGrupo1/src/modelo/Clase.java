package modelo;

import java.util.ArrayList;
import java.util.List;

public class Clase {

    private String codigo;
    private Profesor profesor;
    private List<Alumno> alumnos;
    //--------------------------constructor----------------------------------

    public Clase(String codigo, Profesor profesor) {
        if (codigo == null || codigo.equals("")) {
            throw new IllegalArgumentException("codigo no puede ser null ni vacio");
        }
        if (profesor == null) {
            throw new IllegalArgumentException("profesor no puede ser null ni vacio");
        }
        this.codigo = codigo;
        this.profesor = profesor;
        this.alumnos = new ArrayList<>();
    }
    //--------------------------getter----------------------------------

    public String getCodigo() {
        return codigo;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public List<Alumno> getAlumnos() {
        return alumnos;
    }
     //--------------------------setter----------------------------------

    public void setCodigo(String codigo) {
        if (codigo == null || codigo.equals("")) {
            throw new IllegalArgumentException("codigo no puede ser null ni vacio");
        }
        this.codigo = codigo;
    }

    public void setProfesor(Profesor profesor) {
        if (profesor == null || profesor.equals("")) {
            throw new IllegalArgumentException("profesor no puede ser null ni vacio");
        }
        this.profesor = profesor;
    }

    public void setAlumnos(List<Alumno> alumnos) {
        this.alumnos = alumnos;
    }

    //--------------------------Gestión----------------------------------

    public void addAlumno(Alumno a) {
        if (a == null) {
            throw new IllegalArgumentException("El alumno no puede ser nulo");
        }
        alumnos.add(a);
    }
    
    public boolean removeAlumnoPorDni(String dni){
        boolean chivato=false;
        for (Alumno alumno : alumnos) {
            if (alumno.getDni().equals(dni)) {
                alumnos.remove(alumno);
                chivato=true;
            }
        }
        return chivato;
    }
        //--------------------------derivadas----------------------------------

    public int getNumeroAlumnos(){
        return alumnos.size();
    }
    
    public Double getNotaMediaClase(){
        Double nota=0.0;
        for (Alumno alumno : alumnos) {
            nota+=alumno.getNotaMedia();
        }
        return nota/alumnos.size();
    }
    
        //--------------------------toString----------------------------------

    @Override
    public String toString() {
        String res = "";
        res+=codigo+"\n";
        res+=profesor+"\n";
        for (Alumno alumno : alumnos) {
            res+= alumno.toString()+"\n";
        }
        res+=getNumeroAlumnos()+"\n";
        res+=getNotaMediaClase()+"\n";
        return res;
    }

//    public Double notaMediaDe (List<Alumno> alumno) {
//        Double media = 0.0;
//        for (Alumno e : alumno) {
//            media+=e.getNotaMedia();
//        }
//        return media/alumno.size();
//    }
    
    public Integer numeroRepetidores(){
    Integer numero=0;
    
        for (Alumno alumno : alumnos) {
            if (alumno.getRepetidor()) {
                numero++;
            }
        }
    
    return numero;
    }

}
