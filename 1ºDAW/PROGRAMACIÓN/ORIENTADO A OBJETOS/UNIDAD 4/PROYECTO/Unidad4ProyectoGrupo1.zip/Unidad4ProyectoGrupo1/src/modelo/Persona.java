package modelo;

import java.time.LocalDate;
import java.time.Period;

public class Persona {

    private String dni;
    private String nombre;
    private LocalDate fechaNacimiento;

    public Persona(String dni, String nombre, LocalDate fechaNacimiento) {
        if (dni == null || dni.equals("")) {
            throw new IllegalArgumentException("dni no puede ser null ni vacia");
        }
        if (nombre == null || nombre.equals("")) {
            throw new IllegalArgumentException("nombre no puede ser null ni vacia");
        }
        if (fechaNacimiento == null || fechaNacimiento.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("La fecha no puede ser nula ni futura");
        }

        this.dni = dni;
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
    }
//-------------------------------Getter--------------------------------

    public String getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

//-------------------------------SETTER--------------------------------
    public void setDni(String dni) {
        if (dni == null || dni.equals("")) {
            throw new IllegalArgumentException("dni no puede ser null ni vacia");
        }
        this.dni = dni;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.equals("")) {
            throw new IllegalArgumentException("nombre no puede ser null ni vacia");
        }
        this.nombre = nombre;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

//-------------------------------DERIVADAS--------------------------------
    public int getEdad() {
        return Period.between(fechaNacimiento, LocalDate.now()).getYears();
    }

    public String getFicha() {
        return dni + " - " + nombre;
    }
//-------------------------------DERIVADAS--------------------------------

    @Override
    public String toString() {
        return "Persona{" + "dni=" + dni + ", nombre=" + nombre + ", fechaNacimiento=" + fechaNacimiento + '}';
    }

}
