package test;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import modelo.Alumno;
import modelo.Clase;
import modelo.Instituto;
import modelo.Profesor;
import util.InstitutoUtils;

public class InstitutoTest {
    public static void main(String[] args) {
        Alumno a1 = new Alumno("1ºDAW", 6.7, false, "89564522K", "Paco", LocalDate.of(2000,01, 14));
        Alumno a2 = new Alumno("1ºDAW", 1.5, true, "59148533K", "Alberto", LocalDate.of(2004,02, 18));
        Alumno a3 = new Alumno("1ºDAW", 7.0, false, "87895400N", "Juanca", LocalDate.of(2003,02, 25));
        Alumno a4 = new Alumno("1ºDAW", 10.0, true, "33997888M", "Marina", LocalDate.of(2002,03, 22));
        Alumno a5 = new Alumno("1ºDAW", 5.5, false, "19623788L", "Paula", LocalDate.of(2000,05, 16));
        Alumno a6 = new Alumno("1ºDAW", 8.0, false, "55662233P", "juan", LocalDate.of(2004,05, 11));
        
        
        Profesor p1 = new Profesor("Programacion", 1255.0, true, "77581349J", "Pepelu", LocalDate.of(1977,06, 11));
        Profesor p2 = new Profesor("Programacion", 1305.0, true, "77585972Ñ", "Maria", LocalDate.of(1980,03, 10));
        Profesor p3 = new Profesor("Programacion", 1555.0, true, "77581321P", "Jose", LocalDate.of(1985,04, 15));

       
        Clase c1 = new Clase("111A", p1);
        c1.addAlumno(a1);
        c1.addAlumno(a2);
        
        
        Clase c2 = new Clase("222A", p2);
        c2.addAlumno(a3);
        c2.addAlumno(a4);
        
        Clase c3 = new Clase("333A", p3);
        c3.addAlumno(a5);
        c3.addAlumno(a6);
        
        System.out.println(a1);
        System.out.println(p1);
        System.out.println("");
        System.out.println(c1);
        
        Instituto i1 = new Instituto("Velazquez", LocalDate.of(1885, 10, 5));
        i1.addClase(c1);
        i1.addClase(c2);
        i1.addClase(c3);
        
        System.out.println("");
        System.out.println("");
        System.out.println(i1);
        
        
        System.out.println(i1.toString());
        System.out.println(c1.getNotaMediaClase());
        
        c1.removeAlumnoPorDni(a1.getDni());
        i1.removeClasePorCodigo(c1.getCodigo());
        System.out.println(i1);
        
        System.out.println(InstitutoUtils.contarAlumnosRepetidores(i1));
        
        
        System.out.println("------------------------Ejercicio extra 1------------------");
        System.out.println("");
        System.out.println("Sueldo medio de profesor-->"+InstitutoUtils.redondear2(i1.getSueldoMedioProfeDe(i1.getClases())));
        System.out.println("");
        System.out.println("------------------------Ejercicio extra 2------------------");
        System.out.println("");
        System.out.println("Nota media instituto--> "+i1.getMediaNotaMediaDe());
        System.out.println("");
        System.out.println("------------------------Ejercicio extra 3-------------------");
        System.out.println("");
        System.out.println("¿Cuantos repetidores hay en el instituto? --> "+i1.getRepetidoresInstituto());
        System.out.println("");
        System.out.println("------------------------Ejercicio extra 4--------------------");
        System.out.println("");
        System.out.println("Profesor con más alumnos repetidores en clase --> "+i1.getProfeConMasRep());
    }
}
