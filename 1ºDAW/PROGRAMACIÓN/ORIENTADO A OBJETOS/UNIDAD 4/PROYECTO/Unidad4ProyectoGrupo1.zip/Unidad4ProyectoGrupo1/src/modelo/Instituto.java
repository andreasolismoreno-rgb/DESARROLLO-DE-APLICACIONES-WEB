package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Instituto {

    //Atributos 
    private String nombre;
    private LocalDate fechaFundacion;
    private List<Clase> clases; ////Relación de COMPOSICIÓN

    public Instituto(String nombre, LocalDate fechaFundacion) {
        //Constructor Recibe nombre y fechaFundacion e inicializa la lista clases.

        //Validaciones
        if (nombre == null || nombre.equals("")) {
            throw new IllegalArgumentException("Nombre inválido");
        }
        if (fechaFundacion.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("La fecha no debe ser futura");
        }
        this.nombre = nombre;
        this.fechaFundacion = fechaFundacion;
        this.clases = new ArrayList<>();
    }

    //Getters
    public String getNombre() {
        return nombre;
    }

    public LocalDate getFechaFundacion() {
        return fechaFundacion;
    }

    public List<Clase> getClases() {
        return clases;

    }

    //Setters
    public void setNombre(String nombre) {
        //Validaciones
        this.nombre = nombre;
    }

    public void setFechaFundacion(LocalDate fechaFundacion) {
        //Validaciones
        this.fechaFundacion = fechaFundacion;
    }

    public void setClases(List<Clase> clases) {

        this.clases = clases;
    }

    //Métodos
//    A) Gestión
    public void addClase(Clase c) {
        if (c == null) {
            throw new IllegalArgumentException("La clase no puede ser null");
        }
        clases.add(c);
    }

//    public boolean removeClasePorCodigo(String codigo) {
//        for (int i = 0; i < clases.size(); i++) {
//            if (clases.get(i).getCodigo().equals(codigo)) {
//                clases.remove(i);
//                return true;
//            }
//        }
//        return false;
//    }
    public boolean removeClasePorCodigo(String codigo) {
        for (int i = 0; i < clases.size(); i++) {
            if (clases.get(i).getCodigo().equals(codigo)) {
                clases.remove(i);
                return true;
            }
        }
        return false;
    }

    //B. Derivadas
    public int getNumeroClases() {
        return clases.size();
    }

    public int getTotalAlumnos() {
        int total = 0;
        for (Clase c : clases) {
            total += c.getNumeroAlumnos();
        }
        return total;
    }

    // toString
    @Override

    public String toString() {
        String texto = "Instituto: " + nombre + "\n";
        texto += "Fecha fundación: " + fechaFundacion + "\n";
        for (Clase c : clases) {
            texto += c + "\n";
        }
        texto += "Número de clases: " + getNumeroClases() + "\n";
        texto += "Total alumnos: " + getTotalAlumnos() + "\n";
        return texto;
    }
    
    public Double getSueldoMedioProfeDe (List<Clase> clase) {
        Double sueldo = 0.0;
        for (Clase e : clase) {
            sueldo+=e.getProfesor().getSalario();
        }
        return sueldo/clase.size();
    }
    
    public Double getMediaNotaMediaDe (){
        Double media = 0.0;
        for (Clase e : clases) {
            media+=e.getNotaMediaClase();
        }
        
        return media/clases.size();
    }
    
    public Integer getRepetidoresInstituto(){
    Integer numero=0;
        for (Clase clase : clases) {
            numero+=clase.numeroRepetidores();
        }
    return numero;
    }
    
    public Integer getMaxRep(){
    Integer numero=0;
    
        for (Clase clase : clases) {
            if (clase.numeroRepetidores() > numero) {
                numero=clase.numeroRepetidores();
            }
        }
    
        return numero;
    }
    
    public String getProfeConMasRep(){
    String nombre="";
    
        for (Clase clase : clases) {
            if (getMaxRep()==clase.numeroRepetidores()) {
                nombre+=clase.getProfesor().getNombre();
            }
        }
    
    return nombre;
    }
    
    
    
}
