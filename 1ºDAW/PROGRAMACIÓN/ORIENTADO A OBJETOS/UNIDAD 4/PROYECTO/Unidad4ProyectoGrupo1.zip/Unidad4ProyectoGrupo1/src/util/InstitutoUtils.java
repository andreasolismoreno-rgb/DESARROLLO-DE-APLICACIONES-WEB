package util;

import modelo.Alumno;
import modelo.Clase;
import modelo.Instituto;

public class InstitutoUtils {

    // Normalizar texto
    public static String normalizarTexto(String s) {
        if (s == null) {
            throw new IllegalArgumentException("El texto no puede estar vacio");
        }
        return s.trim().replaceAll("\\s+", " ");
    }

    // Redondear a 2 decimales
    public static double redondear2(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }

    // Contar alumnos repetidores del curso
    public static int contarAlumnosRepetidores(Instituto instituto) {
        if (instituto == null) {
            throw new IllegalArgumentException("El instituto no puede estar vacio");
        }

        int contador = 0;

        for (Clase c : instituto.getClases()) {
            for (Alumno alumno : c.getAlumnos()) {
                if (alumno.getRepetidor()) {
                    contador++;
                }
            }
        }
        return contador;
    }
}
