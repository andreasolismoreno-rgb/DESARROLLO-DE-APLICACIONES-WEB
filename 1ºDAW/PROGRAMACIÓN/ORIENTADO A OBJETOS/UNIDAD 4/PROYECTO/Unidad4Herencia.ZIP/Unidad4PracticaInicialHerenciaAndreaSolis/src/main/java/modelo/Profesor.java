package modelo;

public class Profesor extends Persona {

    // Atributos 
    private String departamento;
    private Integer horasSemanales;

    public Profesor(String dni, String nombre, String departamento, Integer horasSemanales) {
        super(dni, nombre);
        this.departamento = departamento;
        this.horasSemanales = horasSemanales;
    }

    public String presentarse() {
        // Aprovechamos la presentación básica y añadimos lo específico
        return super.presentarse() + ", imparto clases en el departamento de "
                + departamento + " (" + horasSemanales + "h/semana)";
    }

    @Override
    public String toString() {
        return "Profesor (DNI=" + getDni() + ", Nombre=" + getNombre()
                + ", Dept=" + departamento + ", Horas=" + horasSemanales + ")";
    }
}
