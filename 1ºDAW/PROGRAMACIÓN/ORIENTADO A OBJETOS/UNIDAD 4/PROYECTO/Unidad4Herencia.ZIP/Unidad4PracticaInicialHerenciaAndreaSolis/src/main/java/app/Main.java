package app;

import modelo.Alumno;
import modelo.Persona;

public class Main {

    public static void main(String[] args) {
        // Instancia de la superclase
        Persona p = new Persona("111A", "Ana");
        
        // Instancia de la subclase
        Alumno a = new Alumno("222B", "Luis", "1DAW");

        // Mostramos resultados por consola
        System.out.println(p.presentarse()); // Usa el método de Persona
        System.out.println(a.presentarse()); // Usa el método sobrescrito de Alumno
    }
}
