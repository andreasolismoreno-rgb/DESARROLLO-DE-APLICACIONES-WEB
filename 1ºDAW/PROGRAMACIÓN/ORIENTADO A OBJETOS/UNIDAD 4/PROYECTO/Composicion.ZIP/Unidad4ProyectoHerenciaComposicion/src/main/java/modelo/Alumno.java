package modelo;

import java.util.ArrayList;
import java.util.List;

public class Alumno extends Persona {

    private String grupo;
    private List<Asignatura> asignaturas; //Relación de COMPOSICIÓN

    public Alumno(String dni, String nombre, String grupo) {
        super(dni, nombre); // llamada al constructor padre
        if (grupo == null || grupo.trim().isEmpty()) {
            throw new IllegalArgumentException("El grupo no puede estar vacío");
        }
        this.grupo = grupo;
        this.asignaturas = new ArrayList<>();
    }

    public String getGrupo() {
        return grupo;
    }

    public List<Asignatura> getAsignaturas() {
        // Devolvemos una copia para proteger la encapsulación
        return new ArrayList<>(this.asignaturas);
    }
    
    
    
    // 3. Gestión de asignaturas

    public void matricular(Asignatura a) {
        // No permite null
        if (a == null) {
            throw new IllegalArgumentException("No se puede matricular una asignatura nula");
        }
        // No permite duplicados por código
        if (estaMatriculado(a.getCodigo())) {
            throw new IllegalArgumentException("El alumno ya está matriculado en: " + a.getCodigo());
        }
        this.asignaturas.add(a);
    }
    
    public boolean desmatricularPorCodigo(String codigo) {
        // Buscamos la asignatura por código y la eliminamos si existe
        for (Asignatura a : asignaturas) {
            if (a.getCodigo().equalsIgnoreCase(codigo)) {
                return asignaturas.remove(a);
            }
        }
        return false;
    }

    public boolean estaMatriculado(String codigo) {
        // Recorremos la lista comparando códigos
        for (Asignatura a : asignaturas) {
            if (a.getCodigo().equalsIgnoreCase(codigo)) {
                return true;
            }
        }
        return false;
    }

    public int numeroAsignaturas() {
        return this.asignaturas.size(); 
    }

    // 4. Consultas útiles

    public int horasTotales() {
        int suma = 0;
        for (Asignatura a : asignaturas) {
            suma += a.getHoras(); // Suma de horas de la composición
        }
        return suma;
    }

    // 5. toString()
    @Override
    public String toString() {
        return "Alumno [" + super.toString() + ", grupo=" + grupo + 
               ", asignaturas matriculadas=" + numeroAsignaturas() + 
               ", carga horaria=" + horasTotales() + "h]";
    }

}
