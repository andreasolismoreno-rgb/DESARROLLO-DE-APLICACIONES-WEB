package modelo;

public class Asignatura {
    // 1. Atributos privados
    private String codigo;
    private String nombre;
    private int horas;

  
    public Asignatura(String codigo, String nombre, int horas) {
        // Validación: codigo y nombre no vacíos
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de la asignatura no puede estar vacío");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la asignatura no puede estar vacío");
        }
        // Validación: horas > 0
        if (horas <= 0) {
            throw new IllegalArgumentException("Las horas de la asignatura deben ser mayores que 0");
        }

        this.codigo = codigo;
        this.nombre = nombre;
        this.horas = horas;
    }

    // 2. Getters
    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public int getHoras() {
        return horas;
    }

    @Override
    public String toString() {
        return "Asignatura [codigo=" + codigo + ", nombre=" + nombre + ", horas=" + horas + "]";
    }
}
