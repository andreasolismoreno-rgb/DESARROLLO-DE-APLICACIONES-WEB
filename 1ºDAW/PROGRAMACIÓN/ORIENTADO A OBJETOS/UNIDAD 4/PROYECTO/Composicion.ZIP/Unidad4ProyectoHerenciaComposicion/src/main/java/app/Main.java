package app;

import modelo.Alumno;
import modelo.Asignatura;
import modelo.Profesor;

public class Main {

    public static void main(String[] args) {
        try {
            // 1. Crear Profesor
            Profesor prof1 = new Profesor("12345678A", "Tonino", "Informática", 18);

            // 2. Crear Alumnos
            Alumno al1 = new Alumno("11111111B", "Marcos ", "1DAW");
            Alumno al2 = new Alumno("22222222C", "Carmen", "2DAW");

            // 3. Crear 4-6 Asignaturas
            Asignatura asig1 = new Asignatura("PROG", "Programación", 8);
            Asignatura asig2 = new Asignatura("BD", "Bases de Datos", 6);
            Asignatura asig3 = new Asignatura("LM", "Lenguajes de Marcas", 4);
            Asignatura asig4 = new Asignatura("FOL", "Formación Orientación Laboral", 3);

            // 4. Matricular asignaturas
            // Alumno 1 se matricula en todo
            al1.matricular(asig1);
            al1.matricular(asig2);
            al1.matricular(asig3);
            al1.matricular(asig4);

            // Alumno 2 solo en dos
            al2.matricular(asig1);
            al2.matricular(asig2);

            // 5. Probar Desmatricular
            System.out.println("PRUEBA DE DESMATRICULACIÓN");
            boolean borrado = al1.desmatricularPorCodigo("LM");
            System.out.println("¿Se ha desmatriculado Lenguaje de Marcas de Marcos?: " + borrado);

            // 6. Imprimir resultados (toString y Horas Totales)
            System.out.println("DATOS DEL PROFESOR:");
            System.out.println(prof1.presentarse());
            System.out.println(prof1.toString());

            System.out.println("DATOS DE LOS ALUMNOS:");

            // Alumno 1
            System.out.println(al1.toString());
            System.out.println("Carga lectiva de " + al1.getNombre() + ": " + al1.horasTotales() + "h");

            System.out.println();

            // Alumno 2
            System.out.println(al2.toString());
            System.out.println("Carga lectiva de " + al2.getNombre() + ": " + al2.horasTotales() + "h");

        } catch (IllegalArgumentException e) {
            System.out.println("Error en los datos: " + e.getMessage());
        }
    }
}
