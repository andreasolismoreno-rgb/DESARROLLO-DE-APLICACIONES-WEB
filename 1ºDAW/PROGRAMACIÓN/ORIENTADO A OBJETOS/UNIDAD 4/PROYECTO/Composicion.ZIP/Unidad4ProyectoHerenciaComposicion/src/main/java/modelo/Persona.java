package modelo;

public class Persona {

    //ATRIBUTOS (2)
    private String dni;
    private String nombre;

    
    //CONSTRUCTOR
    public Persona(String dni, String nombre) {
        // Validaciones: no null ni vacíos
        if (dni == null || dni.trim().isEmpty()) {
            throw new IllegalArgumentException("El DNI no puede ser null ni vacío");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede ser null ni vacío");
        }
        this.dni = dni;
        this.nombre = nombre;
    }

    
    //GETTERS
    public String getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public String presentarse() {
        return "Soy " + nombre + " (DNI: " + dni + ")";
    }

    @Override
    public String toString() {
        return "Persona{" + "dni=" + dni + ", nombre=" + nombre + '}';
    }
    
    
}
