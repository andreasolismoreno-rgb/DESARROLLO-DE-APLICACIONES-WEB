package modelo;

public class Profesor extends Persona {

    // Atributos 
    private String departamento;
    private Integer horasSemanales;

    public Profesor(String dni, String nombre, String departamento, Integer horasSemanales) {
        super(dni, nombre);
        // Validaciones específicas
        if (departamento == null || departamento.trim().isEmpty()) {
            throw new IllegalArgumentException("El departamento no puede estar vacío");
        }
        if (horasSemanales == null || horasSemanales < 0) {
            throw new IllegalArgumentException("Las horas semanales deben ser mayor o igual a 0");
        }
        this.departamento = departamento;
        this.horasSemanales = horasSemanales;
    }

    public String presentarse() {
        // Aprovechamos la presentación básica y añadimos lo específico
        return super.presentarse() + ", imparto clases en el departamento de "
                + departamento + " (" + horasSemanales + "h/semana)";
    }

    @Override
    public String toString() {
        return "Profesor (DNI=" + getDni() + ", Nombre=" + getNombre()
                + ", Dept=" + departamento + ", Horas=" + horasSemanales + ")";
    }
}
