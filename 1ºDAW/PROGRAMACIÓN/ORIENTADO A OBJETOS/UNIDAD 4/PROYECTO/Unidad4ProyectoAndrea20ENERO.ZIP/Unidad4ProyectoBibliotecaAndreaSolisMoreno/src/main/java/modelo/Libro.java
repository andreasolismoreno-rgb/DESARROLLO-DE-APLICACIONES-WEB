package modelo;

public class Libro {

    // 2.1 Atributos (Propiedades básicas que se almacenan) SIEMPRE PRIVADOS
    private String isbn;
    private String titulo;
    private String autor;
    private Integer anioPublicacion;
    private Double precioReposicion;

    // 2.2 Constructor 
    public Libro(String isbn, String titulo, String autor, Integer anioPublicacion, Double precioReposicion) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
        this.precioReposicion = precioReposicion;
    }

    // 2.3 y 2.4 Getters y Setters con validaciones 
    public void setIsbn(String isbn) {
        if (isbn == null || isbn.trim().isEmpty()) {
            throw new IllegalArgumentException("El ISBN no puede estar vacío");
        }
        this.isbn = isbn; // Uso de this para asignar
    }

    public void setAnioPublicacion(Integer anioPublicacion) {
        if (anioPublicacion <= 1450 || anioPublicacion >= 2100) {
            throw new IllegalArgumentException("Año fuera de rango (1450-2100)");
        }
        this.anioPublicacion = anioPublicacion;
    }

    public void setPrecioReposicion(Double precioReposicion) {
        if (precioReposicion < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
        this.precioReposicion = precioReposicion;
    }

    //GETTER
    public String getIsbn() {
        return isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public Integer getAnioPublicacion() {
        return anioPublicacion;
    }

    public Double getPrecioReposicion() {
        return precioReposicion;
    }
    
    // 2.5 Propiedades derivadas. NO SON ATRIBUTOS. Se calculan:
    
    // Se calcula comparando el atributo anioPublicacion
    public boolean isClasico() {
        return this.anioPublicacion < 1980;
    }

    // Se calcula concatenando dos atributos
    public String getFichaCorta() {
        return this.titulo + " -> " + this.autor;
    }
    
    @Override
    public String toString() {
        return "Libro (ISBN: " + isbn + ", Título: " + titulo + ", Autor: " + autor +  ", Año: " + anioPublicacion + 
               ", Precio: " + precioReposicion + "€" + ", ¿Es clásico?: " + (isClasico() ? "sí" : "no") + ")";
    }
    
}
