package util;

import modelo.Biblioteca;
import modelo.Libro;

public class BibliotecaUtils {
    
   // 4) Clase de utilidad BibliotecaUtils (paquete util)
    
    
    //1. static String normalizarTexto(String s)
    // Elimina espacios iniciales/finales y reduce múltiples espacios internos a uno.
    public static String normalizarTexto(String s) {
    if (s == null) return null;
    // .trim() quita espacios de los lados
    // .replaceAll("\\s+", " ") cambia 2 o más espacios por solo uno
    return s.trim().replaceAll("\\s+", " ");
    }
    
    
    //  2. static double redondear2(double valor)
    //Devuelve el número redondeado a 2 decimales.
    
    public static double redondear2(double valor) {
        // Multiplicamos por 100, redondeamos y dividimos por 100.0
        return Math.round(valor * 100.0) / 100.0;
    }
    
    //3. contarLibrosDeAutor(Biblioteca b, String autor)
    //Devuelve cuántos libros del autor hay (ignorando mayúsculas/minúsculas).
    
    
    // Importante: importar modelo.Biblioteca y modelo.Libro
    public static int contarLibrosDeAutor(Biblioteca b, String autor) {
        int cont = 0;

        // 1. Obtenemos la lista de libros de la biblioteca 'b'
        // 2. La recorremos
        for (Libro lib : b.getLibros()) { 
            // 3. Comparamos ignorando mayúsculas
            if (lib.getAutor().equalsIgnoreCase(autor)) {
                cont++;
            }
        }
        return cont;
    }
    
    
    
    
}
