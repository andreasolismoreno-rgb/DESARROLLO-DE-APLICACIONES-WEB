package test;

import modelo.Biblioteca;
import modelo.Libro;

public class BibliotecaTest {
public static void main(String[] args) {
        // 1. Crear biblioteca e insertar 5 libros
        Biblioteca bib = new Biblioteca("Biblioteca");

        try {
            bib.addLibro(new Libro("123", "El Quijote", "Cervantes", 1605, 20.0));
            bib.addLibro(new Libro("456", "Correspondencia", "Albert Camus", 1944, 15.0));
            bib.addLibro(new Libro("789", "Cien años de soledad", "García Márquez", 1967, 25.0));
            bib.addLibro(new Libro("321", "Poesía Completa", "Rafael de León", 1941, 12.0));
            bib.addLibro(new Libro("654", "Emma", "Jane Austen", 1815, 18.0));
            System.out.println(" CINCO libros insertados con éxito!! ");

            // 2. Probar precioReposicion negativo (Debe fallar)
            System.out.println("Probando precio negativo...");
            try {
                bib.addLibro(new Libro("321", "Error", "Autor", 2000, -5.0));
            } catch (IllegalArgumentException e) {
                System.out.println("Capturado error esperado: " + e.getMessage());
            }

            // 3. PProbar que no se permite insertar un libro con ISBN duplicado.
            System.out.println("Probando ISBN duplicado...");
            try {
                bib.addLibro(new Libro("654", "Duplicado", "Alguien", 2020, 10.0));
            } catch (IllegalArgumentException e) {
                System.out.println("Capturado error esperado: " + e.getMessage());
            }

            // 4. Probar removePorIsbn con:
            //un ISBN existente (debe devolver true)
            //un ISBN inexistente (debe devolver false)
            System.out.println("Eliminando ISBN 123 (existente): " + bib.removePorIsbn("222"));
            System.out.println("Eliminando ISBN 789 (inexistente): " + bib.removePorIsbn("999"));

            // 5.5. Mostrar por pantalla:
            //toString() de la biblioteca
            //el libro más caro (si existe)

            //el valor total de reposición y el precio medio
            
            System.out.println("ESTADO DE LA BIBLIOTECA");
            System.out.println(bib.toString());

            System.out.println("ibro más caro: " + bib.getLibroMasCaro());
            
            System.out.println("Valor total de reposición: " + bib.getValorReposicionTotal() + " €");
            System.out.println("Precio medio de reposición: " + bib.getPrecioMedioReposicion() + " €");

        } catch (Exception e) {
            System.out.println("Error inesperado en el test: " + e.getMessage());
        }
    }
}
