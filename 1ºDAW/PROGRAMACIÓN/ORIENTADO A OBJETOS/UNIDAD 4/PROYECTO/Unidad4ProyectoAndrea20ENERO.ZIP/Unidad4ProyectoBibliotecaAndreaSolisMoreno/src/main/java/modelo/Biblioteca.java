
package modelo;
import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.List;
import modelo.Libro;


public class Biblioteca {  //3. Clase 

    //3.1 Atributos
    private String nombre;
    private List<Libro> libros; // Declaramos la lista de objetos Libro

    //3.2 Constructor
    public Biblioteca(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la biblioteca es obligatorio");
        }
        this.nombre = nombre;
        // Inicializamos la lista aquí para que no sea null
        this.libros = new ArrayList<>();
    }

    //3.3 Métodos
    //A) Gestión básica
    //1. void addLibro(Libro libro)
    //○ Añade un libro a la lista.
    //○ No se permite null.
    //○ No se permite duplicar ISBN (si ya existe uno igual, debe lanzar
    //excepción).
    public void addLibro(Libro libro) {
        if (libro == null) {
            throw new IllegalArgumentException("No nulos");
        }
        if (existeIsbn(libro.getIsbn())) {
            throw new IllegalArgumentException("ISBN duplicado");
        }
        libros.add(libro); // Si todo está bien, se guarda en la lista
    }

    //4. boolean existeIsbn(String isbn)
    //○ Devuelve true si existe un libro con ese ISBN.
    public boolean existeIsbn(String isbn) {
        for (Libro lib : libros) {
            if (lib.getIsbn().equals(isbn)) {
                return true; // Si lo encuentra, termina y devuelve true
            }
        }
        return false; // Si termina el bucle y no lo vio, devuelve false
    }

    //2. boolean removePorIsbn(String isbn)
    //○ Elimina el libro cuyo ISBN coincida.
    //○ Devuelve true si se eliminó, false si no existía.
    public boolean removePorIsbn(String isbn) {
        Libro encontrado = buscarPorIsbn(isbn); // Llamas a tu otro método de búsqueda
        if (encontrado != null) {
            return libros.remove(encontrado); //
        }
        return false; //
    }

    //3. Libro buscarPorIsbn(String isbn)
    //○ Devuelve el libro con ese ISBN o null si no existe.
    public Libro buscarPorIsbn(String isbn) {
        for (Libro lib : libros) {
            if (lib.getIsbn().equals(isbn)) {
                return lib; // Si lo encuentra, devuelve el libro y sale del método
            }
        }
        return null; // Si termina el bucle y no lo vio, devuelve null
    }

    //B) Métodos de búsqueda y filtrado
    //5. List<Libro> buscarPorAutor(String autor)
    //Devuelve una lista con todos los libros cuyo autor coincida (ignorando
    //mayúsculas/minúsculas).Si no hay, devuelve lista vacía.
    public List<Libro> buscarPorAutor(String autor) {
    List<Libro> res = new ArrayList<>(); // Lista normal de libros
    for (Libro lib : libros) {
        if (lib.getAutor().equalsIgnoreCase(autor)) {
            res.add(lib); // Sin el (List<Libro>) que tenías antes
        }
    }
    return res;
}
    
    


    //7. List<Libro> listarClasicos()Devuelve todos los libros que cumplan isClasico().
    public List<Libro> listarClasicos() {
        List<Libro> clasicos = new ArrayList<>();
        for (Libro lib : libros) {
            // Llamamos al método de la clase Libro
            if (lib.isClasico()) {
                clasicos.add(lib);
            }
        }
        return clasicos;
    }

    //8. List<Libro> listarPorAnio(int anio)
    //Devuelve libros publicados exactamente ese año.
    public List<Libro> listarPorAnio(int anio) {
        List<Libro> res = new ArrayList<>();
        for (Libro lib : libros) {
            if (lib.getAnioPublicacion() == anio) {
                res.add(lib); // Añadimos a la sublista
            }
        }
        return res;
    }

    //6. List<Libro> buscarPorTituloContiene(String texto)
    //Devuelve libros cuyo título contenga texto (ignorando
    //mayúsculas/minúsculas).
    //Si texto es null o vacío, lanza excepción.
    public List<Libro> buscarPorTituloContiene(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            throw new IllegalArgumentException("El texto de búsqueda no puede estar vacío");
        }
        List<Libro> res = new ArrayList<>();
        for (Libro lib : libros) {
            // Pasamos todo a minúsculas para comparar "igual con igual"
            if (lib.getTitulo().toLowerCase().contains(texto.toLowerCase())) {
                res.add(lib); //
            }
        }
        return res;
    }

    //C) Cálculos (propiedades derivadas: NO almacenar)
    //11. Libro getLibroMasCaro()
    //● Devuelve el libro con mayor precioReposicion.
    //● Si la biblioteca está vacía, devuelve null.
    public Libro getLibroMasCaro() {
        if (libros.isEmpty()) {
            return null;
        }
        Libro masCaro = libros.get(0); // Suponemos que el primero es el más caro
        for (Libro lib : libros) {
            if (lib.getPrecioReposicion() > masCaro.getPrecioReposicion()) {
                masCaro = lib;
            }
        }
        return masCaro;
    }

    //12. double getPrecioMedioReposicion()
    //● Devuelve el precio medio de reposición.
    //● Si no hay libros, devuelve 0.
    public double getPrecioMedioReposicion() {
        if (libros.isEmpty()) {
            return 0;
        }
        return getValorReposicionTotal() / libros.size();
    }

    
    
    //10. double getValorReposicionTotal()
   // ● Suma del precioReposicion de todos los libros.
    //● Propiedad derivada.
    public double getValorReposicionTotal() {
        double total = 0;
        for (Libro lib : libros) {
            // Sumamos el precio de cada libro usando su Getter
            total += lib.getPrecioReposicion();
        }
        return total;
    }
    
    
    // 9. 9. int getTotalLibros()
    //Devuelve el número total de libros (tamaño de la lista).
    //Es una propiedad derivada.
    public int getTotalLibros() {
    // No devolvemos una variable, devolvemos el tamaño actual de la lista
    return this.libros.size(); 
}       

    
    //D) Ordenación
    
    //13. List<Libro> getLibrosOrdenadosPorTitulo()
    //● Devuelve una nueva lista ordenada por título ascendente.
    //● No debe modificar la lista original.
    public List<Libro> getLibrosOrdenadosPorTitulo() {
    List<Libro> copia = new ArrayList<>(libros); // Hacemos copia para no modificar la original
    // Ordenamos la copia por título ascendente
    copia.sort((lib1, lib2) -> lib1.getTitulo().compareToIgnoreCase(lib2.getTitulo())); 
    return copia;
    }
    
    
    
    // 14. List<Libro> getLibrosOrdenadosPorAnioDesc()

        public List<Libro> getLibrosOrdenadosPorAnioDesc() {
        List<Libro> copia = new ArrayList<>(this.libros);

        Collections.sort(copia, new Comparator<Libro>() {
            @Override
            public int compare(Libro l1, Libro l2) {
                // Descendente: el segundo contra el primero
                return l2.getAnioPublicacion().compareTo(l1.getAnioPublicacion());
            }
        });

        return copia;
    }
    
    
    public List<Libro> getLibros() {
    // Devolvemos una copia. 
    return new ArrayList<>(this.libros); //
    }   
    
    @Override
    public String toString() {
        // 1. Empezamos con el nombre y el total (Propiedad derivada getTotalLibros)
        // Usamos \n para saltar de línea [cite: 196]
        String res = "Biblioteca: " + this.nombre + "\n";
        res = res + "Total libros: " + this.libros.size() + "\n";
        res = res + "--------------------------------\n";

        // 2. Recorremos la lista de libros [cite: 197]
        for (Libro lib : libros) {
            // 3. A lo que ya tenemos, le sumamos la ficha corta del libro actual
            // Aquí estamos llamando al método getFichaCorta() de la clase Libro
            res = res + "-> " + lib.getFichaCorta() + "\n";
        }

        return res;
    }
    
}

