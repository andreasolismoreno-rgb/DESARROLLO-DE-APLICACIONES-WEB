package app;

import java.util.List;
import modelo.Biblioteca;
import modelo.Libro;

public class Main {
    public static void main(String[] args) {
        // 1. Crear biblioteca 
        Biblioteca bib = new Biblioteca("Biblioteca Municipal de Sevilla");

        // 2. Añadir libros (datos para que luzcan los filtros) [cite: 210]
        bib.addLibro(new Libro("123", "El Quijote", "Cervantes", 1605, 20.0));
        bib.addLibro(new Libro("456", "Correspondencia", "Albert Camus", 1944, 15.0));
        bib.addLibro(new Libro("789", "Cien años de soledad", "García Márquez", 1967, 25.0));
        bib.addLibro(new Libro("321", "Poesía Completa", "Rafael de León", 1941, 12.0));
        bib.addLibro(new Libro("654", "Emma", "Jane Austen", 1815, 18.0));
        System.out.println(" BIENVENIDO A LA " + bib.toString() + " ===\n");

        // 3. EJECUCIÓN DE 6 MÉTODOS DISTINTOS

        // Método 1: buscarPorAutor
        System.out.println("1. Libros de Cervantes:");
        for (Libro lib : bib.buscarPorAutor("Cervantes")) {
            System.out.println("   -> " + lib.getFichaCorta());
        }

        // Método 2: listarClasicos
        System.out.println("\n2. Libros clásicos (anteriores a 1980):");
        for (Libro lib : bib.listarClasicos()) {
            System.out.println("   -> " + lib.getTitulo() + " (" + lib.getAnioPublicacion() + ")");
        }

        // Método 3: getLibroMasCaro
        Libro caro = bib.getLibroMasCaro();
        System.out.println("\n3. Joya de la corona (más caro): " + (caro != null ? caro.getTitulo() : "N/A"));

        // Método 4: getPrecioMedioReposicion
        System.out.println("\n4. Valor medio de los libros: " + bib.getPrecioMedioReposicion() + " €");

        // Método 5: buscarPorTituloContiene
        System.out.println("\n5. Buscando títulos que contienen 'cien':");
        for (Libro lib : bib.buscarPorTituloContiene("cien")) {
            System.out.println("   -> " + lib.getFichaCorta());
        }

        // Método 6: getLibrosOrdenadosPorAnioDesc
        System.out.println("\n6. Catálogo ordenado por año (más reciente primero):");
        List<Libro> ordenados = bib.getLibrosOrdenadosPorAnioDesc();
        for (Libro lib : ordenados) {
            System.out.println("   -> " + lib.getAnioPublicacion() + ": " + lib.getTitulo());
        }
    }
}
