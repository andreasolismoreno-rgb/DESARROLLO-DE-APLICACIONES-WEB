package fp.feria;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import fp.utiles.Checkers;

public class FactoriaFeria {

//	public static Aeropuerto leerArticulos2(String rutaFichero) {
//		
//		Aeropuerto res = null;	
//		try {
//			Stream<Vuelo> flujo = Files.lines(Paths.get(rutaFichero))
//				                   .skip(1)
//				                   .map(FactoriaVuelos::parsearVuelo);
//			res=new Aeropuerto(flujo);	                 
//			
//		} catch (IOException e) {		
//			System.out.println("No se ha encontrado el fichero " + rutaFichero);
//			e.printStackTrace();
//		}
//		return res;
//	}

	public static Set<CasetaFeria> leerCasetas(String rutaFichero) {
		Set<CasetaFeria> res = null;
		try {
			res = Files.lines(Paths.get(rutaFichero)).map(FactoriaFeria::parseaCaseta)
					.collect(Collectors.toSet());
		} catch (IOException e) {
			System.out.println("No se ha encontrado el fichero " + rutaFichero);
			e.printStackTrace();
		}
		return res;
	}

	// EL 88 DE COSTILLARES;publica;113;150;rebujito - 7.5 , tortilla patatas - 10 ,
	// jamon - 20;flamenco;si;87
	public static CasetaFeria parseaCaseta(String lineaCSV) {

		String [] campos = lineaCSV.split(";");
		Checkers.check("Formato de linea incorrecto", campos.length==8);
		String nombre = campos[0].trim();
		TipoCaseta tipo = TipoCaseta.valueOf(campos[1].trim().toUpperCase());
		Integer modulo = Integer.valueOf(campos[2].trim());
		Integer aforo = Integer.valueOf(campos[3].trim());
		Set<Producto> menu = auxiliarMenu(campos[4].trim());
		String musica = campos[5].trim();
		Boolean accesoAdaptado = false;
		if (campos[6].trim().equals("si")) {
			accesoAdaptado = true;
		}
		Double valoracion = Double.valueOf(campos[7].trim());
		
		return new CasetaFeria(nombre, tipo, modulo, aforo, menu, musica, accesoAdaptado, valoracion);
	}

	//rebujito - 7.5 , tortilla patatas - 10 , jamon - 20
	private static Set<Producto> auxiliarMenu(String cad) {
		Set<Producto> res = new HashSet<Producto>();
		String [] campos = cad.split(",");
		for (String campo : campos) {
			String [] trozos = campo.split("-");
			Checkers.check("Formato de linea incorrecto", trozos.length==2);
			Producto p = new Producto(trozos[0].trim(), Double.valueOf(trozos[1].trim()));
			res.add(p);
		}
		return res;
	}

}
