package fp.feria;

import java.util.Objects;
import java.util.Set;

import fp.utiles.Checkers;

public class CasetaFeria implements Comparable<CasetaFeria>{
//	Nombre, de tipo String, consultable
//	• Tipo, de tipo TipoCaseta, consultable. Puede tomar los valores PUBLICA y PRIVADA.
//	• Módulo, de tipo Integer, consultable.
//	• Aforo, de tipo Integer, consultable.
//	• Menú, de tipo Set<Producto>, consultable.
//	• Música, de tipo String, consultable y modificable.
//	• Acceso adaptado, de tipo Boolean, consultable.
//	• Valoración, de tipo Double, consultable y modificable.


	private String nombre;
	private TipoCaseta tipo;
	private Integer modulo;
	private Integer aforo;
	private Set<Producto> menu;
	private String musica;
	private Boolean accesoAdaptado;
	private Double valoracion;
	
	public CasetaFeria(String nombre, TipoCaseta tipo, Integer modulo, Integer aforo, Set<Producto> menu, String musica,
			Boolean accesoAdaptado, Double valoracion) {
		Checkers.check(" La valoración debe estar comprendida entre 0 y 100", 
				valoracion>=0.0 && valoracion<=100.0);
		Checkers.check("Debe haber al menos un elemento dentro del menú", menu.size()>0);
		this.nombre = nombre;
		this.tipo = tipo;
		this.modulo = modulo;
		this.aforo = aforo;
		this.menu = menu;
		this.musica = musica;
		this.accesoAdaptado = accesoAdaptado;
		this.valoracion = valoracion;
	}

	
	
	public String getMusica() {
		return musica;
	}



	public void setMusica(String musica) {
		this.musica = musica;
	}



	public Double getValoracion() {
		return valoracion;
	}



	public void setValoracion(Double valoracion) {
		Checkers.check(" La valoración debe estar comprendida entre 0 y 100", 
				valoracion>=0.0 && valoracion<=100.0);
		this.valoracion = valoracion;
	}



	public String getNombre() {
		return nombre;
	}



	public TipoCaseta getTipo() {
		return tipo;
	}



	public Integer getModulo() {
		return modulo;
	}



	public Integer getAforo() {
		return aforo;
	}



	public Set<Producto> getMenu() {
		return menu;
	}



	public Boolean getAccesoAdaptado() {
		return accesoAdaptado;
	}



	@Override
	public String toString() {
		return "CasetaFeria [nombre=" + nombre + ", tipo=" + tipo + ", modulo=" + modulo + ", aforo=" + aforo
				+ ", menu=" + menu + ", musica=" + musica + ", accesoAdaptado=" + accesoAdaptado + ", valoracion="
				+ valoracion + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(modulo, nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CasetaFeria other = (CasetaFeria) obj;
		return Objects.equals(modulo, other.modulo) && Objects.equals(nombre, other.nombre);
	}

	
	
	
	@Override
	public int compareTo(CasetaFeria c) {
		int cmp = this.getModulo().compareTo(c.getModulo());
		if (cmp==0) {
			cmp=this.getNombre().compareTo(c.getNombre());
		}
		return cmp;
	}
	
	
	//	• Precio medio, de tipo Double, consultable. Calculado como la media de precios de todos los
	//	platos incluidos en el menú.
	
	public Double getPrecioMedio() {
		//return menu.stream().mapToDouble(p->p.precio()).average().orElse(0.0);
                Double res=0.0;
                Double suma=0.0;
                for (Producto p : menu) {
                    suma += p.precio();
                }
                if (menu.size()>0) {
                    res= suma/menu.size();
                }
                return res;
	}
	
	//	• Caseta barata, de tipo Boolean, consultable. Esta propiedad indica si el menú de la caseta se
	//	considera asequible. Se considera asequible cuando todos los productos del menú tienen un
	//	precio inferior a 10 euros.
	
	public Boolean getCasetaBarata() {
		//return menu.stream().allMatch(p->p.precio()<10.0);
                Boolean res=true;
                for (Producto p : menu) {
                    if (p.precio()>=10) {
                        res=false;
                        break;
                    }
                }
                return res;
	}
}
