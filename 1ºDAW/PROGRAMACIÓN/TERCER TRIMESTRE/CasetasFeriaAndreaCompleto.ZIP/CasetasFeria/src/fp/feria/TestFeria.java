package fp.feria;

import java.util.Map;
import java.util.Set;

public class TestFeria {
	public static void main(String[] args) {
		Set<CasetaFeria> x = FactoriaFeria.leerCasetas("./data/casetas.csv");
		FeriaGestion fg = new FeriaGestion(x);
		//System.out.println(fg);
		testEjercicio1(fg, TipoCaseta.PUBLICA);
		testEjercicio1(fg, TipoCaseta.PRIVADA);
		
		System.out.println("********************");
		System.out.println(fg.getTopNCasetasPorMusica("rebujito", 3));
		
		System.out.println(fg.getCalleMasAforo());
	}

	private static void testEjercicio1(FeriaGestion fg, TipoCaseta tipo) {
		Map<String, Double> d = fg.getPrecioMaxProducto(tipo);
		System.out.print("El precio máximo encontrado para cada producto en las casetas de tipo "+tipo );
		System.out.println(" es: "+d);
		System.out.println();
	}
	
}
