package fp.feria;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

import java.util.TreeSet;

public class FeriaGestion extends Feria {

    public FeriaGestion(Set<CasetaFeria> casetas) {
        super(casetas);
    }

    @Override
    public String toString() {
        String cad = super.toString() + "\n";
        for (CasetaFeria c : getCasetas()) {
            cad += c + "\n";
        }
        return cad;
    }
//	1.getPrecioMaxProducto: Dado un tipo de caseta (pública o privada), devuelve un Map donde las
//	claves son los nombres de los productos ofertados en casetas de ese tipo, y los valores el precio
//	máximo registrado para ese producto en todas las casetas. Implemente este método con bucles.
//	(1,5 ptos)

    public Map<String, Double> getPrecioMaxProducto(TipoCaseta tipo) {
        Map<String, Double> res = new HashMap<>();
        for (CasetaFeria c : getCasetas()) {
            if (c.getTipo().equals(tipo)) {
                for (Producto p : c.getMenu()) {
                    String clave = p.nombre();
                    if (res.containsKey(clave)) {
                        if (res.get(clave) < p.precio()) {
                            res.put(clave, p.precio());
                        }
                    } else {
                        res.put(clave, p.precio());
                    }
                }
            }
        }
        return res;
    }
//	getValoracionMediaTipoCasetaAccesible: Dado un tipo de caseta (pública o privada) y un booleano
//	que representa un valor de accesibilidad, devuelve la valoración media de todas las casetas de ese
//	tipo que tengan el acceso adaptado según el valor indicado. Si no hay casetas que cumplan ambas
//	condiciones, el método debe devolver 0.0. (1 pto)

//    public Double getValoracionMediaTipoCasetaAccesible(TipoCaseta tipo, Boolean b) {
//        return getCasetas().stream().filter(c -> c.getTipo().equals(tipo))
//                .filter(c -> c.getAccesoAdaptado().equals(b))
//                .mapToDouble(c -> c.getValoracion())
//                .average()
//                .orElse(0.0);
//    }
    public Double getValoracionMediaTipoCasetaAccesible(TipoCaseta tipo, Boolean esAccesible) {
        Double suma = 0.0;
        Integer res = 0;
        for (CasetaFeria c : getCasetas()) {
            if (c.getTipo().equals(tipo) && c.getAccesoAdaptado().equals(esAccesible)) {
                suma += c.getValoracion();
                res++;
            }
        }

        if (res == 0) {
            return 0.0;
        } else {
            return suma / res;
        }
    }

//	getNombresProductos: Dado un umbral de precio, devuelve un conjunto ordenado alfabéticamente
//	con los nombres de todos los productos cuyo precio sea inferior al umbral indicado. (1 pto)
//
//    public SortedSet<String> getNombresProductos(Double umbral) {
//        return getCasetas().stream()
//                .flatMap(c -> c.getMenu().stream())
//                .filter(p -> p.precio() < umbral)
//                .map(p -> p.nombre())
//                .collect(Collectors.toCollection(TreeSet::new));
//    }
    public Set<String> getNombresProductos(Double umbral) {
        Set<String> res = new TreeSet<>();
        for (CasetaFeria c : getCasetas()) {
            for (Producto p : c.getMenu()) {
                if (p.precio() < umbral) {
                    res.add(p.nombre());
                }
            }
        }
        return res;
    }

//	getTopNCasetasPorMusica: Dado el nombre de un producto y un número entero n, devuelve un Map
//	que asocie a cada tipo de música una lista con los nombres de las n casetas mejor valoradas que
//	incluyan ese producto en su menú. (1,5 ptos)
//    public Map<String, List<String>> getTopNCasetasPorMusica(String np, Integer n) {
//        return getCasetas().stream()
//                .filter(c -> tienenEseProducto(c, np))
//                .collect(Collectors.groupingBy(c -> c.getMusica(),
//                        Collectors.collectingAndThen(Collectors.toList(),
//                                x -> auxiliar(x, n))
//                ));
//
//    }
//
//    private List<String> auxiliar(List<CasetaFeria> x, Integer n) {
//        Comparator<CasetaFeria> cmp = Comparator.comparing(CasetaFeria::getValoracion);
//
//        return x.stream()
//                .sorted(cmp.reversed())
//                .limit(n)
//                .map(c -> c.getNombre())
//                .collect(Collectors.toList());
//    }
//
//    private Boolean tienenEseProducto(CasetaFeria c, String np) {
//        return c.getMenu().stream().map(p -> p.nombre()).anyMatch(n -> n.equals(np));
//    }
    public Map<String, List<String>> getTopNCasetasPorMusica(String nombreProducto, Integer n) {
        Map<String, List<CasetaFeria>> grupos = new HashMap<>();

        for (CasetaFeria c : getCasetas()) {
            boolean tieneProducto = false;
            for (Producto p : c.getMenu()) {
                if (p.nombre().equalsIgnoreCase(nombreProducto)) {
                    tieneProducto = true;
                    break;
                }
            }

            if (tieneProducto) {
                String clave = c.getMusica();
                if (grupos.containsKey(clave)) {
                    grupos.get(clave).add(c);
                } else {
                    List<CasetaFeria> nuevaLista = new ArrayList<>();
                    nuevaLista.add(c);
                    grupos.put(clave, nuevaLista);
                }
            }
        }

        Map<String, List<String>> res = new HashMap<>();
        for (String musica : grupos.keySet()) {
            List<CasetaFeria> listaCasetas = grupos.get(musica);
            // Ordenamos de mayor a menor valoración
            listaCasetas.sort((c1, c2) -> c2.getValoracion().compareTo(c1.getValoracion()));

            List<String> nombresTop = new ArrayList<>();
            for (int i = 0; i < Math.min(n, listaCasetas.size()); i++) {
                nombresTop.add(listaCasetas.get(i).getNombre());
            }
            res.put(musica, nombresTop);
        }
        return res;
    }

//	getCalleMasAforo: Devuelve la calle (representada por el primer dígito del número de módulo) que
//	acumula el mayor aforo total sumando el aforo de todas las casetas situadas en ella. El método debe
//	devolver el carácter que representa ese primer dígito, si no se puede calcular se elevará la excepción
//	NoSuchElementException. (1,5 ptos)
//    public Integer getCalleMasAforo() {
//        Map<Integer, Integer> d = getCasetas().stream()
//                .collect(Collectors.groupingBy(c -> c.getModulo() / 100,
//                        Collectors.summingInt(c -> c.getAforo())
//                ));
//        return d.entrySet().stream()
//                .max(Comparator.comparing(e -> e.getValue()))
//                .get()
//                .getKey();
//    }
    public Integer getCalleMasAforo() {
        Map<Integer, Integer> aforosPorCalle = new HashMap<>();

        for (CasetaFeria c : getCasetas()) {
            Integer modulo = c.getModulo();
            if (modulo != null && !modulo.equals(c)) {
                Integer clave = modulo.compareTo(0);
                if (aforosPorCalle.containsKey(clave)) {
                    Integer totalActual = aforosPorCalle.get(clave);
                    aforosPorCalle.put(clave, totalActual + c.getAforo());
                } else {
                    aforosPorCalle.put(clave, c.getAforo());
                }
            }
        }

        Integer calleMax = null;
        Integer maxAforo = -1;
        for (Integer calle : aforosPorCalle.keySet()) {
            if (aforosPorCalle.get(calle) > maxAforo) {
                maxAforo = aforosPorCalle.get(calle);
                calleMax = calle;
            }
        }

        if (calleMax == null) {
            throw new NoSuchElementException("No hay datos");
        } else {
            return calleMax;
        }
    }

    //MÉTODOS CLASSROOM
    // 1. ¿Cuántas casetas tienen acceso a minusválidos?
    public Integer getNumCasetasAccesibles() {
        Integer res = 0;
        for (CasetaFeria c : getCasetas()) {
            if (c.getAccesoAdaptado()) {
                res++;
            }
        }
        return res;
    }

    // 2. ¿Devuelve un listado con los nombres de las casetas de un tipo de música dado?
    public List<String> getNombresCasetasPorMusica(String musica) {
        List<String> res = new ArrayList<>();
        for (CasetaFeria c : getCasetas()) {
            if (c.getMusica().equalsIgnoreCase(musica)) {
                res.add(c.getNombre());
            }
        }
        return res;
    }

    // 3. ¿Cuál es el nombre de la caseta con mayor aforo?
    public String getNombreCasetaMayorAforo() {
        CasetaFeria mayor = null;
        for (CasetaFeria c : getCasetas()) {
            if (mayor == null || c.getAforo() > mayor.getAforo()) {
                mayor = c;
            }
        }

        if (mayor == null) {
            return null;
        } else {
            return mayor.getNombre();
        }
    }

    // 4. ¿Cuál es el aforo medio de las casetas públicas?
    public Double getAforoMedioPublicas() {
        Double suma = 0.0;
        Integer cont = 0;
        for (CasetaFeria c : getCasetas()) {
            if (c.getTipo().equals(TipoCaseta.PUBLICA)) {
                suma += c.getAforo();
                cont++;
            }
        }

        if (cont == 0) {
            return 0.0;
        } else {
            return suma / cont;
        }
    }

    // 5. ¿Cuál es el aforo medio de las casetas que tienen cerveza?
    public Double getAforoMedioConCerveza() {
        Double suma = 0.0;
        Integer cont = 0;
        for (CasetaFeria c : getCasetas()) {
            boolean tieneCerveza = false;
            for (Producto p : c.getMenu()) {
                if (p.nombre().equalsIgnoreCase("cerveza")) {
                    tieneCerveza = true;
                    break;
                }
            }

            if (tieneCerveza) {
                suma += c.getAforo();
                cont++;
            }
        }

        if (cont == 0) {
            return 0.0;
        } else {
            return suma / cont;
        }
    }
}
