package fp.feria;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class Feria {
	private Integer anyo;
	private Set<CasetaFeria> casetas;
	
	public Feria(Set<CasetaFeria> casetas) {
		this.casetas = new HashSet<>(casetas) ;
		this.anyo=LocalDate.now().getYear();
	}

	public Integer getAnyo() {
		return anyo;
	}

	public Set<CasetaFeria> getCasetas() {
		return new HashSet<>(casetas) ;
	}
	
	@Override
	public String toString() {
		return ""+anyo+"-"+casetas.size();
	}

	@Override
	public int hashCode() {
		return Objects.hash(anyo, casetas);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Feria other = (Feria) obj;
		return Objects.equals(anyo, other.anyo) && Objects.equals(casetas, other.casetas);
	}
//	• getNumeroCasetas: Obtiene el número de casetas de ese año en la feria.
	public Integer getNumeroCasetas() {
		return casetas.size();
	}
//	• incorporaCaseta: Dada una caseta, la añade al conjunto de casetas.
	public void incorporaCaseta(CasetaFeria c) {
		casetas.add(c);
	}
//	• eliminaCaseta: Dada una caseta, la elimina del conjunto de casetas.
	public void eliminaCaseta(CasetaFeria c) {
		casetas.remove(c);
	}
}
