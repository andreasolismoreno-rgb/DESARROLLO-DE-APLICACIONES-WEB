package fp.feria;

import fp.utiles.Checkers;

public record Producto(String nombre, Double precio) {

	public  Producto {
		Checkers.checkNoNull(nombre, precio);
		Checkers.check("El precio debe ser positivo.", precio>=0.0);
	}
}
