/**
 *
 * @author DarkS
 */
package com.mycompany.proyectohundirlaflota;

public class Jugador {
private String nombre;
private int victorias;

public Jugador(String nombre) {
    this.nombre = nombre;
    this.victorias = 0; // Todos empiezan con 0
}

public String getNombre() {
    return nombre;
}

public int getVictorias() {
    return victorias;
}

public void sumarVictoria() {
    this.victorias++;
}

}
