package com.mycompany.proyectohundirlaflota;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.text.NumberFormat;
import java.util.Locale;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class TableroMaritimo extends javax.swing.JFrame {

    // --- MEMORIA DEL JUEGO ---
    private JButton[][] casillas = new JButton[10][10];
    private int[][] tableroLogico = new int[10][10]; 
    private JPanel panelJuego;
    
    private Jugador comandante;
    private Jugador artillero;
    
    private boolean juegoIniciado = false;
    private boolean juegoTerminado = false;
    private boolean faseColocacion = true; 
    
    private boolean esHorizontal = true;
    private int longitudBarcoActual = 0;
    private String nombreBarcoActual = "";
    private JButton botonBarcoActual = null;
    
    private int barcosColocados = 0;
    private int municion = 40; 
    private int impactosExitosos = 0; 

    // --- VARIABLES ECONÓMICAS (MISIL PATRIOT) ---
    private final long COSTE_MISIL = 4000000; // 4 Millones de USD
    private long gastoTotal = 0;
    private NumberFormat formatoMoneda = NumberFormat.getCurrencyInstance(Locale.US);
    
    // Componentes visuales
    private JLabel lblDisplay; 
    private JLabel lblMarcadorHistorico;
    private JLabel lblGastoMilitar; // Nueva etiqueta para el dinero
    private JButton btnOrientacion; 
    private JButton btnAccion; 
    private JButton btnPortaaviones, btnAcorazado, btnSubmarino, btnDestructor, btnPatrullero;

    public TableroMaritimo() {
        comandante = new Jugador("Almirante.");
        artillero = new Jugador("Artillero.");

        setTitle("Hundir la Flota - Simulador de Gasto Militar");
        setSize(850, 700); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        panelJuego = new JPanel();
        panelJuego.setLayout(new GridLayout(10, 10));

        for (int fila = 0; fila < 10; fila++) {
            for (int columna = 0; columna < 10; columna++) {
                casillas[fila][columna] = new JButton();
                casillas[fila][columna].setBackground(new Color(0, 150, 255)); 
                
                final int f = fila;
                final int c = columna;
                
                casillas[fila][columna].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (!juegoIniciado || juegoTerminado) return;
                        if (faseColocacion) {
                            colocarBarco(f, c);
                        } else {
                            disparar(f, c);
                        }
                    }
                });
                panelJuego.add(casillas[fila][columna]);
            }
        }
        add(panelJuego, BorderLayout.CENTER);

        JPanel panelControles = new JPanel();
        panelControles.setLayout(new GridLayout(11, 1, 5, 5)); 
        panelControles.setPreferredSize(new Dimension(250, 650)); 
        panelControles.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); 

        btnAccion = new JButton("INICIAR PARTIDA");
        btnAccion.setBackground(Color.GREEN);
        btnAccion.setFont(new Font("Arial", Font.BOLD, 12));
        btnAccion.addActionListener(e -> prepararPartida());

        lblMarcadorHistorico = new JLabel("", SwingConstants.CENTER);
        actualizarMarcadores(); 

        lblDisplay = new JLabel("Esperando inicio...", SwingConstants.CENTER);
        
        // Configuración de la nueva etiqueta de gasto
        lblGastoMilitar = new JLabel("<html><div style='text-align: center; color: #b22222;'>" +
                "<b>GASTO EN MISILES</b><br>$0.00</div></html>", SwingConstants.CENTER);
        lblGastoMilitar.setFont(new Font("Monospaced", Font.BOLD, 13));

        btnOrientacion = new JButton("Orientación: Horizontal");
        btnOrientacion.setEnabled(false); 
        btnOrientacion.addActionListener(e -> {
            esHorizontal = !esHorizontal; 
            btnOrientacion.setText(esHorizontal ? "Orientación: Horizontal" : "Orientación: Vertical");
        });

        // Botones de barcos
        btnPortaaviones = new JButton("Portaaviones (5)");
        btnAcorazado = new JButton("Acorazado (4)");
        btnSubmarino = new JButton("Submarino (3)");
        btnDestructor = new JButton("Destructor (3)");
        btnPatrullero = new JButton("Patrullero (2)");

        configurarBotonBarco(btnPortaaviones, "Portaaviones", 5);
        configurarBotonBarco(btnAcorazado, "Acorazado", 4);
        configurarBotonBarco(btnSubmarino, "Submarino", 3);
        configurarBotonBarco(btnDestructor, "Destructor", 3);
        configurarBotonBarco(btnPatrullero, "Patrullero", 2);

        panelControles.add(btnAccion);
        panelControles.add(lblMarcadorHistorico); 
        panelControles.add(lblDisplay);
        panelControles.add(lblGastoMilitar); // Añadida al panel
        panelControles.add(btnOrientacion);
        panelControles.add(btnPortaaviones);
        panelControles.add(btnAcorazado);
        panelControles.add(btnSubmarino);
        panelControles.add(btnDestructor);
        panelControles.add(btnPatrullero);

        add(panelControles, BorderLayout.EAST);
    }

    private void configurarBotonBarco(JButton btn, String nombre, int len) {
        btn.setEnabled(false);
        btn.addActionListener(e -> seleccionarBarco(nombre, len, btn));
    }

    private void reproducirSonido(String nombreArchivo) {
        try {
            URL url = getClass().getResource("/" + nombreArchivo);
            if (url != null) {
                AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
                Clip clip = AudioSystem.getClip();
                clip.open(audioIn);
                clip.start();
            }
        } catch (Exception ex) {
            System.err.println("Error audio: " + ex.getMessage());
        }
    }

    private void prepararPartida() {
        barcosColocados = 0;
        municion = 40;
        impactosExitosos = 0;
        gastoTotal = 0; // Reset económico
        faseColocacion = true;
        juegoIniciado = true;
        juegoTerminado = false;
        longitudBarcoActual = 0;

        actualizarGastoVisual();
        
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                tableroLogico[i][j] = 0;
                casillas[i][j].setBackground(new Color(0, 150, 255));
                casillas[i][j].setText("");
            }
        }

        btnOrientacion.setEnabled(true);
        btnPortaaviones.setEnabled(true);
        btnAcorazado.setEnabled(true);
        btnSubmarino.setEnabled(true);
        btnDestructor.setEnabled(true);
        btnPatrullero.setEnabled(true);
        btnAccion.setEnabled(false);
        
        lblDisplay.setText("<html><center>FASE DE DESPLIEGUE<br>Selecciona barcos</center></html>");
    }

    private void disparar(int fila, int columna) {
        if (tableroLogico[fila][columna] >= 2) return;
        
        if (municion > 0) {
            municion--; 
            gastoTotal += COSTE_MISIL; // Sumamos 4 millones de dólares
            actualizarGastoVisual();
            
            if (tableroLogico[fila][columna] == 1) {
                tableroLogico[fila][columna] = 3; 
                casillas[fila][columna].setBackground(Color.RED);
                impactosExitosos++;
                reproducirSonido("explosion.wav");
            } else {
                tableroLogico[fila][columna] = 2;
                casillas[fila][columna].setBackground(Color.WHITE);
                reproducirSonido("splash.wav");
            }
            
            actualizarDisplayArtillero();
            comprobarFinDeJuego();
        }
    }

    private void actualizarGastoVisual() {
        lblGastoMilitar.setText("<html><div style='text-align: center; color: #b22222;'>" +
                "<b>COSTO OPERATIVO (PATRIOT)</b><br>" + formatoMoneda.format(gastoTotal) + "</div></html>");
    }

    private void actualizarDisplayArtillero() {
        lblDisplay.setText("<html><div style='text-align: center; color: red;'><b>ARTILLERÍA</b><br>" +
                "Misiles: " + municion + "<br>Impactos: " + impactosExitosos + "/17</div></html>");
    }

    private void seleccionarBarco(String nombre, int longitud, JButton boton) {
        longitudBarcoActual = longitud;
        nombreBarcoActual = nombre;
        botonBarcoActual = boton;
        lblDisplay.setText("<html><center>Colocando:<br>" + nombre + "</center></html>");
    }

    private void colocarBarco(int f, int c) {
    if (longitudBarcoActual == 0) return;
    
    boolean sePuedeColocar = true;

    // 1. PRIMERA PASADA: Comprobar límites y colisiones SIN pintar nada todavía
    if (esHorizontal) {
        if (c + longitudBarcoActual > 10) {
            sePuedeColocar = false;
        } else {
            for (int i = 0; i < longitudBarcoActual; i++) {
                if (tableroLogico[f][c + i] != 0) {
                    sePuedeColocar = false;
                    break; // Salimos del bucle en cuanto detectamos un choque
                }
            }
        }
    } else { // Vertical
        if (f + longitudBarcoActual > 10) {
            sePuedeColocar = false;
        } else {
            for (int i = 0; i < longitudBarcoActual; i++) {
                if (tableroLogico[f + i][c] != 0) {
                    sePuedeColocar = false;
                    break;
                }
            }
        }
    }

    // 2. SEGUNDA PASADA: Solo si ha pasado la inspección, pintamos
    if (sePuedeColocar) {
        for (int i = 0; i < longitudBarcoActual; i++) {
            if (esHorizontal) {
                tableroLogico[f][c + i] = 1; 
                casillas[f][c + i].setBackground(Color.DARK_GRAY);
            } else {
                tableroLogico[f + i][c] = 1; 
                casillas[f + i][c].setBackground(Color.DARK_GRAY);
            }
        }
        
        // Finalizamos la colocación de esta pieza
        botonBarcoActual.setEnabled(false);
        longitudBarcoActual = 0;
        barcosColocados++;
        
        if (barcosColocados == 5) {
            iniciarFaseAtaque();
        } else {
            lblDisplay.setText("<html><center>Barco fijado.<br>Selecciona el siguiente.</center></html>");
        }
    } else {
        // Si no se puede colocar, lanzamos el error y NO hacemos nada más
        JOptionPane.showMessageDialog(this, "¡ERROR DE NAVEGACIÓN!\nEl barco choca con otra unidad o se sale del mapa.", "Alerta de Colisión", JOptionPane.ERROR_MESSAGE);
    }
}

    private void iniciarFaseAtaque() {
        faseColocacion = false;
        for (int i = 0; i < 10; i++) 
            for (int j = 0; j < 10; j++) casillas[i][j].setBackground(new Color(0, 150, 255));
        
        btnOrientacion.setEnabled(false);
        actualizarDisplayArtillero();
        JOptionPane.showMessageDialog(this, "Sistemas de armas listos.\nCada misil Patriot cuesta $4M.\n¡No desperdicie munición!");
    }

    private void comprobarFinDeJuego() {
        if (impactosExitosos == 17) {
            artillero.sumarVictoria();
            actualizarMarcadores();
            String resumen = "¡Objetivos destruidos!\nGasto total en la operación: " + formatoMoneda.format(gastoTotal);
            finalizarJuego(resumen, "Victoria Táctica");
        } else if (municion == 0) {
            comandante.sumarVictoria();
            actualizarMarcadores();
            finalizarJuego("Bancarrota militar. Se ha agotado el presupuesto.", "Misión Fallida");
        }
    }

    private void finalizarJuego(String mensaje, String titulo) {
        juegoTerminado = true;
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
        btnAccion.setText("NUEVA CAMPAÑA");
        btnAccion.setEnabled(true);
    }

    private void actualizarMarcadores() {
        lblMarcadorHistorico.setText("<html><center><b>HISTORIAL</b><br>" +
            comandante.getNombre() + ": " + comandante.getVictorias() + "<br>" +
            artillero.getNombre() + ": " + artillero.getVictorias() + "</center></html>");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new TableroMaritimo().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
