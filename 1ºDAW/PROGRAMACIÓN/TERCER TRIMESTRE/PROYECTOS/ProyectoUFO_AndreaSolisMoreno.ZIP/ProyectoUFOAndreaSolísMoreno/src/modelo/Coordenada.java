package modelo;

public record Coordenada(Double latitud, Double longitud) {

    public Double distanciaA(Coordenada c) {
        Double catetoX = this.longitud - c.longitud;
        Double catetoY = this.latitud - c.latitud;
        return Math.sqrt(catetoX * catetoX + catetoY * catetoY);
    }
}
