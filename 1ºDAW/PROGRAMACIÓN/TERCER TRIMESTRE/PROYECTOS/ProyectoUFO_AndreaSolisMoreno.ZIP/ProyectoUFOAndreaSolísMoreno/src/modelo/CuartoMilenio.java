package modelo;

import java.time.Month;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class CuartoMilenio {

    private List<Avistamiento> avistamientos;

// Constructor 
    public CuartoMilenio(List<Avistamiento> lista) {
        this.avistamientos = new ArrayList<>(lista);
    }

// para buscar y filtrar
    public Boolean existeAvistamiento(String pais, String forma) {
        return avistamientos.stream().anyMatch(a -> a.getCountry().equalsIgnoreCase(pais) && a.getShape().equalsIgnoreCase(forma));
    }

    public List<Avistamiento> getAvistamientosLargos(Double segundos) {
        return avistamientos.stream().filter(a -> a.getDuration() > segundos).collect(Collectors.toList());
    }

    public List<Avistamiento> getAvistamientosAlNorteDe(Coordenada miPosicion) {
        return avistamientos.stream().filter(a -> a.getCoordenada().latitud() > miPosicion.latitud()).collect(Collectors.toList());
    }

// mapa
    public Map<String, Long> getConteoPorForma() {
        return avistamientos.stream().collect(Collectors.groupingBy(Avistamiento::getShape, Collectors.counting()));
    }

    public String getPaisConAvistamientoMasReciente() {
        return avistamientos.stream().max(Comparator.comparing(Avistamiento::getDatetime)).map(Avistamiento::getCountry).orElse("No hay datos");
    }

    public String getFormaMasComunEnPais(String pais) {
        Map<String, Long> conteo = avistamientos.stream().filter(a -> a.getCountry().equalsIgnoreCase(pais)).collect(Collectors.groupingBy(Avistamiento::getShape, Collectors.counting()));

        return conteo.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse("Desconocida");
    }

    public String getFormaMenosComunEnPais(String pais) {
        Map<String, Long> conteo = avistamientos.stream().filter(a -> a.getCountry().equalsIgnoreCase(pais)).collect(Collectors.groupingBy(Avistamiento::getShape, Collectors.counting()));

        return conteo.entrySet().stream().min(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse("Desconocida");
    }

// bucles
    public Map<String, Avistamiento> getMasLargoPorPais() {
        Map<String, Avistamiento> res = new HashMap<>();
        for (Avistamiento a : avistamientos) {
            String pais = a.getCountry();
            if (!res.containsKey(pais) || a.getDuration() > res.get(pais).getDuration()) {
                res.put(pais, a);
            }
        }
        return res;
    }

    public Avistamiento getMasRecienteAlSurDe(Coordenada miPosicion) {
        Avistamiento res = null;
        for (Avistamiento a : avistamientos) {
            if (a.getCoordenada().latitud() < miPosicion.latitud()) {
                if (res == null || a.getDatetime().isAfter(res.getDatetime())) {
                    res = a;
                }
            }
        }
        return res;
    }

    public String getPrimeraCiudadConAvistamiento() {
        return avistamientos.stream().min(Comparator.comparing(Avistamiento::getDatetime)).map(Avistamiento::getCity).orElse("No hay datos");
    }

// propiedades derivadas-
    public Double mediaDuracionPorAnio(Integer anio) {
        return avistamientos.stream().filter(a -> a.getDatetime().getYear() == anio).mapToDouble(Avistamiento::getDuration).average().orElse(0.0);
    }

    public Set<String> getCiudadesPorMes(Month mes) {
        return avistamientos.stream().filter(a -> a.getDatetime().getMonth() == mes).map(Avistamiento::getCity).collect(Collectors.toSet());
    }

    public Set<String> getPaisPorAnio(Integer anio) {
        return avistamientos.stream().filter(a -> a.getDatetime().getYear() == anio).map(Avistamiento::getCountry).collect(Collectors.toSet());
    }

// coordenadas
    public List<Avistamiento> getMasCercanosA(Coordenada c, Integer n) {
        return avistamientos.stream().sorted(Comparator.comparing(a -> a.getCoordenada().distanciaA(c))).limit(n).collect(Collectors.toList());
    }

    public List<Avistamiento> getMasLejanosA(Coordenada c, Integer n) {
        return avistamientos.stream().sorted(Comparator.comparing((Avistamiento a) -> a.getCoordenada().distanciaA(c)).reversed()).limit(n).collect(Collectors.toList());
    }
}
