package test;

import java.time.Month;
import java.util.List;
import java.util.Map;
import modelo.Avistamiento;
import modelo.Coordenada;
import modelo.CuartoMilenio;
import modelo.FactoriaAvistamientos;

public class TestUFOs {

    public static void main(String[] args) {
        System.out.println("----- PROYECTO OVNIS: CUARTO MILENIO -----");

        List<Avistamiento> listaCSV = FactoriaAvistamientos.leerAvistamientos("./date/complete.csv");

        if (listaCSV.isEmpty()) {
            System.out.println("Error: No se han podido cargar los datos. Verifica la carpeta y el nombre del archivo.");
            return;
        }

        CuartoMilenio cm = new CuartoMilenio(listaCSV);
        System.out.println("Registros cargados con éxito: " + listaCSV.size());

        System.out.println("1. ¿Ha habido avistamientos esféricos en USA (us)?: " + cm.existeAvistamiento("us", "sphere"));

        System.out.println("2. ¿Cuál es el país con el avistamiento más reciente? : " + cm.getPaisConAvistamientoMasReciente());

        System.out.println("3. ¿Cuáles son las 3 formas de ovnis más detectadas al norte de madrid? :");
        Coordenada madrid = new Coordenada(40.43712195591008, -3.6943330295109873);
        List<Avistamiento> listaNorte = cm.getAvistamientosAlNorteDe(madrid);
        listaNorte.stream().limit(5).forEach(a -> {
        System.out.println(" - Según su forma: " + a.getShape() +", en la ciudad de: " + a.getCity() + ", de : " + a.getCountry().toUpperCase() + " y con unas " + a.getCoordenada());
        });
        System.out.println(" Total de avistamientos encontrados al norte: " + listaNorte.size());
        
        
        System.out.println("4. ¿Cuál es la duración media en el año 2000? : " + cm.mediaDuracionPorAnio(2000) + " segundos.");

        System.out.println("5. ¿Cuáles son las ciudades con avistamientos en octubre? :");
        cm.getCiudadesPorMes(Month.OCTOBER).stream().limit(5).forEach(c -> System.out.println(" - " + c));

        System.out.println("6. ¿Cuál fue la primera ciudad en registrar un ovnis? : " + cm.getPrimeraCiudadConAvistamiento());

        Coordenada africa = new Coordenada(-8.58657723123241, 34.5118759687518);
        Avistamiento sur = cm.getMasRecienteAlSurDe(africa);
        if (sur != null) {
            System.out.println("7. ¿Cuáles son los avistamientos reciente al sur de África? : " + "En la ciudad: " + sur.getCity() + " Hora: " + sur.getDatetime() + " Con  : " + sur.getCoordenada());
        }

        Coordenada sevilla = new Coordenada(37.37853030601249, -5.9777290191978505);
        System.out.println("8. ¿Cuáles son los 3 ovnis ue se hayan visto más cerca a Sevilla:");
        cm.getMasCercanosA(sevilla, 3).forEach(cerca -> System.out.println(" - " + cerca.getCity() + " a " + cerca.getDuration() + " seg de duración"));

        Coordenada sevilla_a = new Coordenada(37.37853030601249, -5.9777290191978505);
        System.out.println("9. ¿Cuáles son los 3 ovnis que se hayan visto más lejos de Sevilla? :");
        cm.getMasLejanosA(sevilla_a, 3).forEach(lejos -> System.out.println(" - " + lejos.getCity() + " (" + lejos.getCountry() + ")"));

        System.out.println("10. ¿Qué forma suele tener en común los ovnis en USA (us) , y la menos común? : " + " La forma de ovni más vista es ; " + cm.getFormaMasComunEnPais("us") + ", y la forma de ovni menos vista es ; " + cm.getFormaMenosComunEnPais("us"));

        System.out.println("-------------------------------------------");
        System.out.println("Fin del programa.");
    }
}
