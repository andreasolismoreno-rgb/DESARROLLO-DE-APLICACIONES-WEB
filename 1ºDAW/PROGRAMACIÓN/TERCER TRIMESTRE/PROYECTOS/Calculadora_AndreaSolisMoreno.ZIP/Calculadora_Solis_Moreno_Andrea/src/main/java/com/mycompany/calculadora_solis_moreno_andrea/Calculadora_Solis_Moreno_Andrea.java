/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadora_solis_moreno_andrea;

/**
 *
 * @author DAW1-M
 */
public class Calculadora_Solis_Moreno_Andrea {

    public static void main(String[] args) {
        System.out.println("Mi calculadora!");
    }
}
