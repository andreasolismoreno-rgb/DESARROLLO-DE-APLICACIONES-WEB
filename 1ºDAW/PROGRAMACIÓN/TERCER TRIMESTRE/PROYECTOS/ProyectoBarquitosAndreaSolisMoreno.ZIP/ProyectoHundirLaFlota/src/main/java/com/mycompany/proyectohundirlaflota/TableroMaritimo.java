package com.mycompany.proyectohundirlaflota;

import java.awt.*;
import java.net.URL;
import java.util.HashMap;
import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;

public class TableroMaritimo extends javax.swing.JFrame {

    private JButton[][] rejilla = new JButton[10][10];
    private int[][] mapaLogico = new int[10][10];
    private JPanel panelPrincipal;

    private Jugador player1;
    private Jugador player2;

    private boolean activo = false;
    private boolean terminado = false;
    private boolean modoColocar = true;

    private boolean orientacionH = true;
    private int tamanoBarco = 0;
    private int idBarcoActual = 10;
    private JButton btnSeleccionado = null;

    private HashMap<Integer, Integer> vidasBarcos = new HashMap<>();
    private int barcosRestantes = 0;

    private int intentos = 50;
    private int aciertosTotales = 0;

    private Color colorAgua = new Color(0, 100, 150);
    private Color colorBarco = Color.DARK_GRAY;
    private Color colorTocado = Color.YELLOW; // Cambiado a Amarillo
    private Color colorHundido = Color.RED;    // Rojo para cuando cae entero

    private JLabel lblStatus, lblRecords, lblFlota;
    private JButton btnGirar, btnControl;
    private JButton b1, b2, b3, b4, b5;

    public TableroMaritimo() {
        player1 = new Jugador("Capitán");
        player2 = new Jugador("Enemigo");

        setTitle("Sistema de Combate Naval - Control Táctico");
        setSize(1000, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        panelPrincipal = new JPanel(new GridLayout(10, 10, 1, 1));
        panelPrincipal.setBackground(Color.BLACK);

        for (int f = 0; f < 10; f++) {
            for (int c = 0; c < 10; c++) {
                rejilla[f][c] = new JButton();
                rejilla[f][c].setBackground(colorAgua);

                final int fila = f;
                final int col = c;

                rejilla[f][c].addActionListener(e -> {
                    if (!activo || terminado) {
                        return;
                    }
                    if (modoColocar) {
                        if (tamanoBarco == 0) {
                            JOptionPane.showMessageDialog(this, "INSTRUCCIÓN: Seleccione primero un barco del panel derecho.", "Asistente", JOptionPane.WARNING_MESSAGE);
                            return;
                        }
                        gestionarColocacion(fila, col);
                    } else {
                        ejecutarDisparo(fila, col);
                    }
                });
                panelPrincipal.add(rejilla[f][c]);
            }
        }
        add(panelPrincipal, BorderLayout.CENTER);

        JPanel panelSide = new JPanel();
        panelSide.setLayout(new BoxLayout(panelSide, BoxLayout.Y_AXIS));
        panelSide.setPreferredSize(new Dimension(280, 600));
        panelSide.setBorder(BorderFactory.createTitledBorder(null, "ESTADO DE MISIÓN", TitledBorder.CENTER, TitledBorder.TOP));

        btnControl = new JButton("COMENZAR LA MISIÓN");
        btnControl.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnControl.addActionListener(e -> resetearMision());

        lblRecords = new JLabel("", SwingConstants.CENTER);
        lblRecords.setAlignmentX(Component.CENTER_ALIGNMENT);

        lblStatus = new JLabel("<html><center>Esperando inicio...</center></html>", SwingConstants.CENTER);
        lblStatus.setAlignmentX(Component.CENTER_ALIGNMENT);

        lblFlota = new JLabel("<html><center>Barcos restantes: - </center></html>", SwingConstants.CENTER);
        lblFlota.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblFlota.setForeground(new Color(200, 0, 0));

        btnGirar = new JButton("Girar: HORIZONTAL");
        btnGirar.setEnabled(false);
        btnGirar.addActionListener(e -> {
            orientacionH = !orientacionH;
            btnGirar.setText(orientacionH ? "Girar: HORIZONTAL" : "Girar: VERTICAL");
        });

        b1 = new JButton("Portaaviones (5)");
        b2 = new JButton("Acorazado (4)");
        b3 = new JButton("Submarino (3)");
        b4 = new JButton("Destructor (3)");
        b5 = new JButton("Patrullero (2)");

        configurarBoton(b1, 5);
        configurarBoton(b2, 4);
        configurarBoton(b3, 3);
        configurarBoton(b4, 3);
        configurarBoton(b5, 2);

        panelSide.add(Box.createVerticalStrut(10));
        panelSide.add(btnControl);
        panelSide.add(Box.createVerticalStrut(15));
        panelSide.add(lblRecords);
        panelSide.add(Box.createVerticalStrut(15));
        panelSide.add(lblStatus);
        panelSide.add(Box.createVerticalStrut(15));
        panelSide.add(lblFlota);
        panelSide.add(Box.createVerticalStrut(15));
        panelSide.add(btnGirar);
        panelSide.add(Box.createVerticalStrut(10));
        panelSide.add(b1);
        panelSide.add(b2);
        panelSide.add(b3);
        panelSide.add(b4);
        panelSide.add(b5);

        add(panelSide, BorderLayout.EAST);
        actualizarPuntajes();
    }

    private void configurarBoton(JButton b, int l) {
        b.setEnabled(false);
        b.setMaximumSize(new Dimension(250, 35));
        b.addActionListener(e -> {
            tamanoBarco = l;
            btnSeleccionado = b;
            lblStatus.setText("Preparado: Barco de " + l);
        });
    }

    private void resetearMision() {
        JOptionPane.showMessageDialog(this, "GUÍA: 1. Elige un barco. 2. Colócalo. 3. Pulsa OK cuando termines.", "Manual de Usuario", JOptionPane.INFORMATION_MESSAGE);
        idBarcoActual = 10;
        barcosRestantes = 0;
        vidasBarcos.clear();
        intentos = 50;
        aciertosTotales = 0;
        modoColocar = true;
        activo = true;
        terminado = false;
        tamanoBarco = 0;

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                mapaLogico[i][j] = 0;
                rejilla[i][j].setBackground(colorAgua);
            }
        }

        btnGirar.setEnabled(true);
        b1.setEnabled(true);
        b2.setEnabled(true);
        b3.setEnabled(true);
        b4.setEnabled(true);
        b5.setEnabled(true);
        btnControl.setEnabled(false);
        actualizarLabels();
    }

    private void ejecutarDisparo(int f, int c) {
        int valor = mapaLogico[f][c];

        // Si ya disparamos aquí (agua=2 o ya hundido=-1), salimos
        if (valor == 2 || valor == -1 || valor < -9) {
            return;
        }

        intentos--;

        if (valor >= 10) { // Impacto en un barco vivo
            int id = valor;
            int vidaRestante = vidasBarcos.get(id) - 1;
            vidasBarcos.put(id, vidaRestante);

            reproducirSonido("explosion.wav");

            if (vidaRestante == 0) {
                // --- BARCO HUNDIDO COMPLETAMENTE ---
                barcosRestantes--;
                // IMPORTANTE: Primero pintamos TODO el barco de rojo (incluyendo esta casilla)
                pintarBarcoHundidoCompleto(id);
                JOptionPane.showMessageDialog(this, "¡OBJETIVO HUNDIDO!", "Aviso de Radar", JOptionPane.WARNING_MESSAGE);
            } else {
                // --- BARCO TOCADO (AMARILLO) ---
                rejilla[f][c].setBackground(colorTocado);
                // Guardamos el ID en negativo para saber que está tocado pero recordar qué barco era
                mapaLogico[f][c] = -id;
            }
        } else {
            // --- AGUA ---
            mapaLogico[f][c] = 2;
            rejilla[f][c].setBackground(Color.WHITE);
            reproducirSonido("splash.wav");
        }

        actualizarLabels();
        revisarFinal();
    }

    private void pintarBarcoHundidoCompleto(int id) {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                // Buscamos tanto el ID original como el ID negativo (casillas amarillas)
                if (mapaLogico[i][j] == id || mapaLogico[i][j] == -id) {
                    rejilla[i][j].setBackground(colorHundido);
                    mapaLogico[i][j] = -1; // Ahora sí, lo marcamos como hundido definitivo
                }
            }
        }
    }

    private void gestionarColocacion(int f, int c) {
        boolean cabe = true;
        if (orientacionH) {
            if (c + tamanoBarco > 10) {
                cabe = false;
            } else {
                for (int i = 0; i < tamanoBarco; i++) {
                    if (mapaLogico[f][c + i] != 0) {
                        cabe = false;
                    }
                }
            }
        } else {
            if (f + tamanoBarco > 10) {
                cabe = false;
            } else {
                for (int i = 0; i < tamanoBarco; i++) {
                    if (mapaLogico[f + i][c] != 0) {
                        cabe = false;
                    }
                }
            }
        }

        if (!cabe) {
            JOptionPane.showMessageDialog(this, "ERROR: El barco no cabe o choca con otro.", "Sistemas de Navegación", JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (int i = 0; i < tamanoBarco; i++) {
            int nf = f + (orientacionH ? 0 : i);
            int nc = c + (orientacionH ? i : 0);
            mapaLogico[nf][nc] = idBarcoActual;
            rejilla[nf][nc].setBackground(colorBarco);
        }

        vidasBarcos.put(idBarcoActual, tamanoBarco);
        idBarcoActual++;
        barcosRestantes++;
        btnSeleccionado.setEnabled(false);
        tamanoBarco = 0;

        if (barcosRestantes == 5) {
            JOptionPane.showMessageDialog(this, "FLOTA DESPLEGADA: Haga clic en OK para iniciar el combate.", "Radar Activado", JOptionPane.INFORMATION_MESSAGE);
            iniciarCombate();
        }
    }

    private void iniciarCombate() {
        modoColocar = false;
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                rejilla[i][j].setBackground(colorAgua);
            }
        }
        btnGirar.setEnabled(false);
        actualizarLabels();
    }

    private void actualizarLabels() {
        lblStatus.setText("Munición: " + intentos);
        lblFlota.setText("<html><center>Barcos restantes: <b style='color:red;'>" + barcosRestantes + "</b></center></html>");
    }

    private void revisarFinal() {
        if (barcosRestantes == 0) {
            player1.sumarVictoria();
            finalizar("¡VICTORIA! Has hundido toda la flota.", "Fin de la Misión");
        } else if (intentos == 0) {
            player2.sumarVictoria();
            finalizar("DERROTA: Te has quedado sin proyectiles.", "Fin de la Misión");
        }
    }

    private void finalizar(String m, String t) {
        terminado = true;
        actualizarPuntajes();
        JOptionPane.showMessageDialog(this, m, t, JOptionPane.INFORMATION_MESSAGE);
        btnControl.setText("REINICIAR SISTEMA");
        btnControl.setEnabled(true);
    }

    private void actualizarPuntajes() {
        lblRecords.setText("<html><center><b>HISTORIAL</b><br>"
                + player1.getNombre() + ": " + player1.getVictorias() + "<br>"
                + player2.getNombre() + ": " + player2.getVictorias() + "</center></html>");
    }

    private void reproducirSonido(String archivo) {
        try {
            URL url = getClass().getResource("/" + archivo);
            if (url != null) {
                AudioInputStream ai = AudioSystem.getAudioInputStream(url);
                Clip clip = AudioSystem.getClip();
                clip.open(ai);
                clip.start();
            }
        } catch (Exception ex) {
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new TableroMaritimo().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
