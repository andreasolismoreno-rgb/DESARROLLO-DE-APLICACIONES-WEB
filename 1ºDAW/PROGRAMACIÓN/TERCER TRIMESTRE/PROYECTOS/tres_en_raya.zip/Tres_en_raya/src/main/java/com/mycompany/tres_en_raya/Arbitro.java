package com.mycompany.tres_en_raya;

public class Arbitro {

    private Tablero tablero;
    private Jugadores jugador1;
    private Jugadores jugador2;
    private Jugadores turnoActual;

    public Arbitro(Jugadores j1, Jugadores j2) {
        tablero = new Tablero();
        jugador1 = j1;
        jugador2 = j2;
        turnoActual = jugador1;
    }

    public Jugadores getTurno() {
        return turnoActual;
    }

    public boolean jugar(int fila, int col) {

        boolean valido = tablero.ponerFicha(fila, col, turnoActual.getFicha());

        if (valido) {
            cambiarTurno();
        }

        return valido;
    }

    private void cambiarTurno() {
        if (turnoActual == jugador1) {
            turnoActual = jugador2;
        } else {
            turnoActual = jugador1;
        }
    }

    public char getCasilla(int fila, int col) {
        return tablero.getCasilla(fila, col);
    }

    public boolean hayGanador() {

        for (int i = 0; i < 3; i++) {

            // filas
            if (tablero.getCasilla(i, 0) != ' '
                    && tablero.getCasilla(i, 0) == tablero.getCasilla(i, 1)
                    && tablero.getCasilla(i, 1) == tablero.getCasilla(i, 2)) {
                return true;
            }

            // columnas
            if (tablero.getCasilla(0, i) != ' '
                    && tablero.getCasilla(0, i) == tablero.getCasilla(1, i)
                    && tablero.getCasilla(1, i) == tablero.getCasilla(2, i)) {
                return true;
            }
        }

        // diagonal 1
        if (tablero.getCasilla(0, 0) != ' '
                && tablero.getCasilla(0, 0) == tablero.getCasilla(1, 1)
                && tablero.getCasilla(1, 1) == tablero.getCasilla(2, 2)) {
            return true;
        }

        // diagonal 2
        if (tablero.getCasilla(0, 2) != ' '
                && tablero.getCasilla(0, 2) == tablero.getCasilla(1, 1)
                && tablero.getCasilla(1, 1) == tablero.getCasilla(2, 0)) {
            return true;
        }

        return false;
    }

    public boolean hayEmpate() {

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {

                if (tablero.getCasilla(i, j) == ' ') {
                    return false;
                }
            }
        }

        return !hayGanador();
    }

    public Jugadores getJugadorAnterior() {

        if (turnoActual == jugador1) {
            return jugador2;
        } else {
            return jugador1;
        }
    }
}
