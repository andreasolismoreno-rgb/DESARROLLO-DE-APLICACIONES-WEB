/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tres_en_raya;

/**
 *
 * @author DAW1-M
 */
public class Main_Tres_en_raya {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
