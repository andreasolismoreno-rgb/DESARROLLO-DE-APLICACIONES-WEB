package com.mycompany.tres_en_raya;

public class Jugadores {

    private String nombre;
    private char ficha;

    public Jugadores(String nombre, char ficha) {
        this.nombre = nombre;
        this.ficha = ficha;
    }

    public String getNombre() {
        return nombre;
    }

    public char getFicha() {
        return ficha;
    }
}