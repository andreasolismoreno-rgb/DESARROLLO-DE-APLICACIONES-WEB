package com.mycompany.tres_en_raya;

public class Tablero {

    private char[][] tablero;

    public Tablero() {
        tablero = new char[3][3];

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tablero[i][j] = ' ';
            }
        }
    }

    public boolean ponerFicha(int fila, int col, char ficha) {
        if (tablero[fila][col] == ' ') {
            tablero[fila][col] = ficha;
            return true;
        }
        return false;
    }

    public char getCasilla(int fila, int col) {
        return tablero[fila][col];
    }
}