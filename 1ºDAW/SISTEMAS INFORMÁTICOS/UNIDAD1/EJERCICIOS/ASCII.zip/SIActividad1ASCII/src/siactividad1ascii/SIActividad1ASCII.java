
package siactividad1ascii;
import java.util.Scanner;
public class SIActividad1ASCII {


    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.print ("Escribe un carácter:");
        char c = sc.next().charAt(0);
        int codigo = (int) c; // casting del caracter a entero
        String binario = Integer.toBinaryString (codigo);// método que convierte un número en 
                                                            //binario como cadena
        System.out.println("El ASCII de " + c + " es " + binario );
         System.out.println("El ASCII de " + c + " en " + codigo );
    }
    
}
