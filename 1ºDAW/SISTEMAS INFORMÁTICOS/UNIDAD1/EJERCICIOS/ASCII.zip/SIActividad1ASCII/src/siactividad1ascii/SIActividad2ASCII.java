
package siactividad1ascii;


public class SIActividad2ASCII {
    public static void main (String [] args){
        
    //Clase que imprime por pantalla todos los caracteres imprimibles 
    //  del código ASCII (del 32 al 126)
    for ( int i=32; i<=126; i++) {
        char c = ( char ) i; // casting del entero a char para obtener
                            // el carácter de su código
        System.out.println ("El carácter: " + c + " --> " + i);
}
}
}
