
package siactividad1ascii;

public class SIActividad3ASCII {
    public static void main (String [] args){
        // Imprime 5 emoticonos divertidos del estándar Unicode
        System.out.println ( "\u263b emoticono smily");
       System.out.println ( "\u2764 emoticono corazón");
       System.out.println ( "\u2190  flecha lado izquierdo");
       System.out.println ( "\u2192  flecha lado derecho");
        System.out.println ( "\u207d  paréntesis");

        
    }
}
