/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package siactividad1ascii;
import java.util.Scanner;
public class SIActividad4ASCII {
   public static void main (String [] args){
       //Dado un carácter intorudicdo por teclado
       //detectar si es mayúscuka (65 a 90),
       //minúscula (97 a 122) o número (48 a 57).
       Scanner sc = new Scanner (System.in);
       System.out.print ("Escribe un carácter: " );
       char c = sc.next (). charAt (0);
       int codigo = (int) c; // casting del caracter entero 
       
       if ( codigo >= 65 && codigo <= 90){
           System.out.println ("El carácter " + c + " es mayúscula ");
       
         } else if ( codigo >= 97 && codigo <= 122){ 
             System.out.println ("El carácter " + c + " es minúscula ");
    
            } else if ( codigo >= 48 && codigo <= 57){
         System.out.println ("El carácter " + c + " es número ");
            }
    }
}
