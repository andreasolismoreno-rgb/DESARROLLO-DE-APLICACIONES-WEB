package com.ejemplo.proyectoReservas.repositorio;
import com.ejemplo.proyectoReservas.modelo.Habitacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HabitacionRepository  extends JpaRepository<Habitacion, Long>{
    
}
