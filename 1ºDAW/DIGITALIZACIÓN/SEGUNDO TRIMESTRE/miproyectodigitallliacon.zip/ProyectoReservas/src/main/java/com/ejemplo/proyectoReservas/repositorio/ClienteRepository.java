package com.ejemplo.proyectoReservas.repositorio;
import com.ejemplo.proyectoReservas.modelo.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository  extends JpaRepository<Cliente, Long>{
    
}
