package com.ejemplo.proyectoReservas.modelo;

public enum TipoHabitacion {
        INDIVIDUAL, DOBLE, SUITE
}
