package com.ejemplo.proyectoReservas.repositorio;

import com.ejemplo.proyectoReservas.modelo.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
    
}
