package com.ejemplo.proyectoReservas.controlador;

import com.ejemplo.proyectoReservas.modelo.Reserva;
import com.ejemplo.proyectoReservas.modelo.TipoHabitacion;
import com.ejemplo.proyectoReservas.repositorio.ReservaRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class ReservaController {

    private final ReservaRepository repo;

    public ReservaController(ReservaRepository repo) {
        this.repo = repo;
    }

    @GetMapping("/")
    public String listar(Model model) {
        model.addAttribute("reservas", repo.findAll());
        return "lista";
    }

    @GetMapping("/nueva")
    public String nueva(Model model) {
        model.addAttribute("reserva", new Reserva());
        model.addAttribute("tipos", TipoHabitacion.values());

        return "form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute Reserva reserva,
            BindingResult br, 
            Model model) {
        if (br.hasErrors()) {
            model.addAttribute("tipos", TipoHabitacion.values());
            return "form";
        }
        repo.save(reserva);
        return "redirect:/";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        repo.deleteById(id);
        return "redirect:/";
    }

}
