package com.proyectoReservas.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import org.springframework.format.annotation.DateTimeFormat;

/*
 
 */
@Entity
public class Reserva {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "El nombre no puede estar vacío")
    private String nombreCliente;
    
    @NotNull(message = "La fecha de entrada es obligatoria")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate fechaEntrada;
    @NotNull(message = "La fecha de salida es obligatoria")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate fechaSalida;
    
    @NotNull(message = "El precio es obligatorio")
    @Positive(message = "El precio debe ser positivo")
    private double precioPorNoche;
    
    @NotNull(message = "El tipo de habitación es obligatorio")
    @Enumerated(EnumType.STRING)
    private String tipoHabitacion;
    
    @NotNull(message = "La cantidad de noche es obligatoria")
    @Positive(message = " La cantidad de noche debe ser positiva")
    private long numeroNoches;

    public Reserva() {
        
    }

    public double calcularTotal() {
        return precioPorNoche * numeroNoches;
    }

    // Getters
    public String getNombreCliente() { return nombreCliente; }
    public LocalDate getFechaEntrada() { return fechaEntrada; }
    public LocalDate getFechaSalida() { return fechaSalida; }
    public double getPrecioPorNoche() { return precioPorNoche; }
    public String getTipoHabitacion() { return tipoHabitacion; }
    public long getNumeroNoches() { return numeroNoches; }
    
    
}
