package com.ejemplo.bombonas.controlador;

import com.ejemplo.bombonas.modelo.Pedido;
import com.ejemplo.bombonas.modelo.TipoBombona;
import com.ejemplo.bombonas.repositorio.PedidoRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class PedidoController {

    private final PedidoRepository repo;

    public PedidoController(PedidoRepository repo) {
        this.repo = repo;
    }

    @GetMapping("/")
    public String listar(Model model) {
        model.addAttribute("pedidos", repo.findAll());
        return "lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("pedido", new Pedido());
        model.addAttribute("tipos", TipoBombona.values());
        return "form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("pedido") Pedido pedido,
                          BindingResult br,
                          Model model) {
        if (br.hasErrors()) {
            // IMPORTANTE: devolvemos el mismo 'pedido' con sus valores -> mantiene la fecha y lo ya introducido
            model.addAttribute("tipos", TipoBombona.values());
            return "form";
        }
        repo.save(pedido);
        return "redirect:/";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        repo.deleteById(id);
        return "redirect:/";
    }
}
