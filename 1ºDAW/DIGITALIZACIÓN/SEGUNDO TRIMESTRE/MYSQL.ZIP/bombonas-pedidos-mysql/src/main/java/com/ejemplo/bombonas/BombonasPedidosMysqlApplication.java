package com.ejemplo.bombonas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BombonasPedidosMysqlApplication {
    public static void main(String[] args) {
        SpringApplication.run(BombonasPedidosMysqlApplication.class, args);
    }
}
