package com.ejemplo.bombonas.modelo;

public enum TipoBombona {
    NORMAL, LIGERA, CAMPING
}
