package com.ejemplo.bombonas.repositorio;

import com.ejemplo.bombonas.modelo.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {
}
