# bombonas-pedidos-mysql

Mini-app Spring Boot (Thymeleaf + JPA) con MySQL:
- Listar pedidos
- Añadir pedido (con validaciones)
- Eliminar pedido

Correcciones aplicadas:
- TipoBombona: NORMAL, LIGERA, CAMPING
- precio: Double (validación @Positive)
- Mensajes de validación en rojo
- La fecha (y el resto de campos) se mantiene cuando hay errores de validación
  (binding con th:field + @DateTimeFormat en LocalDate)

## Requisitos
- Java 17+
- MySQL Server en local (arrancado)
- Usuario/clave configurados en `application.properties`

## Base de datos
En `application.properties`:
- `createDatabaseIfNotExist=true` crea la BD `bombonas` si no existe.
- `spring.jpa.hibernate.ddl-auto=update` crea la tabla si no existe.

Ajusta:
- `spring.datasource.username`
- `spring.datasource.password`

## Ejecutar
- NetBeans: abrir como proyecto Maven y ejecutar.
- Consola: `mvn spring-boot:run`

URL: http://localhost:8080/
