package com.proyectoReservas.service;

/**
 *
 * @author DAW1-M
 */
import com.proyectoReservas.modelo.EstadoReserva;
import com.proyectoReservas.modelo.Reserva;
import com.proyectoReservas.repositorio.ReservaRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Contiene: 
 * - Validaciones 
 * - Cálculo de precio 
 * - Control de estados 
 * - Disponibilidad
 */
@Service
public class ProyectoReservasService {

    /* ================ REPOSITORIO ================= */
    private final ReservaRepository reservaRepo;

    public ProyectoReservasService(ReservaRepository reservaRepo) {
        this.reservaRepo = reservaRepo;
    }

    /* ================ LISTAR RESERVAS ================= */
    public List<Reserva> listarReservas() {
        return reservaRepo.findAll();
    }

    /* ================ BUSCAR POR ID ================= */
    public Reserva buscarPorId(Long id) {
        return reservaRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Reserva no encontrada"));
    }

    /* ================ ELIMINAR RESERVA ================= */
    public void eliminar(Long id) {

        Reserva r = buscarPorId(id);

        // No permitimos eliminar reservas confirmadas o finalizadas
        if (r.getEstado() == EstadoReserva.CONFIRMADA
                || r.getEstado() == EstadoReserva.FINALIZADA) {

            throw new RuntimeException("No se puede eliminar una reserva activa. Use cancelar.");
        }

        reservaRepo.deleteById(id);
    }

    /* ================ CREAR / GUARDAR RESERVA ================= */
    public void guardar(Reserva r) {

       /*  ---------- VALIDACIONES ---------- */
        if (r.getFechaEntrada() == null || r.getFechaSalida() == null) {
            throw new RuntimeException("Las fechas son obligatorias");
        }

        if (r.getCliente() == null || r.getHabitacion() == null) {
            throw new RuntimeException("Cliente y habitación son obligatorios");
        }

        if (r.getFechaEntrada().isAfter(r.getFechaSalida())) {
            throw new RuntimeException("La fecha de entrada no puede ser posterior a la de salida");
        }

        if (r.getFechaEntrada().isBefore(LocalDate.now())) {
            throw new RuntimeException("No se puede reservar en fechas pasadas");
        }

        /* ---------- CÁLCULO DE DÍAS ---------- */
        long dias = ChronoUnit.DAYS.between(
                r.getFechaEntrada(),
                r.getFechaSalida()
        );

        if (dias <= 0) {
            throw new RuntimeException("La reserva debe ser mínimo de una noche");
        }

        /* ---------- CÁLCULO DEL PRECIO ---------- */
        if (r.getHabitacion().getPrecioNoche() == null) {
            throw new RuntimeException("La habitación no tiene precio definido");
        }

        double precioPorNoche = r.getHabitacion().getPrecioNoche();
        double total = dias * precioPorNoche;

        r.setPrecioTotal(total);

        /* ---------- COMPROBAR DISPONIBILIDAD ---------- */
        List<Reserva> reservasHabitacion
                = reservaRepo.findByHabitacionId(r.getHabitacion().getId());

        for (Reserva existente : reservasHabitacion) {

            if (existente.getEstado() == EstadoReserva.CONFIRMADA) {

                boolean seSolapan
                        = r.getFechaEntrada().isBefore(existente.getFechaSalida())
                        && r.getFechaSalida().isAfter(existente.getFechaEntrada());

                if (seSolapan) {
                    throw new RuntimeException("La habitación ya está reservada en esas fechas");
                }
            }
        }

        /* ---------- ESTADO AUTOMÁTICO ---------- */
        r.setEstado(EstadoReserva.CONFIRMADA);

        /* ---------- GUARDAR EN BD ---------- */
        reservaRepo.save(r);
    }

    /* ================ CANCELAR RESERVA ================= */
    public void cancelarReserva(Long id) {

        Reserva r = buscarPorId(id);

        if (r.getEstado() == EstadoReserva.CANCELADA) {
            throw new RuntimeException("La reserva ya está cancelada");
        }

        if (r.getEstado() == EstadoReserva.FINALIZADA) {
            throw new RuntimeException("No se puede cancelar una reserva finalizada");
        }

        // Cancelación como mínimo 48h de antelación
        if (!LocalDate.now().isBefore(r.getFechaEntrada().minusDays(2))) {
            throw new RuntimeException("No se puede cancelar con menos de 48 horas");
        }

        r.setEstado(EstadoReserva.CANCELADA);

        reservaRepo.save(r);
    }

    /* ================ FINALIZAR RESERVA ================= */
    public void finalizarReserva(Long id) {

        Reserva r = buscarPorId(id);

        if (r.getEstado() != EstadoReserva.CONFIRMADA) {
            throw new RuntimeException("Solo se pueden finalizar reservas confirmadas");
        }

        r.setEstado(EstadoReserva.FINALIZADA);

        reservaRepo.save(r);
    }
}
