package com.proyectoReservas.controlador;

import com.proyectoReservas.modelo.Reserva;
import com.proyectoReservas.repositorio.ClienteRepository;
import com.proyectoReservas.repositorio.HabitacionRepository;
import com.proyectoReservas.service.ProyectoReservasService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/reservas")
public class ReservaController {

    /* ================ DEPENDENCIAS ================= */
    private final ProyectoReservasService reservaService;
    private final ClienteRepository clienteRepo;
    private final HabitacionRepository habitacionRepo;

    public ReservaController(ProyectoReservasService reservaService,
            ClienteRepository clienteRepo,
            HabitacionRepository habitacionRepo) {

        this.reservaService = reservaService;
        this.clienteRepo = clienteRepo;
        this.habitacionRepo = habitacionRepo;
    }

    /* ================ LISTAR ================= */
    @GetMapping
    public String listarReservas(Model model) {
        model.addAttribute("reservas", reservaService.listarReservas());
        return "inicio";
    }

    /* ================ FORMULARIO NUEVA RESERVA ================= */
    @GetMapping("/nueva")
    public String mostrarFormulario(Model model) {

        model.addAttribute("reserva", new Reserva());
        model.addAttribute("clientes", clienteRepo.findAll());
        model.addAttribute("habitaciones", habitacionRepo.findAll());

        return "form";
    }

    /* ================ GUARDAR RESERVA================= */
        @PostMapping("/guardar")
    public String guardarReserva(@Valid @ModelAttribute Reserva reserva,
                                 BindingResult result,
                                 Model model) {

        if (result.hasErrors()) {

            model.addAttribute("clientes", clienteRepo.findAll());
            model.addAttribute("habitaciones", habitacionRepo.findAll());

            return "form";
        }

        try {
            reservaService.guardar(reserva);
        } catch (RuntimeException e) {

            model.addAttribute("error", e.getMessage());
            model.addAttribute("clientes", clienteRepo.findAll());
            model.addAttribute("habitaciones", habitacionRepo.findAll());

            return "form";
        }

        return "redirect:/reservas";
    }


    /* ================ ELIMINAR RESERVA ================= */
    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        reservaService.eliminar(id);
        return "redirect:/reservas";
    }

    /* ================ CANCELAR RESERVA ================= */
    @PostMapping("/cancelar/{id}")
    public String cancelarReserva(@PathVariable Long id) {
        reservaService.cancelarReserva(id);
        return "redirect:/reservas";
    }

    /* ================ FINALIZAR RESERVA================= */
    @PostMapping("/finalizar/{id}")
    public String finalizarReserva(@PathVariable Long id) {
        reservaService.finalizarReserva(id);
        return "redirect:/reservas";
    }
}
