package com.proyectoReservas.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import com.proyectoReservas.modelo.Reserva;
import java.util.List;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {

    List<Reserva> findByHabitacionId(Long id);
}