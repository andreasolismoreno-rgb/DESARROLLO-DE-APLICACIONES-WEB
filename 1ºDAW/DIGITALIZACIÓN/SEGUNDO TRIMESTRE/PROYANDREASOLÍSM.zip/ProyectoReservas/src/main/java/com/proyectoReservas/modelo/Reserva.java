package com.proyectoReservas.modelo;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Entity

public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @FutureOrPresent(message = "La fecha de entrada debe ser hoy o futura")
    @NotNull(message = "La fecha de entrada es obligatoria")
    private LocalDate fechaEntrada;

    @FutureOrPresent(message = "La fecha de salida debe ser hoy o futura")
    @NotNull(message = "La fecha de salida es obligatoria")
    private LocalDate fechaSalida;

    // El precio lo calcula el sistema
    @Column(nullable = false)
    private Double precioTotal;
    //En service me calcula el precio 
    //    @NotNull(message = "El precio es obligatorio")
    //    @Positive(message = "El precio debe ser positivo")
    //    private Double precioTotal;

    @Enumerated(EnumType.STRING)
    private EstadoReserva estado;

    @ManyToOne
    @JoinColumn(name = "cliente_id", nullable = false)
    @NotNull(message = "El cliente es obligatorio")
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "habitacion_id", nullable = false)
    @NotNull(message = "La habitación es obligatoria")
    private Habitacion habitacion;

    public Reserva() {
    }

    // GETTERS Y SETTERS
    public Long getId() {
        return id;
    }

    public LocalDate getFechaEntrada() {
        return fechaEntrada;
    }

    public void setFechaEntrada(LocalDate fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    public LocalDate getFechaSalida() {
        return fechaSalida;
    }

    public void setFechaSalida(LocalDate fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    public Double getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(Double precioTotal) {
        this.precioTotal = precioTotal;
    }

    public EstadoReserva getEstado() {
        return estado;
    }

    public void setEstado(EstadoReserva estado) {
        this.estado = estado;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Habitacion getHabitacion() {
        return habitacion;
    }

    public void setHabitacion(Habitacion habitacion) {
        this.habitacion = habitacion;
    }
}
