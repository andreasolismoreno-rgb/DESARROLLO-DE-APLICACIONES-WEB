 package hotel;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/*
 
 */

public class Reserva {
    private String nombreCliente;
    private LocalDate fechaEntrada;
    private LocalDate fechaSalida;
    private double precioPorNoche;
    private String tipoHabitacion;
    private long numeroNoches;

    public Reserva(String nombreCliente, LocalDate fechaEntrada, LocalDate fechaSalida,
                   double precioPorNoche, String tipoHabitacion) {
        this.nombreCliente = nombreCliente;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        this.precioPorNoche = precioPorNoche;
        this.tipoHabitacion = tipoHabitacion;
        this.numeroNoches = ChronoUnit.DAYS.between(fechaEntrada, fechaSalida);
    }

    public double calcularTotal() {
        return precioPorNoche * numeroNoches;
    }

    // Getters
    public String getNombreCliente() { return nombreCliente; }
    public LocalDate getFechaEntrada() { return fechaEntrada; }
    public LocalDate getFechaSalida() { return fechaSalida; }
    public double getPrecioPorNoche() { return precioPorNoche; }
    public String getTipoHabitacion() { return tipoHabitacion; }
    public long getNumeroNoches() { return numeroNoches; }
}
