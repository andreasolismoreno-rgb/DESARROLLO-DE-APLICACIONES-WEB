package hotel;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Servlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
         // Cargar archivo desde el classpath (src/resources/)
        InputStream is = getClass().getClassLoader().getResourceAsStream("datos.csv");

        if (is == null) {
            throw new ServletException("No se encontró datos.csv en src/resources/");
        }

        List<Reserva> lista = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String linea;
            boolean primera = true;
            
            while ((linea = br.readLine()) != null) {
                if (primera) { // saltar encabezado
                    primera = false;
                    continue;
                }
                
                String[] c = linea.split(",");
                
                String nombre = c[0];
                LocalDate entrada = LocalDate.parse(c[1]);
                LocalDate salida = LocalDate.parse(c[2]);
                double precio = Double.parseDouble(c[3]);
                String tipo = c[4];
                
                Reserva r = new Reserva(nombre, entrada, salida, precio, tipo);
                lista.add(r);
            }
        }

        req.setAttribute("reservas", lista);

        RequestDispatcher dispatcher = req.getRequestDispatcher("listaReservas.jsp");
        dispatcher.forward(req, resp);
    }
    
    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          
         String nombre = null;
         String tipo = null;
         Double precio = null;
         String salidaStr = null;
         String entradaStr = null;
         LocalDate entrada = null;
         LocalDate salida = null;
         String mensaje = "";
        
        try{
         nombre = request.getParameter("nombre");
         entradaStr = request.getParameter("entrada");
         if (entrada.compareTo(LocalDate.now())<0) {
                throw new IllegalAccessError("La fecha no puede ser anterior a la actual");
            }
         salidaStr = request.getParameter("salida");
         entrada = LocalDate.parse(entradaStr);
         salida = LocalDate.parse(salidaStr);
         tipo = request.getParameter("tipo");
         precio = Double.parseDouble(request.getParameter("precio"));
        
        
        
      
        
        }catch (IllegalArgumentException e){
            response.getWriter().print("");
        }
        
            
            
        
        
        Reserva reserva = new Reserva(nombre, entrada, salida, precio, tipo);

        request.setAttribute("reserva", reserva);
        RequestDispatcher dispatcher = request.getRequestDispatcher("confirmacion.jsp");
        dispatcher.forward(request, response);
    }
}
