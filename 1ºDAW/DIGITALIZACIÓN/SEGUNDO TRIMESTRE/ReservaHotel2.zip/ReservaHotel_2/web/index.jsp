<%-- 
    Document   : index
    Created on : 13 nov 2025, 9:15:26
    Author     : DAW1-M
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reserva de Hotel</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="page">
        <div class="app-card">
            <header class="app-header">
                <h1 class="app-title">
                    <span class="icon">🏨</span>
                    Reserva de hotel
                </h1>
                <p class="app-subtitle">
                    Completa los datos de tu estancia y calcula el importe total de la reserva.
                </p>
            </header>

            <form action="Servlet" method="post">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nombre">Nombre del cliente</label>
                        <input type="text" id="nombre" name="nombre" required>
                    </div>

                    <div class="form-group">
                        <label for="entrada">Fecha de entrada</label>
                        <input type="date" id="entrada" name="entrada" required>
                    </div>

                    <div class="form-group">
                        <label for="salida">Fecha de salida</label>
                        <input type="date" id="salida" name="salida" required>
                    </div>

                    <div class="form-group">
                        <label for="tipo">Tipo de habitación</label>
                        <select id="tipo" name="tipo">
                            <option value="Individual">Individual</option>
                            <option value="Doble">Doble</option>
                            <option value="Suite">Suite</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="precio">Precio por noche (€)</label>
                        <input type="number" id="precio" name="precio" step="0.01" min="0" required>
                    </div>
                </div>

                <div class="form-footer">
                    <p class="form-helper">
                        Revisa bien las fechas: el número de noches se calculará automáticamente en el resumen de la reserva.
                    </p>
                    <input type="submit" value="Confirmar reserva">
                </div>
            </form>
        </div>
    </div>
</body>
</html>
