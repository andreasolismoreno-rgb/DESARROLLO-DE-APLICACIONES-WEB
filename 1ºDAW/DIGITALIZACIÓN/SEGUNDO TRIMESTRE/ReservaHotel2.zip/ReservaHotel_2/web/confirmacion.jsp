<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Confirmación de reserva</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

    <h2 style="color: green; font-family: Arial;">
        ✔ Reserva completada
    </h2>

    <%
        hotel.Reserva r = (hotel.Reserva) request.getAttribute("reserva");
    %>

    <div class="page">
        <div class="confirm-card">
            <header>
                <div class="confirm-badge">
                    ✨ Reserva confirmada
                </div>
                <h1 class="confirm-title">Resumen de tu estancia</h1>
                <p class="text-muted">
                    Estos son los datos de la reserva que acabas de realizar en nuestro hotel.
                </p>
            </header>

            <ul class="confirm-details">
                <li>
                    <span class="label">Cliente</span>
                    <span><%= r.getNombreCliente() %></span>
                </li>
                <li>
                    <span class="label">Fecha de entrada</span>
                    <span><%= r.getFechaEntrada() %></span>
                </li>
                <li>
                    <span class="label">Fecha de salida</span>
                    <span><%= r.getFechaSalida() %></span>
                </li>
                <li>
                    <span class="label">Tipo de habitación</span>
                    <span><%= r.getTipoHabitacion() %></span>
                </li>
                <li>
                    <span class="label">Precio total</span>
                    <span><%= r.getPrecioPorNoche() * r.getNumeroNoches() %> €</span>
                </li>
            </ul>

            <div class="form-footer" style="margin-top: 2.25rem;">
                <p class="text-muted">
                    Si necesitas modificar algún dato, puedes volver al formulario y realizar
                    una nueva reserva.
                </p>
                <a href="index.jsp" class="btn-primary">Hacer otra reserva</a>
            </div>
        </div>
    </div>

</body>
</html>
