import com.miempresa.modelo.Genero;
import com.miempresa.modelo.Libro;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/LibroServlet")
public class LibroServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("Metodo doPost");
        // 1️⃣ Recoger parámetros del formulario
        String titulo = request.getParameter("titulo");
        String autor = request.getParameter("autor");
        double precio = Double.parseDouble(request.getParameter("precio"));
        int paginas = Integer.parseInt(request.getParameter("paginas"));
        Genero genero = Genero.valueOf(request.getParameter("genero"));

        // 2️⃣ Crear objeto Libro
        Libro libro = new Libro(titulo, autor, precio, paginas, genero);

        // 3️⃣ Generar la respuesta HTML
        response.setContentType("text/html; charset=UTF-8");
        response.getWriter().println("<h1>Libro introducido correctamente</h1>");
        response.getWriter().println("<p><b>Título:</b> " + libro.getTitulo() + "</p>");
        response.getWriter().println("<p><b>Autor:</b> " + libro.getAutor() + "</p>");
        response.getWriter().println("<p><b>Precio:</b> " + libro.getPrecio() + " €</p>");
        response.getWriter().println("<p><b>Páginas:</b> " + libro.getPaginas() + "</p>");
        response.getWriter().println("<p><b>Género:</b> " + libro.getGenero() + "</p>");
        
        // Enlace para volver al formulario
        response.getWriter().println("<br><a href='index.html'>Introducir otro libro</a>");
    }
}