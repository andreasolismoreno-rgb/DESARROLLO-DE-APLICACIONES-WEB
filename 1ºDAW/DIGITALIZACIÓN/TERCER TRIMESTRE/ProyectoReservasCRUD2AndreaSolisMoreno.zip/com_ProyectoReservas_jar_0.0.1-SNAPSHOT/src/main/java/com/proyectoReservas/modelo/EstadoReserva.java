package com.proyectoReservas.modelo;
public enum EstadoReserva {

    CONFIRMADA,CANCELADA,FINALIZADA
}
