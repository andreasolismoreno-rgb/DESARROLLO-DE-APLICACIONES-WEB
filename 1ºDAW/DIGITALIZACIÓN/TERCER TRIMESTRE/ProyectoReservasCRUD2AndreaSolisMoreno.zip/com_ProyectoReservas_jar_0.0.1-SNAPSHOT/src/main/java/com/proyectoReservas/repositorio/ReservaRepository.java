package com.proyectoReservas.repositorio;

import com.proyectoReservas.modelo.Reserva;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {

    List<Reserva> findByHabitacionId(Long id);

    @Query("SELECT r FROM Reserva r WHERE r.habitacion.id = :habitacionId "
            + "AND r.fechaSalida > :entrada AND r.fechaEntrada < :salida")
    List<Reserva> reservasSolapadas(
            @Param("habitacionId") Long habitacionId,
            @Param("entrada") LocalDate entrada,
            @Param("salida") LocalDate salida
    );
}
