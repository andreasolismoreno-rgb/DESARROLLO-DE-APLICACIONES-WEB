package com.proyectoReservas;

import com.proyectoReservas.modelo.*;
import com.proyectoReservas.repositorio.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final HabitacionRepository habRepo;
    private final ClienteRepository clienteRepo;

    public DataInitializer(HabitacionRepository habRepo, ClienteRepository clienteRepo) {
        this.habRepo = habRepo;
        this.clienteRepo = clienteRepo;
    }

    @Override
    public void run(String... args) throws Exception {
        // Inicializar Habitaciones (esto déjalo si quieres tener datos)
        if (habRepo.count() == 0) {
            habRepo.save(new Habitacion(101, TipoHabitacion.SUITE, 150.0));
            habRepo.save(new Habitacion(102, TipoHabitacion.DOBLE, 80.0));
            habRepo.save(new Habitacion(103, TipoHabitacion.INDIVIDUAL, 45.0));
        }
        if (clienteRepo.count() == 0) {
            clienteRepo.save(new Cliente("Admin", "Prueba", "12345678Z", "admin@hotel.com", "912345678"));
        }

    }
}
