package com.proyectoReservas.controlador;

import com.proyectoReservas.modelo.Cliente;
import com.proyectoReservas.service.ProyectoReservasService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/clientes")
public class ClienteController {

    @Autowired
    private ProyectoReservasService service; // Cambiado a 'service' para consistencia

    @GetMapping
    public String listar(Model model) {
        List<Cliente> lista = service.listarTodosLosClientes();
        model.addAttribute("clientes", lista);
        return "listaClientes";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("cliente", new Cliente());
        return "formClientes";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Cliente cliente = service.listarTodosLosClientes().stream()
                .filter(c -> c.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (cliente == null) {
            return "redirect:/clientes";
        }

        model.addAttribute("cliente", cliente);
        return "formClientes";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("cliente") Cliente cliente, BindingResult result) {
        if (result.hasErrors()) {
            return "formClientes";
        }
        service.guardarCliente(cliente);
        return "redirect:/clientes?ok";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.eliminarCliente(id);
        return "redirect:/clientes?eliminado";
    }
}
