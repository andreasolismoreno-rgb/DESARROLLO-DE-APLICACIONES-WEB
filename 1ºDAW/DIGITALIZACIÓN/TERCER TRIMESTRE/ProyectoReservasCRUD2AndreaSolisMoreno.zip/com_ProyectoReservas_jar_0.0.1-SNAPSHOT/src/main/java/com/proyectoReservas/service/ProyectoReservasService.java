package com.proyectoReservas.service;

import com.proyectoReservas.modelo.*;
import com.proyectoReservas.repositorio.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class ProyectoReservasService {

    private final ReservaRepository reservaRepo;
    private final HabitacionRepository habRepo;
    private final ClienteRepository clienteRepo;

    public ProyectoReservasService(ReservaRepository reservaRepo,
            HabitacionRepository habRepo,
            ClienteRepository clienteRepo) {
        this.reservaRepo = reservaRepo;
        this.habRepo = habRepo;
        this.clienteRepo = clienteRepo;
    }

    public List<Reserva> listarTodas() {
        return reservaRepo.findAll();
    }

    public Reserva buscarPorId(Long id) {
        return reservaRepo.findById(id).orElse(null);
    }

    public void eliminar(Long id) {
        reservaRepo.deleteById(id);
    }

    @Transactional
    public void procesarYGuardarReserva(Reserva r, boolean esNuevo) {

        // CLIENTE
        if (esNuevo) {
            if (r.getCliente() == null) {
                throw new RuntimeException("Debes rellenar los datos del cliente");
            }
            Cliente nuevo = clienteRepo.save(r.getCliente());
            r.setCliente(nuevo);
        } else {
            if (r.getCliente() == null || r.getCliente().getId() == null) {
                throw new RuntimeException("Debes seleccionar un cliente");
            }

            Cliente existente = clienteRepo.findById(r.getCliente().getId())
                    .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
            r.setCliente(existente);
        }

        // HABITACIÓN
        if (r.getHabitacion() == null || r.getHabitacion().getId() == null) {
            throw new RuntimeException("Debes seleccionar una habitación");
        }

        Habitacion h = habRepo.findById(r.getHabitacion().getId())
                .orElseThrow(() -> new RuntimeException("Habitación no encontrada"));

        r.setHabitacion(h);

        // FECHAS
        if (r.getFechaEntrada() == null || r.getFechaSalida() == null) {
            throw new RuntimeException("Debes indicar las fechas");
        }

        if (!r.getFechaSalida().isAfter(r.getFechaEntrada())) {
            throw new RuntimeException("La fecha de salida debe ser posterior");
        }

        // SOLAPADAS
        List<Reserva> solapadas = reservaRepo.reservasSolapadas(
                h.getId(),
                r.getFechaEntrada(),
                r.getFechaSalida()
        );

        if (r.getId() != null) {
            solapadas = solapadas.stream()
                    .filter(res -> !res.getId().equals(r.getId()))
                    .toList();
        }

        if (!solapadas.isEmpty()) {
            throw new RuntimeException("La habitación ya está ocupada en esas fechas");
        }

        // PRECIO
        long noches = ChronoUnit.DAYS.between(r.getFechaEntrada(), r.getFechaSalida());
        r.setPrecioTotal(noches * h.getPrecioNoche());

        reservaRepo.save(r);
    }

    public List<Cliente> listarTodosLosClientes() {
        return clienteRepo.findAll();
    }

    public List<Habitacion> listarHabitaciones() {
        return habRepo.findAll();
    }

    public void guardarHabitacion(Habitacion h) {
        habRepo.save(h);
    }

    public void eliminarHabitacion(Long id) {
        habRepo.deleteById(id);
    }

    public void guardarCliente(Cliente c) {
        clienteRepo.save(c);
    }

    public void eliminarCliente(Long id) {
        clienteRepo.deleteById(id);
    }
}
