package com.proyectoReservas.modelo;

public enum TipoHabitacion {
        INDIVIDUAL, DOBLE, SUITE
}
