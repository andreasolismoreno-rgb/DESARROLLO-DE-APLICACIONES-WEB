package com.proyectoReservas.controlador;

import com.proyectoReservas.modelo.Habitacion;
import com.proyectoReservas.service.ProyectoReservasService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/habitaciones")
public class HabitacionController {

    private final ProyectoReservasService service;

    public HabitacionController(ProyectoReservasService service) {
        this.service = service;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("habitaciones", service.listarHabitaciones());
        return "listaHabitaciones";
    }

    @GetMapping("/nueva")
    public String nueva(Model model) {
        model.addAttribute("habitacion", new Habitacion());
        return "formHabitaciones";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("habitacion") Habitacion habitacion, BindingResult result) {
        if (result.hasErrors()) {
            return "formHabitaciones";
        }

        service.guardarHabitacion(habitacion);
        return "redirect:/habitaciones?ok";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.eliminarHabitacion(id);
        return "redirect:/habitaciones?eliminado";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Habitacion h = service.listarHabitaciones().stream()
                .filter(hab -> hab.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (h == null) {
            return "redirect:/habitaciones";
        }

        model.addAttribute("habitacion", h);
        return "formHabitaciones";
    }
}
