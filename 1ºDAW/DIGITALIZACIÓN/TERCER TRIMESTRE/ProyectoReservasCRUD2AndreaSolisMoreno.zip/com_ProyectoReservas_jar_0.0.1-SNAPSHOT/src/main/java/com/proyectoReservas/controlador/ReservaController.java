package com.proyectoReservas.controlador;

import com.proyectoReservas.modelo.*;
import com.proyectoReservas.service.ProyectoReservasService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/reservas")
public class ReservaController {

    private final ProyectoReservasService service;

    public ReservaController(ProyectoReservasService service) {
        this.service = service;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("reservas", service.listarTodas());
        return "inicio";
    }

    @GetMapping("/nueva")
    public String nueva(Model model) {
        cargarFormulario(model, new Reserva());
        return "form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("reserva") Reserva reserva,
            BindingResult result,
            @RequestParam(required = false, defaultValue = "false") boolean esNuevo,
            Model model) {

        // 🔥 VALIDAR CLIENTE NUEVO MANUALMENTE
        if (esNuevo) {
            Cliente c = reserva.getCliente();

            if (c.getNombre() == null || c.getNombre().isBlank()) {
                model.addAttribute("error", "El nombre es obligatorio");
            } else if (c.getApellidos() == null || c.getApellidos().isBlank()) {
                model.addAttribute("error", "Los apellidos son obligatorios");
            } else if (!c.getDni().matches("\\d{8}[A-Z]")) {
                model.addAttribute("error", "El DNI debe tener 8 números y una letra mayúscula");
            } else if (c.getTelefono() == null || !c.getTelefono().matches("\\d{9}")) {
                model.addAttribute("error", "El teléfono debe tener 9 números");
            }
        }

        if (result.hasErrors() || model.containsAttribute("error")) {
            model.addAttribute("clientes", service.listarTodosLosClientes());
            model.addAttribute("habitaciones", service.listarHabitaciones());
            return "form";
        }

        try {
            service.procesarYGuardarReserva(reserva, esNuevo);
        } catch (RuntimeException e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("clientes", service.listarTodosLosClientes());
            model.addAttribute("habitaciones", service.listarHabitaciones());
            return "form";
        }

        return "redirect:/reservas?ok";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return "redirect:/reservas?eliminado";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Reserva reserva = service.buscarPorId(id);

        if (reserva == null) {
            return "redirect:/reservas";
        }

        cargarFormulario(model, reserva);
        return "form";
    }

    private void cargarFormulario(Model model, Reserva reserva) {
        if (reserva.getCliente() == null) {
            reserva.setCliente(new Cliente());
        }
        if (reserva.getHabitacion() == null) {
            reserva.setHabitacion(new Habitacion());
        }

        model.addAttribute("reserva", reserva);
        model.addAttribute("habitaciones", service.listarHabitaciones());
        model.addAttribute("clientes", service.listarTodosLosClientes());
    }
}
