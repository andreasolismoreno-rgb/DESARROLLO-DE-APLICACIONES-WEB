const btnVer = document.getElementById("btnVer");
const btnReiniciar = document.getElementById("btnReiniciar");
const inputTexto = document.getElementById("inputTexto");

for (let i = 0; i < botones.length; i++) {
    btnVer[i].addEventListener("click", function () {
        inputTexto.textContent = "Has elegido: " + btnVer[i].textContent;
        const select = btnVer.value;
        if (select === "") {
            inputTexto.textContent = "Debes seleccionar un destino";
            inputTexto.style.color = "black";
        }
        btnVer.addEventListener("click", comprobarMnesaje);
        btnReiniciar.addEventListener("click", function () {

            inputTexto.textContent = "Destino elegido";
            btnReiniciar.classList.add("correcto");
            inputTexto.forEach(c => c.style.backgroundColor = "");
        });
    }); 
}