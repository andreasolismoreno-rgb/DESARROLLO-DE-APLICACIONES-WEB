const cuadro = document.getElementById("cuadro");
cuadro.addEventListener("mouseover", function () { 
    cuadro.style.backgroundColor = "orange"; 
      estado1.textContent = "Ratón dentro";

});
cuadro.addEventListener("mouseout", function () { 
    cuadro.style.backgroundColor = "white"; 
});

const estado1 = document.getElementById("estado");
estado1.addEventListener("mouseover", function () { 
        cuadro.style.backgroundColor = "orange"; 
  estado1.textContent = "Has entrado en la zona";
});

const estado2 = document.getElementById("estado");
estado2.addEventListener("mouseout", function () { 
        cuadro.style.backgroundColor = "white"; 

  estado2.textContent = "Has salido de la zona";
});