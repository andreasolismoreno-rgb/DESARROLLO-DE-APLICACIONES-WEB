const bateria = document.getElementById("bateria");
const btnComprobar = document.getElementById("btnComprobar");
const resultadoBateria = document.getElementById("resultadoBateria");
function comprobarBateria() {
const valor = bateria.value;
if (valor === "") {
resultadoBateria.textContent = "Debes introducir un porcentaje";
resultadoBateria.style.color = "black"; 
} else {

const bat = Number(valor);
if (bat < 20) {
resultadoBateria.textContent = "Batería baja";
resultadoBateria.style.color = "red";
}
else if (bat >= 20 && bat <= 60) {
resultadoBateria.textContent = "Batería media";
resultadoBateria.style.color = "black";
}
else {
resultadoBateria.textContent = "Batería alta";
resultadoBateria.style.color = "green";
}
}
}

btnComprobar.addEventListener("click", comprobarBateria);

window.addEventListener("keydown", function(event) {
if (event.key.toUpperCase() === "B") {
bateria.value = "";
resultadoBateria.textContent = "";
}
});