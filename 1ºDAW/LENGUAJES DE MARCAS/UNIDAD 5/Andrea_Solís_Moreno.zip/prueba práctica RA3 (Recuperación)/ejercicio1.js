const tarjeta = document.getElementById("tarjeta");
alert ("Elemento padre:", tarjeta.parentElement);
const btnInfo = document.getElementById("btnInfo");
alert( btnInfo.textContent);
const resultado = document.getElementById("resultado");
alert( resultado.textContent);