const formulario = document.getElementById("formulario");
const resultado = document.getElementById("resultado");
const campoProducto = document.getElementById("producto");
const campoCantidad = document.getElementById("cantidad");
const campoResponsable = document.getElementById("responsable");
const campoTurno = document.getElementById("turno");
const campoConfirmacion = document.getElementById("confirmacion");
formulario.addEventListener("submit", function (event) {
    event.preventDefault();
    const campos = [campoProducto, campoCantidad, campoResponsable, campoTurno];
    campos.forEach(c => c.style.backgroundColor = "");
    resultado.classList.remove("error", "correcto");
    resultado.textContent = "";

    let mensajeError = "";
    let campoConError = null;
    if (campoProducto.value.trim() === "") {
        mensajeError = "Hay datos incorrectos en el formulario";
        campoConError = campoProducto;
        
    } else if (campoCantidad.value === "" || Number(campoCantidad.value) < 0) {
        mensajeError = "Hay datos incorrectos en el formulario"; 
        campoConError = campoCantidad;
    } else if  (campoResponsable.value.trim() === "") {
        mensajeError = "Hay datos incorrectos en el formulario";
        campoConError = campoResponsable;
    } else if (campoTurno.value === "") {
        mensajeError = "Hay datos incorrectos en el formulario"; 
        campoConError = campoTurno;
    } else if (!campoConfirmacion.checked) {
        mensajeError = "Hay datos incorrectos en el formulario";
    }
    if (mensajeError !== "") {
        resultado.textContent = mensajeError;
        resultado.classList.add("error");
        if (campoConError) {
            campoConError.style.backgroundColor = "red";
        }
    } else {
        resultado.textContent = "Formulario enviado correctamente";
        resultado.classList.add("correcto");
        campos.forEach(c => c.style.backgroundColor = "");
    }
});