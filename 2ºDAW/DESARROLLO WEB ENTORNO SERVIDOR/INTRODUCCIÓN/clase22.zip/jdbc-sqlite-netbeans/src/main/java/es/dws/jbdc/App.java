package es.dws.jbdc;

import java.sql.Connection;

public class App {

    public static void main(String[] args) {
        Database.crearTabla();
        try (Connection con = Database.conectar()) {
            System.out.println("Conexión correcta");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
