/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio3;

import java.util.Scanner;

/* SCANNER!. Lee tres números enteros y muestra cuál es el mayor. 
Debe funcionar también si hay números iguales.
 */
public class Ejercicio3 {
    
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        int mayor = a;
        if (b > mayor) mayor = b;
        if (c > mayor) mayor = c;
        System.out.println("El mayor es: " + mayor);
        
    }
    
    
    /*
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt(), b = sc.nextInt(), c = sc.nextInt();

        if (a >= b && a >= c)
            System.out.println("El mayor es: " + a);
        else if (b >= a && b >= c)
            System.out.println("El mayor es: " + b);
        else
            System.out.println("El mayor es: " + c);
 */   
}
