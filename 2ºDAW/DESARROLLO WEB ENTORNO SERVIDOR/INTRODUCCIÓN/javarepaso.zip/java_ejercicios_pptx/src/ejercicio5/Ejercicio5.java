/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio5;

/*Dado el array {8, 3, 11, 5, 2}, muestra el mínimo, el máximo y la media.
Inicializa mínimo y máximo con el primer elemento.
 */
public class Ejercicio5 {
        
        
    public static void main(String[] args) {
        int[] datos = {8, 3, 11, 5, 2};
        int min = datos[0], max = datos[0], suma = 0;
        for (int valor : datos) {
            if (valor < min) {
                min = valor;
            }
            if (valor > max) {
                max = valor;
            }
            suma += valor;
        }
        double media = (double) suma / datos.length;
        System.out.println("Min: " + min + " Max: " + max);
        System.out.println("Media: " + media);
    }

//    int[] numeros = {8, 3, 11, 5, 2};
//
//    int minimo = numeros[0];
//    int maximo = numeros[0];
//    int suma = 0;
//
//    for (int i = 0;i< numeros.length ;i++) {
//            if (numeros[i] < minimo) {
//            minimo = numeros[i];
//        }
//        if (numeros[i] > maximo) {
//            maximo = numeros[i];
//        }
//        suma = suma + numeros[i];
//    }
//
//    double media = (double) suma / numeros.length;
//
//    System.out.println ( "Mínimo: " + minimo);
//    System.out.println ( "Máximo: " + maximo);
//    System.out.println ("Media: " + media);
//    }
}
