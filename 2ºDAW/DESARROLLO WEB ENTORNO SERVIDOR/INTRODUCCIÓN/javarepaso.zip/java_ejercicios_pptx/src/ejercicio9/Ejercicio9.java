/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio9;

/*Pide dos enteros y muestra su división. Controla una entrada no numérica y 
la división entre cero sin cerrar el programa con error. 
Captura InputMismatchException y ArithmeticException.
 */
import java.util.Scanner;
import java.util.InputMismatchException;

public class Ejercicio9 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            int a = sc.nextInt();
            int b = sc.nextInt();
            System.out.println("Resultado: " + (a / b));
        } catch (InputMismatchException e) {
            System.out.println("Debes introducir enteros");
        } catch (ArithmeticException e) {
            System.out.println("No se puede dividir entre cero");
        } finally {
           
        }
    }
}
