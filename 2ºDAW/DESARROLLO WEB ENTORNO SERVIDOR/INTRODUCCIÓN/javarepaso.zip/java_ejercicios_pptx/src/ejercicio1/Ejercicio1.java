/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio1;


/**
 *
 * @author daw2
 */
public class Ejercicio1 {

    /*Declar dos numeros enteros, 18 y 7. MUestra sy suma, resta, producto y división decimal. 
    
     */
    
    public static void main(String[] args) {
        int a = 18;
        int b = 7;
        
        System.out.println("La suma de 18 y 7 son: " + ( a + b ));
        System.out.println("La resta de 18 y 7 son: " + ( a - b ));
        System.out.println("La multiplicación de 18 y 7 son: " + ( a * b ));
        System.out.println("La división de 18 y 7 son: " + ((double) a / b));
    }
    
    
}
