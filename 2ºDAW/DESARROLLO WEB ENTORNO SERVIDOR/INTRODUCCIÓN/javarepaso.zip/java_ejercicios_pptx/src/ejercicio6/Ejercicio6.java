/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio6;

/**
 * Pide una palabra y determina si es un palíndromo, ignorando mayúsculas y
 * minúsculas. Compara la palabra con su versión invertida.
 */
import java.util.Scanner;

public class Ejercicio6 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String texto = sc.nextLine().toLowerCase();
        String inversa = new StringBuilder(texto).reverse().toString();
        if (texto.equals(inversa)) {
            System.out.println("Es palíndromo");
        } else {
            System.out.println("No es palíndromo");
        }

//        Scanner sc = new Scanner(System.in);
//
//        String palabra = sc.nextLine().toLowerCase();
//        String invertida = "";
//
//        for (int i = palabra.length() - 1; i >= 0; i--) {
//            invertida += palabra.charAt(i);
//        }
//
//        if (palabra.equals(invertida))
//            System.out.println("Es palíndromo");
//        else
//            System.out.println("No es palíndromo");
    }
}
