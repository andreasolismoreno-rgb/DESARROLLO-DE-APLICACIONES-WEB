/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2;

import java.util.Scanner;

/*Pide el nombre y la edad. Muestra cuántos años tendrá la persona dentro de cinco años
 */
public class Ejercicio2 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
        
        System.out.println("Dime tu nombre: " );
        String nombre = sc.nextLine();
        
        System.out.println("Dime tu edad: " );
        int edad = sc.nextInt();
       
        System.out.println(nombre + ", en cinco años tendrás " + (edad + 5) + " años");
    }
}
