/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio8;

/*Crea una clase Cuenta con titular y saldo. Añade ingresar, retirar y mostrarSaldo. 
No permitas retirar más dinero del disponible. Encapsula saldo y devuelve boolean desde retirar.
 */
class Cuenta {

    private String titular;
    private double saldo;

    Cuenta(String titular) {
        this.titular = titular;
    }

    void ingresar(double cantidad) {
        if (cantidad > 0) {
            saldo += cantidad;
        }
    }

    boolean retirar(double cantidad) {
        if (cantidad <= 0 || cantidad > saldo) {
            return false;
        }
        saldo -= cantidad;
        return true;
    }

    void mostrarSaldo() {
        System.out.println(titular + ": " + saldo + " €");
    }

//
//public class Cuenta {
//    private String titular;
//    private double saldo;
//
//    public Cuenta(String titular, double saldo) {
//        this.titular = titular;
//        this.saldo = saldo;
//    }
//
//    public void ingresar(double cantidad) {
//        saldo += cantidad;
//    }
//
//    public boolean retirar(double cantidad) {
//        if (cantidad > saldo) return false;
//        saldo -= cantidad;
//        return true;
//    }
//
//    public void mostrarSaldo() {
//        System.out.println("Saldo: " + saldo);
//    }
//
//    public static void main(String[] args) {
//        Cuenta c = new Cuenta("Alba", 100);
//        c.ingresar(40);
//        System.out.println(c.retirar(200));
//        c.mostrarSaldo();
//    }
//}
}
