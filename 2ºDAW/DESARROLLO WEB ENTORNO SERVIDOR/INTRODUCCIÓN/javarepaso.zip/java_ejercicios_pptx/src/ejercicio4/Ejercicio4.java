/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

import java.util.Scanner;

/*Pide un número positivo n y calcula la suma de los números pares comprendidos entre 1 y n. 
Recorre solo los pares o comprueba cada número con %
 */
public class Ejercicio4 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int suma = 0;
        for (int i = 2; i <= n; i += 2) {
            suma = suma + i;
        }
        System.out.println("La suma de pares es: " + suma);
    }
}
