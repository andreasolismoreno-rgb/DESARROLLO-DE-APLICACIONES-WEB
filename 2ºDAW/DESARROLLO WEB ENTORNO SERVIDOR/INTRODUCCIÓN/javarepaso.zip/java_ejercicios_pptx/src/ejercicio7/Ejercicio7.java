/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio7;

import java.util.Scanner;

/*Crea un método contarVocales(String texto) que devuelva el número de vocales. Pruébalo desde main. 
Convierte el texto a minúsculas y recórrelo carácter a carácter.
 */
public class Ejercicio7 {

    static int contarVocales(String texto) {
        int total = 0;
        for (char c : texto.toLowerCase().toCharArray()) {
            if ("aeiouáéíóú".indexOf(c) >= 0) {
                total++;
            }
        }
        return total;
    }

    public static void main(String[] args) {
        System.out.println(contarVocales("Programación"));
    }

//    static int contarVocales(String texto) {
//        int cont = 0;
//        texto = texto.toLowerCase();
//        for (int i = 0; i < texto.length(); i++) {
//            if ("aeiou".indexOf(texto.charAt(i)) >= 0) {
//                cont++;
//            }
//        }
//        return cont;
//    }
//
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        System.out.println(contarVocales(sc.nextLine()));
//    }
}
