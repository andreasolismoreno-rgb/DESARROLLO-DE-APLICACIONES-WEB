/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio15;

/*Retirada de stock no válida. Impide que una operación deje existencias negativas.
Dentro de main, parte de un stock de 5 unidades e intenta retirar 8. Si el resultado sería negativo, 
lanza una excepción con el mensaje «Stock insuficiente» y captúrala para mostrar el mensaje sin detener 
bruscamente el programa.

 */
public class Ejercicio15 {

    public static void main(String[] args) {
        int stock = 5;
        int retirada = 8;
        try {
            if (retirada > stock) {throw new IllegalArgumentException( "Stock insuficiente");
            }
            stock -= retirada;
            System.out.println("Quedan " + stock);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("El programa continúa");
    }

}

/*
EXPLICACIÓN:

int stock = 5;
Guardamos el stock inicial.

int retirada = 8;
Indicamos que queremos retirar 8 unidades.

try
Intentamos realizar la operación que puede producir un error.

if (retirada > stock)
Comprobamos si queremos retirar más unidades de las disponibles.

throw new IllegalArgumentException("Stock insuficiente");
Lanzamos una excepción porque no hay suficiente stock.

catch (IllegalArgumentException e)
Capturamos la excepción para que el programa no se detenga.

e.getMessage()
Obtiene el mensaje de la excepción: "Stock insuficiente".

System.out.println("El programa continúa");
Demostramos que, aunque haya habido un error, el programa continúa.


RESULTADO:

Stock insuficiente
El programa continúa


IDEA PRINCIPAL:

try → intenta ejecutar el código.

throw → lanza una excepción.

catch → captura la excepción.

getMessage() → obtiene el mensaje del error.
*/