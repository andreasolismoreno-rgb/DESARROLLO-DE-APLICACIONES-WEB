/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio14;

import java.util.List;

/*Leer una edad con seguridad. Evita que una entrada no numérica termine el programa.
Dentro de main, guarda el texto «veinte» e intenta convertirlo a int. Si no es posible, 
muestra «La edad debe ser un número». Después repite la prueba con el texto «20».

 */
public class Ejercicio14 {

    public static void main(String[] args) {
        for (String texto : List.of("veinte", "20")) {
            try {
                int edad = Integer.parseInt(texto);
                System.out.println("Edad: " + edad);
            } catch (NumberFormatException e) {
                System.out.println("La edad debe ser un número");
            }
        }
    }

}

/*
EXPLICACIÓN:

for (String texto : List.of("veinte", "20"))
Recorremos los dos textos para probar la conversión.

try
Intentamos ejecutar el código que puede dar error.

Integer.parseInt(texto)
Convierte un texto a un número entero.

"20" → 20

catch (NumberFormatException e)
Si el texto no se puede convertir a número, capturamos el error.

System.out.println("La edad debe ser un número");
Mostramos el mensaje cuando el texto no es válido.


RESULTADO:

La edad debe ser un número
Edad: 20


IDEA PRINCIPAL:

try → intentamos hacer algo.

catch → controlamos el error si ocurre.

Integer.parseInt() → convierte String a int.

NumberFormatException → aparece cuando el texto no es un número.
*/