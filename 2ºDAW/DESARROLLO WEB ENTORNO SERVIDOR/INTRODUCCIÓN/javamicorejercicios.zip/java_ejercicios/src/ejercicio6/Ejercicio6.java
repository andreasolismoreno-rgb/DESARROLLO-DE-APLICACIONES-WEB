/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio6;

import java.util.List;

/*precios superiores a 50. Recorre una colección y selecciona algunos valores.
Hazlo todo directamente en main. Guarda los precios 20, 55, 180, 35 y 75. 
Recorre los datos y muestra únicamente los precios superiores a 50. 
Al final, muestra cuántos has encontrado.

 */
public class Ejercicio6 {

    public static void main(String[] args) {
        List<Double> precios = List.of(20.0, 55.0, 180.0, 35.0, 75.0);
        int total = 0;
        for (double precio : precios) {
            if (precio > 50) {
                System.out.println(precio);
                total++;
            }
        }
        System.out.println("Total: " + total);
    }

}
/*
EXPLICACIÓN DEL CÓDIGO:

import java.util.List;
Importamos List para poder crear una lista.


List<Double> precios = List.of(20.0, 55.0, 180.0, 35.0, 75.0);
Creamos una lista llamada precios.

<Double> significa que la lista va a guardar números decimales.

La lista contiene:

20.0
55.0
180.0
35.0
75.0


int total = 0;
Creamos una variable llamada total.

La utilizamos para contar cuántos precios son superiores a 50.

Empezamos en 0 porque todavía no hemos encontrado ninguno.


for (double precio : precios) {
Este for recorre todos los elementos de la lista.

En cada vuelta, la variable precio contiene un precio diferente.

Primera vuelta → precio = 20.0
Segunda vuelta → precio = 55.0
Tercera vuelta → precio = 180.0
Cuarta vuelta → precio = 35.0
Quinta vuelta → precio = 75.0


if (precio > 50) {
Comprobamos si el precio es mayor que 50.

Si es mayor que 50, ejecutamos lo que hay dentro del if.

20.0 → no
55.0 → sí
180.0 → sí
35.0 → no
75.0 → sí


System.out.println(precio);
Si el precio es mayor que 50, lo mostramos por pantalla.

Se mostrarán:

55.0
180.0
75.0


total++;
Cada vez que encontramos un precio superior a 50, aumentamos total en 1.

Es lo mismo que:

total = total + 1;


Al principio:

total = 0

Después de encontrar 55.0:

total = 1

Después de encontrar 180.0:

total = 2

Después de encontrar 75.0:

total = 3


System.out.println("Total: " + total);
Al terminar el bucle, mostramos cuántos precios superiores a 50 hemos encontrado.

Resultado:

Total: 3


RESULTADO COMPLETO:

55.0
180.0
75.0
Total: 3


IDEA PRINCIPAL:

En este ejercicio practicamos:

List.of() → crear una lista.

for-each → recorrer todos los elementos de una lista.

if → comprobar una condición.

total++ → contar cuántos elementos cumplen una condición.

La estructura importante es:

for (double precio : precios) {
    if (precio > 50) {
        // hacemos algo
    }
}

Esto significa:

"Recorre todos los precios y, si el precio es mayor que 50, haz algo."
*/