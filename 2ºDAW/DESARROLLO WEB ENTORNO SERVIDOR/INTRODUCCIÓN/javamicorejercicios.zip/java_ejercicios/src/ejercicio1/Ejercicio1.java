package ejercicio1;
//Precio final de varios productos
//Crea un programa con productos que tengan nombre y precio sin IVA. 
//Todos aplican un IVA del 21 %. Calcula el precio final de
//cada producto. Decide qué datos pertenecen a cada producto y cuáles son comunes a todos.

public class Ejercicio1 {

    public static void main(String[] args) {
        Producto p = new Producto("Teclado", 100);

        System.out.println(p.precioFinal());
    }

    static class Producto {

        static final double IVA = 0.21;
        private String nombre;
        private double precioSinIVA;

        Producto(String nombre, double precio) {
            this.nombre = nombre;
            this.precioSinIVA = precio;
        }

        double precioFinal() {
            return precioSinIVA * (1 + IVA);
        }
    }
}

//
//IVA pertenece a la clase porque es igual para todos los productos. 
//El precio sí pertenece a cada objeto.
