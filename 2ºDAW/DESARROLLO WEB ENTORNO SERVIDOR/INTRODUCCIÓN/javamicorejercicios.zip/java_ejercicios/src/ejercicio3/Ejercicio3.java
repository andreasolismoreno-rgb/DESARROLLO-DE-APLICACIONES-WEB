/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio3;
//Préstamo de una biblioteca

import java.util.List;

/*Modela libros y revistas. Ambos tienen título. 
Un libro se presta 21 días y una revista 7. 
El programa debe poder guardar ambos tipos juntos y consultar sus días de préstamo sin preguntar 
qué tipo concreto es.

 */
public class Ejercicio3 {

    public static void main(String[] args) {
        for (Recurso r : List.of(new Libro("Java"), new Revista("Web"))) {
            System.out.println(r.titulo + ": " + r.diasPrestamo() + " días");
        }
    }

    static abstract class Recurso {

        String titulo;

        Recurso(String t) {
            titulo = t;
        }

        abstract int diasPrestamo();
    }

    static class Libro extends Recurso {

        Libro(String t) {
            super(t);
        }

        int diasPrestamo() {
            return 21;
        }
    }

    static class Revista extends Recurso {

        Revista(String t) {
            super(t);
        }

        int diasPrestamo() {
            return 7;
        }
    }
}
