/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio9;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/*Alumnso en dos módulos. Averigua qué nombres aparecen en dos grupos.
Hazlo todo directamente en main. Java contiene Ana, Luis y Marta. 
Web contiene Luis, Marta y Pablo. Obtén los alumnos presentes en ambos grupos sin modificar los grupos originales.

 */
public class Ejericicio9 {

    public static void main(String[] args) {
        Set<String> java
                = new HashSet<>(List.of("Ana", "Luis", "Marta"));
        Set<String> web
                = new HashSet<>(List.of("Luis", "Marta", "Pablo"));
        Set<String> comunes = new HashSet<>(java);
        comunes.retainAll(web);
        System.out.println(comunes);
    }

}
/*
EXPLICACIÓN:

Set<String> java = new HashSet<>(List.of("Ana", "Luis", "Marta"));
Creamos un conjunto con los alumnos de Java.

Set<String> web = new HashSet<>(List.of("Luis", "Marta", "Pablo"));
Creamos otro conjunto con los alumnos de Web.

Set<String> comunes = new HashSet<>(java);
Creamos una copia del grupo de Java para no modificar el grupo original.

comunes.retainAll(web);
Nos quedamos solamente con los alumnos que aparecen en los dos grupos.

java:
Ana, Luis, Marta

web:
Luis, Marta, Pablo

Comunes:
Luis, Marta

System.out.println(comunes);
Mostramos los alumnos que están en ambos grupos.


RESULTADO:

[Luis, Marta]


IDEA PRINCIPAL:

retainAll() → deja solamente los elementos que están en los dos conjuntos.

Se hace una copia con:

new HashSet<>(java)

para no modificar el conjunto original.
*/