/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio13;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/*Etiquetas de dos articulos 
Combina elementos sin repetirlos y localiza los que solo aparecen en un grupo.
Hazlo todo directamente en main. El artículo A tiene java, web y backend. 
El artículo B tiene java, api y backend. Muestra todas las etiquetas sin repetir 
y después las que aparecen en A pero no en B.

 */
public class Ejercicio13 {

    public static void main(String[] args) {
        Set<String> a = new LinkedHashSet<>(List.of("java", "web", "backend"));
        Set<String> b = new LinkedHashSet<>(List.of("java", "api", "backend"));
        
        Set<String> todas = new LinkedHashSet<>(a);
        todas.addAll(b);
        
        Set<String> soloA = new LinkedHashSet<>(a);
        soloA.removeAll(b);
        
        System.out.println("Todas: " + todas);
        System.out.println("Solo A: " + soloA);
    }

}
/*
EXPLICACIÓN:

Set<String> a = ...
Creamos el conjunto de etiquetas del artículo A.

Set<String> b = ...
Creamos el conjunto de etiquetas del artículo B.

Set<String> todas = new LinkedHashSet<>(a);
Hacemos una copia de las etiquetas de A.

todas.addAll(b);
Añadimos las etiquetas de B.
Como es un Set, no se repiten.

Set<String> soloA = new LinkedHashSet<>(a);
Hacemos otra copia de A.

soloA.removeAll(b);
Eliminamos de A las etiquetas que también están en B.
Así quedan solo las que aparecen en A.


RESULTADO:

Todas: [java, web, backend, api]
Solo A: [web]


IDEA PRINCIPAL:

addAll() → añade todos los elementos.

removeAll() → elimina los elementos que también están en otro conjunto.

Set → no permite elementos repetidos.
*/