/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio7;

import java.util.List;

/*Media nota máxima. Obtén información a partir de varios números.
Hazlo todo directamente en main. Guarda las notas 6, 9, 3, 7 y 5. 
Recorre los datos para calcular la media y localizar la nota máxima. Muestra ambos resultados.
 */
public class Ejercicio7 {

    public static void main(String[] args) {
        List<Integer> notas = List.of(6, 9, 3, 7, 5);
        int suma = 0;
        int maxima = notas.get(0);
        for (int nota : notas) {
            suma += nota;
            if (nota > maxima) {
                maxima = nota;
            }
        }
        double media = (double) suma / notas.size();
        System.out.println("Media: " + media);
        System.out.println("Máxima: " + maxima);
    }

}
/*
EXPLICACIÓN DEL CÓDIGO:

import java.util.List;
Importamos List para poder crear una lista.


List<Integer> notas = List.of(6, 9, 3, 7, 5);
Creamos una lista llamada notas.

<Integer> significa que la lista guarda números enteros.

La lista contiene:

[6, 9, 3, 7, 5]


int suma = 0;
Creamos una variable llamada suma.

La utilizaremos para sumar todas las notas.

Empezamos en 0 porque todavía no hemos sumado ninguna nota.


int maxima = notas.get(0);
Creamos una variable llamada maxima para guardar la nota más alta.

Le damos inicialmente el valor de la primera nota:

notas.get(0) → 6

Por tanto:

maxima = 6

Después iremos comparando las demás notas con este valor.


for (int nota : notas) {
Recorremos todas las notas de la lista.

En cada vuelta, la variable nota contiene una nota diferente.

Primera vuelta → 6
Segunda vuelta → 9
Tercera vuelta → 3
Cuarta vuelta → 7
Quinta vuelta → 5


suma += nota;
Sumamos cada nota a la variable suma.

Es lo mismo que:

suma = suma + nota;

Las sumas serían:

0 + 6 = 6
6 + 9 = 15
15 + 3 = 18
18 + 7 = 25
25 + 5 = 30

Al terminar:

suma = 30


if (nota > maxima) {
Comprobamos si la nota actual es mayor que la máxima que tenemos guardada.


maxima = nota;
Si la nota actual es mayor, la guardamos como nueva máxima.

Por ejemplo:

Primero:
maxima = 6

Llega el 9:

9 > 6 → verdadero

Entonces:

maxima = 9

Después:

3 > 9 → falso
7 > 9 → falso
5 > 9 → falso

Por tanto, al terminar:

maxima = 9


double media = (double) suma / notas.size();
Calculamos la media.

suma = 30

notas.size() = 5

Por tanto:

30 / 5 = 6.0

El `(double)` sirve para convertir suma a número decimal antes de hacer la división.

Así la variable media puede guardar un resultado decimal.


System.out.println("Media: " + media);
Mostramos la media.

Resultado:

Media: 6.0


System.out.println("Máxima: " + maxima);
Mostramos la nota máxima.

Resultado:

Máxima: 9


RESULTADO COMPLETO:

Media: 6.0
Máxima: 9


IDEA PRINCIPAL:

En este ejercicio hacemos dos cosas mientras recorremos la lista:

1. Sumamos todas las notas:

suma += nota;

2. Buscamos la nota máxima:

if (nota > maxima) {
    maxima = nota;
}

Después calculamos la media:

double media = (double) suma / notas.size();


IMPORTANTE PARA EL EXAMEN:

get(0) → obtiene el primer elemento.

size() → indica cuántos elementos tiene la lista.

+= → suma un valor a una variable.

(double) → convierte el número a decimal.

El truco para buscar el máximo es empezar con el primer elemento:

int maxima = notas.get(0);

y después comparar los demás.
*/