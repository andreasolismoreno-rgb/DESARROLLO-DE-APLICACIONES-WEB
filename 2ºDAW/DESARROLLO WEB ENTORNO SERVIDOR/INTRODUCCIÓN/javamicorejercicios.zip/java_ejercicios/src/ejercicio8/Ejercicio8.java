/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio8;

import java.util.LinkedHashSet;
import java.util.Set;

/*correos sin repetir
Hazlo todo directamente en main. Introduce ana@web.es, luis@web.es, ana@web.es y marta@web.es. 
Muestra los correos que quedan almacenados y el número de correos diferentes.

 */
public class Ejercicio8 {

    public static void main(String[] args) {
        Set<String> correos = new LinkedHashSet<>();
        correos.add("ana@web.es");
        correos.add("luis@web.es");
        correos.add("ana@web.es");
        correos.add("marta@web.es");
        System.out.println(correos);
        System.out.println("Diferentes: " + correos.size());
    }

}

/*
EXPLICACIÓN:

Set<String> correos = new LinkedHashSet<>();
Creamos un Set para guardar correos sin repetir.
LinkedHashSet mantiene el orden en el que los añadimos.

correos.add(...)
Añadimos los correos a la colección.
El correo de Ana aparece dos veces, pero Set solo guarda uno.

System.out.println(correos);
Muestra los correos almacenados.

correos.size()
Cuenta cuántos correos diferentes hay.


RESULTADO:

[ana@web.es, luis@web.es, marta@web.es]
Diferentes: 3


IDEA PRINCIPAL:

Set → no permite elementos repetidos.

add() → añade un elemento.

size() → cuenta los elementos.

En este ejercicio usamos Set para evitar correos duplicados.
*/