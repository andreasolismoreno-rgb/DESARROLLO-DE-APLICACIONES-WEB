/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio10;

import java.util.HashMap;
import java.util.Map;

/*Agenda telefónica. Relaciona cada nombre con su número de teléfono.

Hazlo todo directamente en main. Guarda Ana-600111111, Luis-600222222 y Marta-600333333. 
Muestra el teléfono de Luis, cambia el de Ana y elimina a Marta. Después muestra la agenda completa.

 */
public class Ejercicio10 {

    public static void main(String[] args) {
        Map<String, String> agenda = new HashMap<>();
        agenda.put("Ana", "600111111");
        agenda.put("Luis", "600222222");
        agenda.put("Marta", "600333333");
        System.out.println(agenda.get("Luis"));
        agenda.put("Ana", "699999999");
        agenda.remove("Marta");
        System.out.println(agenda);
    }

}
/*
EXPLICACIÓN:

Map<String, String> agenda = new HashMap<>();
Creamos un Map para relacionar cada nombre con un teléfono.

agenda.put(...)
Añadimos un nombre y su número.

agenda.get("Luis")
Buscamos y mostramos el teléfono de Luis.

agenda.put("Ana", "699999999")
Cambiamos el teléfono de Ana.

agenda.remove("Marta")
Eliminamos a Marta de la agenda.

System.out.println(agenda)
Mostramos la agenda completa.


RESULTADO:

600222222
{Ana=699999999, Luis=600222222}


IDEA PRINCIPAL:

Map → relaciona una clave con un valor.

put() → añade o modifica.
get() → busca un valor.
remove() → elimina.
*/