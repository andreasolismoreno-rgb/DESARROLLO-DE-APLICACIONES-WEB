/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio11;

import java.util.HashMap;
import java.util.Map;

/*Actualiza Stock. Modifica cantidades localizadas mediante un código.

Hazlo todo directamente en main. El stock inicial es P01=5, P02=2 y P03=8. Vende dos unidades de P01, añade cinco a P02 y elimina P03 del catálogo. Muestra el stock final.

 */
public class Ejercicio11 {

    public static void main(String[] args) {
        Map<String, Integer> stock = new HashMap<>();
        stock.put("P01", 5);
        stock.put("P02", 2);
        stock.put("P03", 8);
        stock.put("P01", stock.get("P01") - 2);
        stock.put("P02", stock.get("P02") + 5);
        stock.remove("P03");
        System.out.println(stock);
    }

}
/*
EXPLICACIÓN:

Map<String, Integer> stock = new HashMap<>();
Creamos un Map para relacionar el código del producto con su cantidad.

stock.put(...)
Añadimos los productos y sus cantidades.

stock.get("P01") - 2
Obtenemos las unidades de P01 y le restamos 2 porque vendemos dos.

stock.get("P02") + 5
Obtenemos las unidades de P02 y le sumamos 5.

stock.remove("P03")
Eliminamos P03 del stock.

System.out.println(stock)
Mostramos el stock final.


RESULTADO:

{P01=3, P02=7}


IDEA PRINCIPAL:

put() → añade o modifica.
get() → obtiene una cantidad.
remove() → elimina un producto.
*/