/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio5;

import java.util.ArrayList;
import java.util.List;

/*Lista de tareas. Practica las operaciones básicas de una colección ordenada.
Guarda Estudiar, Comprar y Entrenar. 
Sustituye Comprar por Preparar clase
Elimina Entrenar 
y muestra las tareas restantes junto a su posición.


 */
public class Ejercicio5 {

    public static void main(String[] args) {
        List<String> tareas = new ArrayList<>();
        tareas.add("Estudiar");
        tareas.add("Comprar");
        tareas.add("Entrenar");
        tareas.set(1, "Preparar clase");
        tareas.remove("Entrenar");
        for (int i = 0; i < tareas.size(); i++) {
            System.out.println(i + " - " + tareas.get(i));
        }
    }

}


/*
EXPLICACIÓN DEL CÓDIGO:

import java.util.ArrayList;
Importamos ArrayList para poder crear una lista que pueda guardar varios elementos.

import java.util.List;
Importamos List porque vamos a utilizar List para declarar nuestra colección.


List<String> tareas = new ArrayList<>();
Creamos una lista llamada tareas.

<String> significa que la lista solo va a guardar textos (String).

ArrayList es el tipo de lista que utilizamos para guardar las tareas.


tareas.add("Estudiar");
Añadimos "Estudiar" a la lista.

La lista queda:

[Estudiar]


tareas.add("Comprar");
Añadimos "Comprar".

La lista queda:

[Estudiar, Comprar]


tareas.add("Entrenar");
Añadimos "Entrenar".

La lista queda:

[Estudiar, Comprar, Entrenar]


tareas.set(1, "Preparar clase");
Cambiamos el elemento que está en la posición 1.

MUY IMPORTANTE:
Las posiciones empiezan en 0.

Posición 0 → Estudiar
Posición 1 → Comprar
Posición 2 → Entrenar

Por eso:

set(1, "Preparar clase")

cambia "Comprar" por "Preparar clase".

Ahora tenemos:

[Estudiar, Preparar clase, Entrenar]


tareas.remove("Entrenar");
Eliminamos de la lista el elemento "Entrenar".

Ahora queda:

[Estudiar, Preparar clase]


for (int i = 0; i < tareas.size(); i++) {
Creamos un bucle para recorrer toda la lista.

int i = 0
Empezamos en la posición 0.

i < tareas.size()
Mientras i sea menor que el número de elementos de la lista, seguimos recorriendo.

i++
Aumentamos i en 1 en cada vuelta.


tareas.get(i)
Obtiene el elemento que está en la posición i.

Por ejemplo:

get(0) → Estudiar
get(1) → Preparar clase


System.out.println(i + " - " + tareas.get(i));
Muestra la posición y la tarea.

El resultado es:

0 - Estudiar
1 - Preparar clase


IDEA PRINCIPAL:

En este ejercicio practicamos las operaciones básicas de una List:

add() → añadir un elemento
set() → cambiar un elemento
remove() → eliminar un elemento
get() → obtener un elemento
size() → saber cuántos elementos tiene la lista

MUY IMPORTANTE PARA EL EXAMEN:

Las posiciones de una lista empiezan en 0.

0 → primer elemento
1 → segundo elemento
2 → tercer elemento
*/