/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2;
//numeración automática de varios pedidos
//Crea pedidos sin introducir manualmente su identificador. 
//El primero tendrá el número 1, el segundo el 2 y así sucesivamente. 
//Cada pedido conservará siempre su número. Decide dónde guardar el dato que 
//permite generar el siguiente identificador.
public class Ejercicio2 {

    public static void main(String[] args) {
        Pedido a = new Pedido();
        Pedido b = new Pedido();
        System.out.println(a.getId());
        System.out.println(b.getId());

    }

    static class Pedido {

        private static int siguienteId = 1;
        private final int id;

        Pedido() {
            id = siguienteId;
            siguienteId++;
        }

        int getId() {
            return id;
        }
    }

}

//siguienteId es compartido; id pertenece a un pedido concreto. 
//Cada constructor consume un número y prepara el siguiente.

