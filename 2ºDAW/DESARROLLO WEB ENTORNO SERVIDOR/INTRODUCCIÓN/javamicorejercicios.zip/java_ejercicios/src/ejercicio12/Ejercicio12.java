/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio12;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/*Ordenar tiempos de respuesta. Ordena varios valores y elimina el más lento.
Hazlo todo directamente en main. Guarda los tiempos 420, 180, 350, 210 y 500 milisegundos. 
Ordénalos de menor a mayor, elimina el tiempo más alto y muestra los valores restantes y el tiempo más rápido.

 */
public class Ejercicio12 {

    public static void main(String[] args) {
        List<Integer> tiempos = new ArrayList<>(List.of(420, 180, 350, 210, 500));
        Collections.sort(tiempos);
        tiempos.remove(tiempos.size() - 1);
        System.out.println(tiempos);
        System.out.println("Más rápido: " + tiempos.get(0) + " ms");
    }

}
/*
EXPLICACIÓN:

List<Integer> tiempos = new ArrayList<>(List.of(...));
Creamos una lista con los tiempos.

Collections.sort(tiempos);
Ordenamos la lista de menor a mayor.

tiempos.remove(tiempos.size() - 1);
Eliminamos el último elemento, que es el tiempo más alto.

System.out.println(tiempos);
Mostramos los tiempos restantes.

tiempos.get(0)
Obtenemos el primer elemento, que es el tiempo más rápido.


RESULTADO:

[180, 210, 350, 420]
Más rápido: 180 ms


IDEA PRINCIPAL:

Collections.sort() → ordena de menor a mayor.

size() - 1 → posición del último elemento.

get(0) → primer elemento.
*/ 