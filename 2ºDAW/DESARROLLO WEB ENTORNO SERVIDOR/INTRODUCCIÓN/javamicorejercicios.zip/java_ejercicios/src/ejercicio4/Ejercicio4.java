/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio4;

/*Enviar avisos por distintos canales
Modela dos formas de notificación: correo electrónico y SMS. 
Ambas deben poder recibir el mismo mensaje. Recorre conjuntamente varios canales 
y envía «Hola» sin escribir un bucle distinto para cada tipo.

 */
import java.util.List;

public class Ejercicio4 {

    static abstract class Notificacion {

        abstract void enviar(String mensaje);
    }

    static class Email extends Notificacion {

        void enviar(String m) {
            System.out.println("EMAIL: " + m);
        }
    }

    static class Sms extends Notificacion {

        void enviar(String m) {
            System.out.println("SMS: " + m);
        }
    }

    public static void main(String[] args) {
        for (Notificacion n : List.of(new Email(), new Sms())) {
            n.enviar("Hola");
        }
    }
}

/*
EXPLICACIÓN DEL CÓDIGO:

package ejercicio4;
Indica que la clase pertenece al paquete ejercicio4.

import java.util.List;
Importamos List para poder crear una lista de objetos.

public class Ejercicio4 {
Creamos la clase principal llamada Ejercicio4.


static abstract class Notificacion {
Creamos una clase abstracta llamada Notificacion.
Es abstracta porque no vamos a crear directamente objetos de ella.
static permite utilizarla desde el main, que también es static.


abstract void enviar(String mensaje);
Indica que todas las notificaciones deben tener un método enviar().
No tiene código porque cada tipo de notificación lo hará de una forma diferente.


static class Email extends Notificacion {
Creamos la clase Email.
extends Notificacion significa que Email hereda de Notificacion.


void enviar(String m) {
Creamos el método enviar() para Email.


System.out.println("EMAIL: " + m);
Muestra por pantalla el mensaje indicando que es un EMAIL.


static class Sms extends Notificacion {
Creamos la clase Sms.
También hereda de Notificacion.


void enviar(String m) {
Creamos el método enviar() para SMS.


System.out.println("SMS: " + m);
Muestra por pantalla el mensaje indicando que es un SMS.


public static void main(String[] args) {
Es el método principal. Es donde empieza a ejecutarse el programa.


for (Notificacion n : List.of(new Email(), new Sms())) {
Creamos una lista con un Email y un Sms.
Los dos se pueden guardar juntos porque ambos son Notificacion.
El for recorre los dos objetos.


n.enviar("Hola");
Llamamos al método enviar() de cada objeto.
Primero se ejecuta el de Email y después el de Sms.


RESULTADO:

EMAIL: Hola
SMS: Hola


IDEA PRINCIPAL:

Notificacion
    |
    |--- Email
    |
    |--- Sms

Notificacion indica que todas deben tener enviar().
Email y Sms indican cómo funciona enviar() en cada caso.

Por eso podemos recorrer Email y Sms juntos con un solo for.
*/



/*
explicacion
        
package ejercicio4;

import java.util.List; // Importamos List para poder crear una lista de notificaciones.

public class Ejercicio4 {

    // Clase abstracta que representa una notificación.
    // Es abstracta porque no vamos a crear directamente objetos Notificacion.
    static abstract class Notificacion {

        // Todas las notificaciones tendrán un método enviar().
        // No ponemos el código porque cada tipo de notificación lo hará de una forma diferente.
        abstract void enviar(String mensaje);
    }

    // Clase Email que hereda de Notificacion.
    static class Email extends Notificacion {

        // Implementamos el método enviar() para los correos electrónicos.
        void enviar(String m) {

            // Mostramos el mensaje indicando que es un EMAIL.
            System.out.println("EMAIL: " + m);
        }
    }

    // Clase Sms que hereda de Notificacion.
    static class Sms extends Notificacion {

        // Implementamos el método enviar() para los SMS.
        void enviar(String m) {

            // Mostramos el mensaje indicando que es un SMS.
            System.out.println("SMS: " + m);
        }
    }

    // Método principal del programa.
    public static void main(String[] args) {

        // Creamos una lista con un Email y un Sms.
        // Los dos pueden guardarse juntos porque ambos son Notificacion.
        for (Notificacion n : List.of(new Email(), new Sms())) {

            // Llamamos al método enviar() para cada notificación.
            // Primero se ejecuta el de Email y después el de Sms.
            n.enviar("Hola");
        }
    }
}*/